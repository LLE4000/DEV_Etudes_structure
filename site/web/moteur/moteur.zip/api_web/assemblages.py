# -*- coding: utf-8 -*-
"""Le module « Assemblages métalliques » du site : une note = un PROJET d'assemblages (la page projet de Streamlit,
modules/assemblages.py et acier/projet.py) ; chaque élément de la note est un assemblage, de l'une des sept
configurations du registre (acier/registre.py) :

- poutre–poutre : plat d'âme soudé, doubles cornières, platine d'about (api_web/assemblages_poutre.py) ;
- poutre–poteau : les trois mêmes attaches sur l'aile ou dans l'âme d'un poteau (api_web/assemblages_poteau.py) ;
- pied de poteau sur platine béton, avec son calcul « platine à la main » (api_web/assemblages_pied.py).

Ce fichier est l'AIGUILLAGE et la CARTE COMMUNE : l'état de la note, la liste des assemblages (ajouter, copier,
supprimer), le menu « Configuration » en tête du cadre Données, puis la mise en forme commune à toutes les
configurations — le cadre Données (sections numérotées), le résultat (verdict, une ligne par pièce), les fenêtres de
calcul (tableau des vérifications et détail des formules), les sélecteurs (boulon, profilés, cornière, propositions
du prédimensionnement) et les vues de la toile : les DESSINS, et eux seuls.

Chaque configuration est DÉCRITE par sa famille (``Config`` ci-dessous) : son moteur (``entrees``, ``moteur``,
``synthese``, ``formules``, ``notation``, ``texte``, ``methode``, ``benchmark``, ``schemas`` du dépôt — jamais
``interface.py``, ``ecran_*.py``, ``note.py``, ``carte.py`` ni ``ui_commun.py``, qui chargent streamlit ou
reportlab), ses libellés courts, ses sections, ses vues. Rien n'est recalculé ici : les taux, les formules, les
alertes, les dessins viennent du moteur ; ce fichier les MET EN FORME.

L'état d'un assemblage reprend celui de l'écran Streamlit : ``values`` porte les clés de ``entrees.defaults()``,
normalisées comme les widgets les rendent (``carte.valeur_widget`` : un nombre est un flottant ou None, un choix est
l'une de ses options, un texte est une chaîne) — c'est exactement ce que l'écran Streamlit passe au moteur
(tests/test_api_web_assemblages.py le prouve en faisant tourner l'écran Streamlit lui-même).

L'écran est l'établi COMPACT (api_web/etabli_compact.py, la mise en forme des poutres — 12/11/2026), le même pour les
sept configurations : à gauche la ligne de l'assemblage ouvert (son REPÈRE, qui est son nom ; la liste, copier,
supprimer) et les rubriques de la configuration en accordéon — la première seule ouverte, « Options » secondaire ; au
centre les dessins sous leur en-tête technique ; à droite la tête, le verdict, le bloc « Vérifications » (une ligne
par pièce : ce qu'elle choisit — boulon, profilé —, son taux, ce que sa vérification la plus chargée compare ; puis
la géométrie du Tableau 3.3) et le bloc « Prédimensionnement », qui ouvre les propositions.

REVUE DE L'ÉCRAN du 25/11/2026 (le propriétaire, sur sa tablette) — ce qui a changé, et pourquoi :

- « dans la partie centrale, on devrait juste avoir élévation, plan, droite » : la toile ne porte plus que les dessins.
  Les onglets Prédim, Note (« c'était pour la recopier dans mon mail, il n'y a plus besoin »), Méthode et Validation
  (« c'est dans le dépôt GitHub, où on revérifie à chaque fois qu'on modifie quelque chose ») sont retirés ; ce que la
  vérification ne couvre PAS reste écrit, au pied de chaque fenêtre de calcul ;
- « les propositions, ça doit nous proposer des propositions qui sont correctes » : le bloc « Prédimensionnement » du
  résultat ouvre des dispositions VÉRIFIÉES par le calcul complet (acier/assemblages/propositions.py : plus de
  rangées, une deuxième file, une pièce plus épaisse) ; sans solution, il nomme la vérification qui bloque et dit de
  changer de profilé. La bascule « Mode vérification / prédimensionnement » n'existe plus : une note enregistrée dans
  ce mode est relue avec sa proposition recopiée (``sans_mode_predim``) ;
- « poutre et grugeage, ça pourrait être regroupé » ; « cartouche, affichage, coefficients, modèle : plutôt un truc
  d'option » : les rubriques sont Assemblage · Poutres (avec le grugeage) · la pièce d'attache · Boulons · Efforts ELU ·
  Options. « Options » porte aussi les règles du prédimensionnement et « afficher les taux dans la note de calcul » (une
  option de la NOTE, ``etat["note_taux"]`` : api_web/note_assemblages.py).
"""
import copy
import html
import json
import math
import re
from typing import Callable, Dict, List, Optional, Sequence

from acier import projet as PJ
from acier import registre as RG
from acier.assemblages import propositions as PR
from acier.bibliotheques import DB, PERSO, find

from . import commun as C
from . import dessin_assemblages as DA
from . import etabli_compact as E

MODULE = "assemblages"
PAGE = "assemblages"
GENRE = E.Genre("Assemblages", "l'assemblage", "cet assemblage", "un assemblage")
CLASSES_BLOC = {"p": "ok", "f": "warn", "r": "nok", "v": "warn"}
# la rubrique SECONDAIRE des sept configurations : « Options » (coefficients, modèle, prédimensionnement, note, cartouche)
SECONDAIRES = frozenset({"op"})

VISSERIE_DEFAUT = "1 rondelle + 1 écrou"
NIVEAUX_COTATION = (("0", "Simple"), ("1", "Édition"), ("2", "Toutes"))   # « Vue simple », « Complète » : rognés à 1024 px
MODE_VERIF = "VÉRIFICATION"                # le seul mode de calcul de l'écran du site (``sans_mode_predim``)
UNITES = {"kNm": "kN·m", "MPa": "N/mm²", "-": ""}
OUI_NON = ["Oui", "Non"]
# les nombres qui comptent (rangées, files de tiges) : entiers ≥ 1 — Streamlit les arrondit en silence
# (moteur : n1 = max(1, Math.round(n1))), le site refuse une saisie qui ne l'est pas
COMPTES = {"n1_u", "n1S_u", "n1P_u", "n_ax", "n_ay"}
# … et BORNÉS : l'écran Streamlit n'a pas de maximum, et le moteur pose un boulon par case — n₁ = 10⁹ rangées (une
# faute de frappe, un fichier abîmé) épuise la mémoire (mesuré : 14 Go, processus tué) et figerait l'onglet du
# navigateur. 50 rangées (une platine de 3 m au pas de 60 mm) et 20 × 20 tiges (40 × 40 : 6,6 s par calcul hors
# navigateur, huit calculs par ouverture du sélecteur des tiges) couvrent tous les assemblages réels.
COMPTES_MAXI = {"n1_u": 50, "n1S_u": 50, "n1P_u": 50, "n_ax": 20, "n_ay": 20}
# les grandeurs qui peuvent être négatives (signe = sens) ; les autres dimensions sont ≥ 0
SIGNEES = {"V_Ed", "N_Ed", "M_Ed", "H_Ed", "Mx_Ed", "My_Ed", "Vx_Ed", "Vy_Ed", "T_Ed", "xN", "yN", "d_top"}
# les coefficients et résistances strictement positifs (une division par zéro donnerait des taux absurdes)
POSITIVES = re.compile(r"^(g_M\w*|g_c|g_Mc|fy_u|fu_u|bw_u|eta_c|k_e1|k_p1|k_e2|k_rot|a_cc)$")
# les dimensions saisies d'un profil, d'une cornière, d'un acier personnalisés, reprises de la pièce qu'on quitte
PERSO_PROFIL = {"prof_P": "P", "prof_S": "S"}
PERSO_ACIER = (("fy_u", "fy"), ("fu_u", "fu"), ("bw_u", "bw"))
# … et leur aide : ces trois champs sont COMMUNS à toutes les pièces d'un assemblage en « Personnalisé » (une seule
# saisie pour la porteuse, la portée, le plat…), et la reprise ne les remplit qu'une fois (``_reprendre_acier`` :
# seulement s'ils sont vides) — une deuxième pièce passée en « Personnalisé » prend les valeurs de la première
AIDE_PERSO_ACIER = ("commun à toutes les pièces en « Personnalisé » ; repris de la première pièce passée en "
                    "« Personnalisé » (la valeur qui redonne ce que son calcul retenait), puis gardé pour les suivantes")


# ===================================================================== la description d'une configuration
class Config:
    """Ce qu'une famille confie à la carte commune pour une configuration (voir les fichiers assemblages_*.py).

    ``E`` entrees, ``calculer(u)`` → R, ``S`` synthese, ``N`` notation, ``bench`` (module benchmark ou None : ses
    exemples publiés se chargent depuis « Options »), ``vues(R, opt)`` → [(clé, titre, court, Dessin)],
    ``options_dessin(R, niveau, hl)``, ``sections(u, R, el)`` → [(clé, titre, résumé, [items], ouvert)], ``libelles``
    {clé: (symbole, libellé)}, ``formules(R, c)`` → (aide, [lignes de C.lignes_fx]), ``parametres(R)`` → [[libellé,
    valeur]], ``non_reverifies`` (texte de l'écran Streamlit : ce que la vérification ne couvre pas, au pied des
    fenêtres de calcul), ``piece(R, u, groupe)`` → (texte, rôle du sélecteur), ``tableaux_boulons(R)`` → [(titre, liste
    d'EffortBoulon)], ``dimensions`` (valeurs provisoires des dimensions vides), ``segments`` (clés en segments),
    ``affichage`` (options courtes), ``famille`` (clé de la famille du registre), ``blocs(R, groupe)`` (HTML de plus
    dans la fenêtre d'une pièce : la matrice aile A · aile B des cornières).

    ``predim`` (ou None : pied de poteau) : les PROPOSITIONS du prédimensionnement (acier/assemblages/propositions.py)
    — ``moteur`` (le module du moteur : ``compute``, ``apply_solution``), ``genre`` (« plat », « cornieres »,
    « platine »), ``nom(v)`` (une proposition en quelques mots, depuis ses saisies : « 3 M20 · L100x100x8 ») et
    ``detail(v)`` (sa géométrie : pinces, entraxes, gorge).

    Facultatifs (famille poutre–poteau) : ``noms_aciers`` {« P »: « poteau », …} (les aciers des hypothèses),
    ``sans_objet(R)`` (ce que l'écran ajoute au « sans objet » de son périmètre), ``regle_33`` (la règle du
    Tableau 3.3 que l'écran écrit sous ses pinces).

    Facultatifs (famille pied de poteau, deux modes et des tables libres) : ``visserie_defaut`` (la visserie d'un
    assemblage neuf de l'écran Streamlit, ``entrees.VISSERIE_DEFAUT``), ``exemples()`` → [(id, libellé, saisies
    brutes)] (« Charger ces données dans l'outil » : les cas de chaque mode), ``etat`` {clé: normaliser} (un état
    d'écran propre à l'assemblage, hors saisies du moteur : la grille à poser), ``actions`` {tête: f(cfg, el, reste,
    valeur)} (les chemins de cet état), ``sur_saisie`` {clé: f(cfg, el, valeur)} (une saisie qui fait plus que
    s'écrire : la bascule de mode reprend la disposition), ``aides`` (dict ou f(u) : l'aide « ? » de l'écran
    Streamlit d'un champ), ``hypotheses(R, u)`` (pastilles de plus), ``normes`` {groupe: norme}, ``blocs_tete(R,
    groupe)`` (HTML en tête du détail d'une fenêtre), ``lignes_resultat(R, u)`` (lignes de plus dans le résultat),
    ``legende_33`` (le pied de la fenêtre Géométrie), ``titre_non_verifies`` (le titre de
    ce que la vérification ne couvre pas), ``nom_menu`` (le nom de l'attache dans le menu Configuration quand son nom
    court redit sa famille), ``refus(u)`` → [(chemin, message)] (les lignes de ses tables qu'une note relue porte et
    que la saisie refuserait), ``mot_information(R, groupe)`` (ce que la ligne d'une pièce d'information dit d'elle : « information » par défaut ;
    le béton d'ancrage hors du périmètre « EC3 seul » le dit)."""

    def __init__(self, **k):
        self.__dict__.update(k)
        a = RG.trouver(self.cle)
        if not a:
            raise KeyError(f"configuration absente du registre : {self.cle}")
        self.famille, self.titre, self.court = a[0].id, a[1].titre, a[1].court or a[1].titre
        self.titre_famille = a[0].titre
        for nom, defaut in (("affichage", {}), ("segments", frozenset()), ("libelles", {}), ("dimensions", {}),
                            ("predim", None), ("bench", None), ("non_reverifies", ()), ("tableaux_boulons", None),
                            ("selecteurs", {}), ("entiers", frozenset()), ("listes", {}), ("est_manuel", None),
                            ("blocs", None), ("visserie_defaut", VISSERIE_DEFAUT), ("exemples", None), ("etat", {}),
                            ("actions", {}), ("sur_saisie", {}), ("aides", None), ("hypotheses", None), ("normes", {}),
                            ("blocs_tete", None), ("lignes_resultat", None),
                            ("legende_33", None), ("titre_non_verifies", None),
                            ("nom_menu", None), ("refus", None), ("mot_information", None)):
            if not hasattr(self, nom):
                setattr(self, nom, defaut)


CONFIGS: Dict[str, Config] = {}


def enregistrer(cfg: Config) -> None:
    CONFIGS[cfg.cle] = cfg


def ordre() -> List[str]:
    """Les configurations dans l'ordre du registre (familles, puis assemblages)."""
    return [a.id for f in RG.FAMILLES for a in f.assemblages if a.id in CONFIGS]


def _cfg(el: Dict) -> Config:
    return CONFIGS[el["type"]]


def pour(cfg: Config, R) -> Config:
    """La description qui rend le résultat ``R`` : celle de la configuration, ou de sa variante (le pied de poteau
    a deux moteurs, la vérification complète et le calcul à la main, avec chacun sa synthèse, son texte, ses vues)."""
    v = getattr(cfg, "variante", None)
    return v(R) if (v and R is not None) else cfg


# ===================================================================== les valeurs d'un assemblage
def valeur_widget(cfg: Config, k: str, v):
    """La valeur telle que l'écran Streamlit la tient (``carte.valeur_widget``, recopiée faute de pouvoir importer
    carte.py qui charge streamlit — test : tests/test_api_web_assemblages.py la compare à l'original)."""
    f = cfg.E.CHAMPS.get(k)
    if f is None:
        return "" if v is None else str(v)
    if f["t"] == "n":
        if v is None or v == "":
            return None
        try:
            return float(str(v).strip().replace(",", "."))
        except (TypeError, ValueError):
            return None
    if f["t"] == "s":
        s = str(v) if v is not None else f["o"][0]
        if s not in f["o"]:
            try:
                s = str(int(float(s)))
            except (TypeError, ValueError):
                pass
        return s if s in f["o"] else f["o"][0]
    return "" if v is None else str(v)


def valeurs_normales(cfg: Config, src) -> Dict:
    """Un jeu de saisies (fichier, état reçu) relu comme l'écran Streamlit le relit : fusion sur les défauts
    (``entrees.charger_json``), puis chaque clé normalisée comme son widget ; les listes (calcul de la platine à la
    main) passent par la famille."""
    if not isinstance(src, dict):
        raise ValueError("saisies d'assemblage illisibles")
    u = cfg.E.charger_json(src)
    out = {}
    for k in cfg.E.defaults():
        if k in cfg.listes:
            out[k] = cfg.listes[k]["normaliser"](u.get(k))
        else:
            out[k] = valeur_widget(cfg, k, u.get(k))
    return out


def dimensions_vides(cfg: Config, u: Dict) -> List[str]:
    """Les dimensions visibles d'une pièce personnalisée restées vides ou ≤ 0 (``carte.dimensions_vides``) : la
    vérification est suspendue, le dessin garde des dimensions provisoires."""
    from acier.js import N
    return [k for k in cfg.dimensions if cfg.E.champ_visible(u, k) and not (N(u.get(k)) or 0) > 0]


def a_calculer(cfg: Config, u: Dict) -> Dict:
    """Les saisies passées au moteur : celles de l'écran, les dimensions vides remplacées par leurs valeurs
    provisoires (``carte.provisoire``) — interface.py fait de même avant ``compute``."""
    vides = dimensions_vides(cfg, u)
    return dict(u, **{k: cfg.dimensions[k] for k in vides}) if vides else u


def valeurs_defaut(cfg: Config) -> Dict:
    """Les saisies d'un assemblage NEUF : ``entrees.defaults()`` mis en forme des widgets — « Créer » de la page
    projet (``projet_ui.creer``) et 🔄 de l'écran. Ce n'est pas la lecture d'un fichier vide : ``charger_json`` lit un
    fichier sans « mode » comme un fichier d'avant le calcul à la main (pied de poteau : vérification complète), alors
    qu'un pied de poteau neuf s'ouvre sur le calcul à la main."""
    return valeurs_normales(cfg, cfg.E.defaults())


def trop_grand(cfg: Config, u: Dict) -> Optional[str]:
    """Le motif d'un calcul qu'on NE LANCE PAS : un nombre de rangées ou de tiges au-delà de ``COMPTES_MAXI`` (une
    note abîmée, l'écran les refuse à la saisie), ou une table du calcul à la main plus longue que ``LIGNES_MAXI``."""
    from acier.js import N
    for k, m in COMPTES_MAXI.items():
        x = N(u.get(k)) if k in cfg.E.CHAMPS else None
        if x is not None and x > m:
            return f"{_nom_champ(cfg, k)} : {C.nb(x)} — {m} au plus"
    for k in cfg.listes:
        if isinstance(u.get(k), list) and len(u[k]) > LIGNES_MAXI:
            return f"table « {k} » : {len(u[k])} lignes — {LIGNES_MAXI} au plus"
    return None


LIGNES_MAXI = 400          # boulons, éléments ou raidisseurs d'une table du calcul à la main (400 boulons : 0,05 s)


def moteur(cfg: Config, u: Dict):
    """Le calcul du moteur sur des saisies de l'écran (dimensions vides → provisoires), jamais sur un nombre de
    rangées ou de tiges hors bornes (``trop_grand`` : ValueError)."""
    motif = trop_grand(cfg, u)
    if motif:
        raise ValueError(motif)
    return cfg.calculer(a_calculer(cfg, u))


def calculer(cfg: Config, el: Dict):
    """(R, vides, erreur) d'un assemblage."""
    u = el["values"]
    vides = dimensions_vides(cfg, u)
    motif = trop_grand(cfg, u)
    if motif:                                     # le calcul n'est pas lancé (il épuiserait la mémoire de l'onglet)
        return None, vides, motif
    try:
        return moteur(cfg, u), vides, None
    except Exception as e:  # noqa: BLE001 — l'écran Streamlit affiche « Données incomplètes » ; le site aussi
        return None, vides, f"{type(e).__name__} : {e}"


def saisies_refusees(cfg: Config, u: Dict) -> List:
    """Les saisies d'un assemblage RELU (fichier .stab, note du navigateur) que l'écran du site refuserait si on les
    tapait (``_lire_saisie``) : V<sub>Ed</sub> vide, γ ≤ 0, rangées 2,4, dimension négative… L'écran Streamlit les
    calcule EN SILENCE (V vide = 0 : plat d'âme « vérifié » à 60 % au lieu de 74 % ; γ<sub>M2</sub> = 0 : boulons à
    0 %) — non conservatif. Le site les garde dans les champs, à corriger, et suspend le verdict. [(clé, message)]"""
    out = []
    for k, f in cfg.E.CHAMPS.items():
        if f["t"] != "n" or k in cfg.listes or k in cfg.sur_saisie or not cfg.E.champ_visible(u, k):
            continue
        _x, msg = _lire_saisie(cfg, u, k, u.get(k))
        if msg:
            out.append((k, msg))
    if cfg.refus:                                 # les tables d'une configuration (pied : éléments soudés)
        out += cfg.refus(u)
    return out


# ===================================================================== l'état de la note
def _etat_ecran(cfg: Config, el: Optional[Dict] = None) -> Dict:
    """L'état d'écran propre à la configuration (``Config.etat``), relu : une valeur abîmée reprend son défaut."""
    out = {}
    for k, normal in cfg.etat.items():
        try:
            out[k] = normal((el or {}).get(k))
        except (ValueError, TypeError, KeyError):
            out[k] = normal(None)
    return out


def nouvel_assemblage(cle: str, repere: str = "A1") -> Dict:
    cfg = CONFIGS[cle]
    v = valeurs_defaut(cfg)
    v["id_rep"] = repere
    return dict({"type": cle, "values": v, "visserie": cfg.visserie_defaut, "cotation": 1}, **_etat_ecran(cfg))


def nouvel_etat() -> Dict:
    """Une note neuve : un assemblage de la première configuration ; ``note_taux`` — la note de calcul PDF écrit les
    taux (« Options » : une option de la NOTE, la même pour tous ses assemblages)."""
    return {"version": 1, "assemblages": [nouvel_assemblage(ordre()[0])], "actif": 0, "note_taux": True}


def sans_mode_predim(cfg: Config, u: Dict) -> Dict:
    """Les saisies d'un assemblage, TOUJOURS en mode vérification. Une note enregistrée dans l'ancien « mode
    prédimensionnement » (la bascule de la section Assemblage, retirée le 25/11/2026 : les propositions s'ouvrent du
    résultat) montrait le calcul de la proposition du moteur : cette proposition est RECOPIÉE dans les saisies
    (``moteur.apply_solution``), si bien que la note relue affiche le même assemblage ; si le moteur ne peut pas la
    donner (saisies incomplètes), le mode est seulement remis à « vérification »."""
    mode = getattr(cfg.E, "mode_predim", None)
    if not cfg.predim or mode is None or not mode(u):
        return u
    try:
        pd = moteur(cfg, u).get("pd")
        if pd is not None and pd.get("pick") is not None and pd.pick.get("prop"):
            return valeurs_normales(cfg, cfg.predim["moteur"].apply_solution(u, pd.pick))
    except Exception:  # noqa: BLE001 — une note que le moteur ne calcule pas : elle reste à corriger, en vérification
        pass
    return dict(u, mode_calc=MODE_VERIF)


def _assemblage_relu(el) -> Dict:
    if not isinstance(el, dict) or el.get("type") not in CONFIGS:
        raise ValueError(f"assemblage illisible ou de configuration inconnue : {str(el)[:80]}")
    cfg = CONFIGS[el["type"]]
    v = el.get("values")
    if v is None:
        v = {}
    niv = el.get("cotation", 1)
    niv = int(niv) if isinstance(niv, (int, float)) and not isinstance(niv, bool) and 0 <= niv <= 2 else 1
    vis = el.get("visserie")
    return dict({"type": cfg.cle, "values": sans_mode_predim(cfg, valeurs_normales(cfg, v)),
                 "visserie": str(vis) if vis is not None else cfg.visserie_defaut, "cotation": niv}, **_etat_ecran(cfg, el))


def normaliser(etat) -> Dict:
    """L'état reçu (navigateur, fichier .stab) relu : chaque assemblage relu comme l'écran Streamlit relit un fichier
    projet ; un assemblage illisible ou d'une configuration inconnue lève une erreur claire."""
    lst = etat.get("assemblages") if isinstance(etat, dict) else None
    if not lst:
        return nouvel_etat()
    if not isinstance(lst, list):
        raise ValueError("la liste des assemblages est illisible")
    out = {"version": 1, "assemblages": [_assemblage_relu(e) for e in lst]}
    try:
        a = int(etat.get("actif", 0) or 0)
    except (TypeError, ValueError):
        a = 0
    out["actif"] = min(max(0, a), len(out["assemblages"]) - 1)
    out["note_taux"] = etat.get("note_taux", True) is not False      # (une note d'avant l'option : les taux, comme avant)
    return out


def _actif(etat: Dict) -> Dict:
    return etat["assemblages"][etat["actif"]]


def _repere(el: Dict, i: int) -> str:
    return str(el["values"].get("id_rep") or "").strip() or f"A{i + 1}"


def _repere_libre(etat: Dict) -> str:
    """Le premier repère « A1, A2… » libre (acier/projet.repere_libre)."""
    projet = {"assemblages": [{"values": e["values"]} for e in etat["assemblages"]]}
    return PJ.repere_libre(projet)


def gerer_elements(etat: Dict, action: str, index: Optional[int] = None) -> None:
    """Les assemblages de la note : en ouvrir un, en ajouter un (même configuration que l'ouvert, valeurs par
    défaut, premier repère libre — « Nouvel assemblage » de Streamlit), copier l'ouvert (« Dupliquer » : repère
    « … (copie) »), en supprimer un (jamais le dernier)."""
    lst = etat["assemblages"]
    if action == "activer":
        etat["actif"] = min(max(0, int(index or 0)), len(lst) - 1)
    elif action == "ajouter":
        lst.append(nouvel_assemblage(_actif(etat)["type"], _repere_libre(etat)))
        etat["actif"] = len(lst) - 1
    elif action == "dupliquer":
        # (``index`` : l'assemblage à copier — la ligne de l'élément de l'établi compact ; sans : l'ouvert)
        try:
            i = etat["actif"] if index is None else min(max(0, int(index)), len(lst) - 1)
        except (TypeError, ValueError):
            i = etat["actif"]
        e = copy.deepcopy(lst[i])
        e["values"]["id_rep"] = f"{_repere(e, i)} (copie)"
        lst.insert(i + 1, e)
        etat["actif"] = i + 1
    elif action == "supprimer" and len(lst) > 1:
        i = min(max(0, int(index or 0)), len(lst) - 1)
        del lst[i]
        if etat["actif"] > i or etat["actif"] >= len(lst):
            etat["actif"] = max(0, etat["actif"] - 1)


# ===================================================================== la saisie
# Les saisies qui gardent leur SENS d'une attache poutre–poutre ou poutre–poteau à l'autre : profilés, grugeage,
# boulons (sauf leur disposition, propre à chaque pièce), efforts, coefficients, prédimensionnement, cartouche. La
# géométrie de la pièce (h_p, b_p, t_p, z, a, rangées, entraxes, pinces) ne suit PAS : la largeur d'un plat d'âme
# (100 mm) donnerait à une platine d'about une pince e2 de 5 mm.
GARDEES = frozenset({
    "id_projet", "id_rep", "id_red", "id_date", "mode_calc",
    "prof_P", "nu_P", "hP_u", "bP_u", "twP_u", "tfP_u", "rP_u", "prof_S", "nu_S", "hS_u", "bS_u", "twS_u", "tfS_u", "rS_u",
    "d_top", "d_nt", "d_nb", "l_n", "r_n", "lt_ok",
    "boulon_u", "classe", "trou", "d0_u", "filet", "cat", "mu_s", "k_s", "k_ser",
    "V_Ed", "N_Ed", "M_Ed", "H_Ed", "nat_N",
    "g_M0", "g_M1", "g_M2", "g_M2n", "g_M3", "g_M3s", "g_Mu", "opt_blf", "expo", "fy_u", "fu_u", "bw_u",
    "eta_c", "k_e1", "k_p1", "k_e2", "pd_dmin", "pd_dmax",
    # poutre–poteau : le cas d'appui et le jeu de montage de la poutre entre les ailes gardent leur sens d'une attache
    # à l'autre (la nature de N_Ed suit N_Ed : une traction de chaînage reste une traction de chaînage)
    "appui", "j_lat"})
# la pièce porteuse : une poutre principale (poutre–poutre) n'est pas un poteau (poutre–poteau)
PORTEUSE = frozenset({"prof_P", "nu_P", "hP_u", "bP_u", "twP_u", "tfP_u", "rP_u"})
# D'une famille à l'autre, la poutre portée et son grugeage ne suivent pas non plus : la pièce neuve (plat, cornières,
# platine) a la géométrie par défaut de SA famille, dimensionnée pour SA poutre par défaut (HEA 300 grugé sous une
# poutre, IPE 400 non grugé sur un poteau). Gardés, ils entraient en conflit avec elle : un HEA 300 sous un plat posé à
# z_p = 40 mm (t_f + r = 41 mm), ou un grugeage de 50 mm sur un plat à 40 mm, donnaient « Impossible » à l'ouverture.
PORTEE = frozenset({"prof_S", "nu_S", "hS_u", "bS_u", "twS_u", "tfS_u", "rS_u"})
GRUGEAGE = frozenset({"d_top", "d_nt", "d_nb", "l_n"})


def gardees(ancien: Config, cfg: Config) -> frozenset:
    """Les saisies que l'assemblage garde quand il change de configuration : dans la même famille, GARDEES ; entre
    poutre–poutre et poutre–poteau, GARDEES sans les pièces (porteuse, portée et son grugeage : l'assemblage repart
    des défauts de la configuration, comme « Créer » de Streamlit, avec ses boulons, ses efforts, ses coefficients et
    son cartouche) ; avec le pied de poteau (N_Ed y est une COMPRESSION positive, une traction ailleurs), le cartouche
    seulement."""
    if ancien.famille == cfg.famille:
        return GARDEES
    if "pied_poteau" in (ancien.famille, cfg.famille):
        return frozenset({"id_projet", "id_rep", "id_red", "id_date"})
    return GARDEES - PORTEUSE - PORTEE - GRUGEAGE


def _changer_configuration(etat: Dict, cle) -> Optional[str]:
    """Le menu « Configuration » : l'assemblage ouvert prend une autre configuration, aux valeurs par défaut ; il
    garde son repère, son cartouche, sa visserie et les saisies qui gardent leur sens (``gardees``)."""
    if cle not in CONFIGS:
        return f"Configuration inconnue : « {cle} »"
    el = _actif(etat)
    if cle == el["type"]:
        return None
    ancien, cfg = _cfg(el), CONFIGS[cle]
    v = valeurs_defaut(cfg)
    for k in gardees(ancien, cfg):
        if k not in v or k not in el["values"] or k in cfg.listes:
            continue
        f = cfg.E.CHAMPS.get(k)
        x = el["values"][k]
        if f is None or (f["t"] == "s" and x not in f["o"]):
            continue
        v[k] = valeur_widget(cfg, k, x)
    for k in ancien.etat:
        el.pop(k, None)
    el.update({"type": cle, "values": v}, **_etat_ecran(cfg))
    if el.get("visserie") == ancien.visserie_defaut:     # la visserie par défaut suit (celle de l'écran de l'attache)
        el["visserie"] = cfg.visserie_defaut
    return None


def _reprendre_profil(cfg: Config, u: Dict, k: str, ancien) -> None:
    """Un profilé (ou une cornière) passé en « Personnalisé » : ses dimensions, si elles sont vides, reprennent
    celles de la pièce qu'on quitte (Streamlit les laisse vides et suspend la vérification ; le site part d'une
    pièce réelle, qu'on modifie)."""
    if k in PERSO_PROFIL:
        X = PERSO_PROFIL[k]
        cles = [(f"{d}{X}_u", d) for d in ("h", "b", "tw", "tf", "r")]
        liste = "profils"
    elif k == "corn_u":
        cles, liste = [("k1_u", "a1"), ("k2_u", "a2"), ("kt_u", "t"), ("kr_u", "r")], "cornieres"
    else:
        return
    try:
        src = find(DB[liste], ancien)
    except (ValueError, KeyError, TypeError):
        return
    for cle, champ in cles:
        if cle in u and not (u.get(cle) or 0) > 0:
            u[cle] = float(src[champ])


def _reprendre_acier(cfg: Config, u: Dict, k: str, ancien) -> None:
    """Un acier passé en « Personnalisé » : f_y, f_u et β_w vides reprennent ceux que le calcul RETENAIT pour la pièce
    qu'on quitte (vides, le moteur prendrait f_y = 0) — f_y et f_u selon SON épaisseur (tableau 3.3 ANB), tels que le
    moteur les nomme (``R.materiau``, clé de saisie ``k``) : l'écran ne relit pas la table."""
    if not any(cle in u and not (u.get(cle) or 0) > 0 for cle, _ in PERSO_ACIER):
        return
    try:
        R = moteur(cfg, dict(u, **{k: ancien}))
        m = next(m for m in (R.get("materiau") or {}).values() if m.get("cle") == k)
    except Exception:  # noqa: BLE001 — un calcul impossible (pièce hors du tableau…) laisse les champs à remplir
        return
    for cle, champ in PERSO_ACIER:
        x = valeur_reprise(m, champ)
        if cle in u and not (u.get(cle) or 0) > 0 and x:
            u[cle] = float(x)


def valeur_reprise(m: Dict, champ: str):
    """La valeur qu'un champ « Personnalisé » reprend d'une pièce (``m`` : son matériau nommé par le moteur) : la
    valeur de SAISIE équivalente quand le moteur la nomme (``fy_saisie`` du pied de poteau, dont le « Personnalisé »
    réduit la f_y saisie selon l'épaisseur — reprendre la f_y retenue la réduirait deux fois), sinon la valeur
    retenue (les six attaches prennent la saisie telle quelle)."""
    return m.get(champ + "_saisie", m.get(champ))


def _lire_saisie(cfg: Config, u: Dict, k: str, valeur):
    """(valeur normalisée, message) d'une saisie dans le champ ``k``."""
    f = cfg.E.CHAMPS[k]
    if f["t"] == "s" and list(f["o"]) == OUI_NON and isinstance(valeur, bool):
        return ("Oui" if valeur else "Non"), None
    if f["t"] == "s":
        s = str(valeur)
        if s not in f["o"]:
            return None, f"Option inconnue pour {_nom_champ(cfg, k)} : « {valeur} »"
        return s, None
    if f["t"] == "x":
        return ("" if valeur is None else str(valeur)), None
    if valeur is None or (isinstance(valeur, str) and not valeur.strip()):
        if k in cfg.dimensions or k in ("d0_u",) or k.endswith(("P_u", "S_u")) or k in ("fy_u", "fu_u", "bw_u"):
            return None, None
        return None, f"{_nom_champ(cfg, k)} : une valeur est attendue"
    x = C.lire_nombre(valeur)
    if x is None:
        return None, f"Nombre illisible : « {valeur} »"
    if k in COMPTES or k in cfg.entiers:
        if x < 1 or abs(x - round(x)) > 1e-9:
            return None, (f"{_nom_champ(cfg, k)} : un nombre entier ≥ 1 est attendu (« {valeur} » ; l'écran Streamlit "
                          f"l'arrondirait en silence)")
        if x > COMPTES_MAXI.get(k, x):
            return None, f"{_nom_champ(cfg, k)} : {COMPTES_MAXI[k]} au plus (« {valeur} »)"
        return float(round(x)), None
    if POSITIVES.match(k) and x <= 0:
        return None, f"{_nom_champ(cfg, k)} : une valeur strictement positive est attendue"
    if x < 0 and k not in SIGNEES:
        return None, f"{_nom_champ(cfg, k)} : une valeur positive ou nulle est attendue (« {valeur} »)"
    return x, None


def _nom_champ(cfg: Config, k: str) -> str:
    lab = cfg.libelles.get(k)
    if lab:
        return re.sub(r"<[^>]+>", "", (lab[0] + " " + lab[1]).strip())
    f = cfg.E.CHAMPS.get(k)
    return f["l"] if f else k


def modifier(etat: Dict, chemin: Sequence, valeur) -> Optional[str]:
    """Une saisie dans l'assemblage ouvert. ``chemin`` : [« type »] (le menu Configuration), [« v », clé] (une donnée
    du moteur), [« v », liste, …] (les tables du calcul à la main), [« visserie »], [« cotation »], [« d0_impose »],
    [« exemple »], [« reinitialiser »] ; et [« note_taux »], une option de la NOTE (les taux dans sa note de calcul PDF).
    Rend un message si la saisie est refusée — l'assemblage reste intact."""
    el = _actif(etat)
    cfg = _cfg(el)
    chemin = [int(c) if isinstance(c, str) and c.lstrip("-").isdigit() and c != "-" else c for c in chemin]
    if chemin == ["nom"]:                         # la ligne de l'élément (établi compact) : son nom est le REPÈRE
        chemin = ["v", "id_rep"]
    tete = chemin[0] if chemin else None
    if chemin == ["type"]:
        return _changer_configuration(etat, valeur)
    if chemin == ["visserie"]:
        el["visserie"] = "" if valeur is None else str(valeur)
        return None
    if chemin == ["cotation"]:
        x = C.lire_nombre(valeur)
        if x is None or x not in (0, 1, 2):
            return f"Niveau de cotation inconnu : « {valeur} »"
        el["cotation"] = int(x)
        return None
    if chemin == ["note_taux"]:
        etat["note_taux"] = bool(valeur)
        return None
    if chemin == ["d0_impose"]:
        return _d0_impose(cfg, el["values"], bool(valeur))
    if chemin == ["exemple"]:
        return _charger_exemple(cfg, el, valeur)
    if chemin == ["reinitialiser"]:
        return _reinitialiser(cfg, el)
    if chemin == ["solution"]:                    # « Appliquer » du bloc « À corriger » : la proposition nommée est recopiée
        if not cfg.predim:
            return "Cette configuration n'a pas de solutions à proposer."
        try:
            choisir_solution(cfg, el["values"], "" if valeur is None else str(valeur))
        except ValueError as e:
            return f"Solution refusée : {e}"
        return None
    if tete in cfg.actions:                       # un état d'écran de la configuration (pied : la grille à poser)
        return cfg.actions[tete](cfg, el, chemin[1:], valeur)
    if tete != "v" or len(chemin) < 2:
        return f"Champ inconnu : {'/'.join(str(c) for c in chemin)}"
    u = el["values"]
    k = chemin[1]
    if k in cfg.listes:
        avant = copy.deepcopy(u[k])
        try:
            msg = cfg.listes[k]["modifier"](u, chemin[2:], valeur)
        except (ValueError, KeyError, IndexError, TypeError) as e:
            msg = f"Saisie refusée : {e}"
        if msg:
            u[k] = avant
        return msg
    if k not in cfg.E.CHAMPS or len(chemin) != 2:
        return f"Champ inconnu : {'/'.join(str(c) for c in chemin)}"
    x, msg = _lire_saisie(cfg, u, k, valeur)
    if msg:
        return msg
    if k == "mode_calc" and x != MODE_VERIF:      # (une page d'avant le 25/11/2026 : la bascule n'existe plus)
        return "Le mode prédimensionnement n'existe plus : les propositions s'ouvrent depuis le résultat (bloc « Prédimensionnement »)."
    if k in cfg.sur_saisie:                       # pied : la bascule de mode reprend la disposition
        return cfg.sur_saisie[k](cfg, el, x)
    ancien = u.get(k)
    u[k] = x
    if x == PERSO and ancien != PERSO:
        if k in PERSO_PROFIL or k == "corn_u":
            _reprendre_profil(cfg, u, k, ancien)
        elif k.startswith("nu_"):
            _reprendre_acier(cfg, u, k, ancien)
    return None


def _d0_impose(cfg: Config, u: Dict, oui: bool) -> Optional[str]:
    """La case « trou imposé » : décochée, d0 est vide (trou normal du boulon, Tab. 3.3) ; cochée, d0 part du trou
    normal du boulon retenu, à modifier (un d0 déjà saisi est gardé)."""
    if "d0_u" not in u:
        return None
    if not oui:
        u["d0_u"] = None
        return None
    if not (u.get("d0_u") or 0) > 0:
        try:
            u["d0_u"] = float(find(DB["boulons"], u.get("boulon_u"))["d0"])
        except (ValueError, KeyError, TypeError):
            u["d0_u"] = None
    return None


def _reinitialiser(cfg: Config, el: Dict) -> None:
    """« 🔄 Réinitialiser » de l'écran Streamlit (``interface._reinitialiser`` puis ``projet_ui.entree_reinitialisee``) :
    les valeurs par défaut de la configuration et la visserie par défaut ; le repère est gardé."""
    rep = el["values"].get("id_rep")
    el["values"] = valeurs_defaut(cfg)
    el["values"]["id_rep"] = rep
    el["visserie"] = cfg.visserie_defaut
    el.update(_etat_ecran(cfg))


def exemples(cfg: Config) -> List:
    """Les exemples à charger : [(id, libellé, saisies brutes)] — ceux de la configuration (``Config.exemples``), ou
    les exemples publiés de son benchmark (les défauts, puis les données de l'exemple)."""
    if cfg.exemples:
        return list(cfg.exemples())
    out = []
    for x in (getattr(cfg.bench, "BENCH", None) or []):
        d = cfg.E.defaults()
        d.update(x["inp"])
        out.append((x["id"], f"{x['id']} · {x['titre'][:40]}", d))
    return out


def _charger_exemple(cfg: Config, el: Dict, valeur) -> Optional[str]:
    """« Charger ces données dans l'outil » (onglet Benchmark de Streamlit) : les saisies de l'exemple (``exemples``)
    ; le repère est gardé."""
    if valeur in ("", None):
        return None
    ex = {i: d for i, _lab, d in exemples(cfg)}
    if valeur not in ex:
        return f"Exemple inconnu : « {valeur} »"
    d = copy.deepcopy(ex[valeur])
    rep = el["values"].get("id_rep")
    el["values"] = valeurs_normales(cfg, d)
    el["values"]["id_rep"] = rep
    return None


def choisir_section(etat: Dict, role: str, nom: str) -> None:
    """La ligne choisie dans un sélecteur : un boulon, un profilé, une cornière, une solution du prédimensionnement."""
    el = _actif(etat)
    cfg = _cfg(el)
    u = el["values"]
    sel = _selecteurs(cfg).get(role)
    if sel is None:
        raise ValueError(f"sélecteur inconnu : {role}")
    sel["choisir"](cfg, u, nom)


# ===================================================================== le texte : symboles et formules
_STOP = {"max", "min", "avec", "et", "si", "sinon", "ou", "sur", "sous", "par", "pour", "les", "des", "une", "un", "le",
         "la", "du", "de", "en", "au", "aux", "dans", "net", "brut", "Oui", "Non", "mm", "cm", "kN", "kNm", "MPa", "kg",
         "sqrt", "abs", "cos", "sin", "tan", "ln", "exp", "lim", "file", "files", "plat", "flexion", "limite",
         "domaine", "Valide", "valeur", "selon", "entre", "via", "tout", "tous", "deux", "soit", "est", "sans", "non",
         "cas", "pas", "and", "EN", "Tab", "MSB", "SCI", "ECCS", "ANB", "ELU", "ELS", "base", "bord", "haut", "bas",
         "trou", "rangs", "rang", "vers", "face", "aile", "ailes", "kN·m", "pb", "py",
         # des mots français des formules poutre–poteau et pied de poteau que la règle prenait pour des symboles
         # (« aucun bord libre » s'écrivait a_ucun bord l_ibre)
         "aucun", "aucune", "libre", "paroi", "mode", "plan", "plans", "bande", "zone", "pince", "ligne", "due", "son",
         "ne", "qu", "exact", "effet", "plus", "gauge", "tige", "tiges", "seul", "coin", "pry", "out", "objet", "bout",
         "se", "sa", "raidie", "donc",
         # pied de poteau : les profilés nommés (HEA 300 s'écrivait H_EA 300) et « au nu de la paroi »
         "HEA", "HEB", "HEM", "HEAA", "IPE", "RHS", "SHS", "CHS", "UPN", "UPE", "nu", "plat", "rond"}
_JETON = re.compile(r"(?<![\w.,])([A-Za-zσητγαμ])([A-Za-z0-9]+(?:,[A-Za-z0-9]+)*)(?![\w(])")


def indices(s: str) -> str:
    """La notation des assemblages (« Fv,Rd », « γM2 », « fub », « tp ») écrite pour C.symb_math (« F_v,Rd »,
    « γ_M2 », « f_ub », « t_p ») : la première lettre d'un symbole est sa base, le reste son indice. Les mots
    français, les unités et les fonctions restent tels quels."""
    def rep(m):
        base, reste = m.group(1), m.group(2)
        mot = base + reste
        if mot in _STOP or mot.lower() in _STOP:
            return mot
        if len(reste) > 4 and not re.search(r"[,0-9A-Z]", reste):
            return mot
        return base + "_" + reste
    s = re.sub(r"(?<![\w.,])([A-Z]),(Ed|Rd)(?!\w)", r"\1\2", s or "")      # « F,Ed » du moteur : F_Ed
    # un exposant (« Fz² ») n'empêche pas l'indice : il est mis de côté le temps de la règle (² et ³ sont des \w)
    s = s.replace("²", "\x01").replace("³", "\x02")
    return _JETON.sub(rep, s).replace("\x01", "²").replace("\x02", "³")


def math_html(s: str) -> str:
    """Un symbole ou une expression du moteur, écrit en HTML avec ses indices (texte échappé)."""
    return C.symb_math(indices(s))


def lignes_texte(R, c, textes: Callable) -> (str, List[Dict]):
    """Le détail d'une vérification dont le moteur compose les formules en TEXTE (``formules.textes`` de la
    famille : formule générale, valeurs introduites, « η = Ed / Rd = … ») → (la formule générale en clair, les
    lignes « symbole = valeur » et la ligne du taux)."""
    t = textes(R, c)
    formule, vals, eta = (t[0] if t else ""), (t[1] if len(t) > 2 else ""), (t[-1] if t else "")
    lignes = []
    for morceau in re.split(r"\s+;\s+|\s+→\s+", vals or ""):
        morceau = morceau.strip().rstrip(".")
        if not morceau:
            continue
        if " = " in morceau:
            g, d = morceau.split(" = ", 1)
            lignes.append({"parts": [indices(g.strip())], "res": d.strip(), "niveau": ""})
        elif " : " in morceau:
            g, d = morceau.split(" : ", 1)
            lignes.append({"parts": [g.strip()], "res": d.strip(), "niveau": ""})
        else:
            lignes.append({"parts": [indices(morceau)], "res": "", "niveau": ""})
    m = re.match(r"η = (.+?) = ([^=]+?)\s*(?:≤|>) 100 %$", eta or "")
    if m:
        lignes.append({"parts": ["η", m.group(1)], "res": f"{C.pc(taux_c(c, 1))} %", "niveau": niveau_c(c)})
    else:
        lignes.append({"parts": ["η"], "res": f"{C.pc(taux_c(c, 1))} %", "niveau": niveau_c(c)})
    return formule, [li for li in lignes if li["res"] != "" or len(li["parts"]) > 1]


def lignes_sub(R, c, F) -> (str, List[Dict]):
    """Le détail d'une vérification dont le moteur compose des SUBSTITUTIONS (``formules.lignes`` : « Fv,Rd =
    αv·fub·A/γM2 = 0,6 × 800 × 245/1,25/10³ = 94,08 kN ») → les lignes de C.lignes_fx, telles quelles."""
    L = F.lignes(R, c)
    if not L:
        return lignes_texte(R, c, F.textes)
    out = []
    for ligne in L:
        for s in ligne:
            parts, res = F.morceaux(s)
            parts = [indices(p) for p in parts]
            if s.nom == "η":
                out.append({"parts": parts, "res": f"{C.pc(taux_c(c, 1))} %", "niveau": niveau_c(c)})
            else:
                out.append({"parts": parts, "res": res, "niveau": ""})
    return c.formula, out


def taux(eta, nd: int = 0):
    """Un taux du moteur à afficher (C.pct), plafonné à 999 % : un taux infini ou indéterminé (pied de poteau :
    aucune épaisseur ne suffit, η = ∞ — l'écran Streamlit écrit « > 999 % ») reste rouge au lieu d'arrêter l'écran."""
    if not isinstance(eta, (int, float)) or not math.isfinite(eta) or eta > 9.99:
        return C.pct(9.99, nd)
    return C.pct(eta, nd)


def eta_vu(eta, ok: bool = True):
    """Le taux à MONTRER : celui du moteur, sauf qu'un taux que le moteur déclare vérifié ne passe pas 100 %. Le
    moteur admet η ≤ 1 + 10⁻⁹ (``c.ok``, l'arrondi des flottants : une gorge égale à la gorge minimale, un effort
    pile à la résistance) et l'écran Streamlit écrit alors « 100,0 % · VÉRIFIÉ » ; sans cette borne, le site écrivait
    « 101 % » en rouge, « Non conforme », à côté de « E<sub>d</sub> ≤ R<sub>d</sub »."""
    if ok and isinstance(eta, (int, float)) and math.isfinite(eta) and eta > 1:
        return 1.0
    return eta


def taux_c(c, nd: int = 1):
    """Le taux affiché d'une vérification (``eta_vu`` puis ``taux``)."""
    return taux(eta_vu(c.eta, c.ok), nd)


def eta_R(R):
    """Le taux affiché d'un assemblage : son η max, borné à 100 % quand sa vérification gouvernante est vérifiée ; une
    pince ou un entraxe NON conforme (Tableau 3.3) le porte au moins à son propre rapport. Le moteur qui trouve la
    géométrie non valide ne calcule plus les résistances qui en dépendent : pied de poteau « à la main », une tige à
    30 mm du bord pour 1,2·d₀ = 31,2 mm, son η max tombait à 0,03 % et la tête de la note écrivait « 0 % » à côté de
    « Non conforme », quand la ligne « Géométrie » disait 104 %."""
    g = R.get("gov")
    eta = eta_vu(R.eta_max, g.ok if g is not None else bool(R.verified))
    p = _pince_ko(R)
    if p is not None:
        t = _taux_distance(p)
        if not isinstance(eta, (int, float)) or (math.isfinite(eta) and t > eta):
            return t
    return eta


def _pince_ko(R):
    """La pince ou l'entraxe non conforme le plus défavorable (Tableau 3.3), ou None."""
    ko = [x for x in (R.get("dist") or []) if not x.ok]
    return max(ko, key=_taux_distance) if ko else None


def _cause_geometrie(R):
    """La géométrie quand c'est ELLE qui gouverne, sinon None : (titre, détail). Une pince non conforme dont le rapport
    dépasse le η du moteur ; ou, sans pince en cause, une alerte bloquante (élément hors platine, boulon dans
    l'emprise d'un élément…) quand le moteur n'a rien trouvé au-delà de 100 % — la tête nomme alors la vraie cause
    au lieu d'une vérification satisfaite (« Trous · pression diamétrale 0,2 kN ≤ 535,8 kN »)."""
    if R.get("dist_ok", True) and R.get("geo_ok", True):
        return None
    g = R.get("gov")
    eta = eta_vu(R.eta_max, g.ok if g is not None else bool(R.verified))
    fini = isinstance(eta, (int, float)) and math.isfinite(eta)
    p = _pince_ko(R)
    if p is not None and fini and _taux_distance(p) >= eta:
        regle = f" ({C.esc(p.rule)})" if getattr(p, "rule", "") else ""
        cmp_ = f"{C.fr(p.val, 1)} mm &lt; {C.fr(p.min, 1)} mm" if p.min and p.val < p.min else \
            (f"{C.fr(p.val, 1)} mm &gt; {C.fr(p.max, 1)} mm" if p.max else "")
        return f"Géométrie · {_minuscule(p.lab)}", f"{cmp_}{regle}"
    if p is None and fini and eta <= 1:
        bloc = [a for a in (R.get("alerts") or []) if getattr(a, "block", False)]
        if bloc:
            a = bloc[0]
            return "Géométrie non valide", C.esc(a.msg) + (f" · {C.esc(a.why)}" if getattr(a, "why", "") else "")
    return None


def niveau_c(c) -> str:
    """La couleur d'une vérification : son taux, rouge dès que le moteur la déclare non vérifiée."""
    return "r" if not c.ok else C.niveau(eta_vu(c.eta))


def niveau_R(R) -> str:
    """La couleur d'un assemblage : son taux maximal, rouge dès que le moteur ne le déclare pas vérifié (géométrie,
    pinces, alerte bloquante) même sous 100 % ; orange « À vérifier » quand le moteur nomme une raison
    (``R.a_verifier`` : pied de poteau, un contrôle HORS PÉRIMÈTRE au-delà de 100 % — brief v12 § 19.1 point 4), jamais
    « Conforme »."""
    if not R.verified:
        return "r"
    return "v" if R.get("a_verifier") else C.niveau(eta_R(R))


def tableau(entetes: Sequence[str], lignes: Sequence[Sequence[str]], droite: Sequence[int] = (), classe: str = "") -> str:
    """Un tableau de la charte (classe vtab) ; les cellules sont déjà du HTML."""
    th = "".join(f'<th class="{"n" if i in droite else ""}">{h}</th>' for i, h in enumerate(entetes))
    tr = "".join("<tr>" + "".join(f'<td class="{"n" if i in droite else ""}">{x}</td>' for i, x in enumerate(li)) + "</tr>"
                 for li in lignes)
    return f'<table class="vtab {classe}"><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>'


# ===================================================================== le cadre Données
def _unite(f: Dict) -> str:
    un = f.get("un") or ""
    return UNITES.get(un, un)


def _aide(f: Dict, cfg: Optional[Config] = None, u: Optional[Dict] = None) -> str:
    """L'aide d'un champ : le libellé long et l'aide de l'écran Streamlit (entrees.GROUPES, source unique) — ou,
    quand la configuration les porte (``Config.aides`` : les « ? » de la carte Streamlit), celle-là."""
    t = f.get("l") or ""
    aides = (cfg.aides(u or {}) if callable(cfg.aides) else cfg.aides) if cfg is not None and cfg.aides else {}
    h = aides.get(f["k"]) or f.get("h")
    if f["k"] in dict(PERSO_ACIER):
        h = (h + " ; " if h else "") + AIDE_PERSO_ACIER
    if h:
        t += " — " + h
    return t


def champ(cfg: Config, u: Dict, k: str, plein: Optional[bool] = None, libelle=None) -> str:
    """Une ligne de saisie pour la clé ``k`` du moteur : symbole et libellé courts, aide = libellé long de l'écran
    Streamlit, le champ selon le type (nombre, choix, texte). ``libelle`` (symbole, libellé) : celui du mode (pied de
    poteau : « Tige » ou « Boulon »)."""
    f = cfg.E.CHAMPS[k]
    sym, lab = libelle or cfg.libelles.get(k, ("", f["l"]))
    v = u.get(k)
    if f["t"] == "s":
        aff = cfg.affichage.get(k, {})
        opts = [(o, aff.get(o, o)) for o in f["o"]]
        if list(f["o"]) == OUI_NON:
            return C.case(["v", k], v == "Oui", (sym + " " if sym else "") + lab)
        if k in cfg.segments:
            return C.ligne(lab, C.segments(["v", k], v, opts), sym, _aide(f, cfg, u), full=True)
        large = plein if plein is not None else max(len(t) for _, t in opts) > 15
        return C.ligne(lab, C.choix(["v", k], v, opts), sym, _aide(f, cfg, u), full=large)
    if f["t"] == "x":
        return C.ligne(lab, C.texte(["v", k], v, ""), sym, _aide(f, cfg, u), full=True)
    entier = k in COMPTES or k in cfg.entiers
    return C.ligne(lab, C.num(["v", k], v, _unite(f), dec=3, entier=entier, mini=1 if entier else None), sym, _aide(f, cfg, u))


def _options(cfg: Config, k: str) -> List:
    aff = cfg.affichage.get(k, {})
    return [(o, aff.get(o, o)) for o in cfg.E.CHAMPS[k]["o"]]


def _cellule(cfg: Config, u: Dict, k: str):
    """(libellé court en HTML, champ, aide) de la clé ``k`` pour une ligne à DEUX champs (``commun.ligne2``) : son
    symbole quand elle en a un — celui que le dessin cote, « p₁ », « e₂,b » —, sinon son libellé ; le libellé long et
    l'aide de l'écran Streamlit au survol de ⓘ. None pour une case à cocher (elle garde sa ligne)."""
    f = cfg.E.CHAMPS[k]
    sym, lab = cfg.libelles.get(k, ("", f["l"]))
    v = u.get(k)
    if f["t"] == "s":
        if list(f["o"]) == OUI_NON:
            return None
        ctl = C.segments(["v", k], v, _options(cfg, k)) if k in cfg.segments else C.choix(["v", k], v, _options(cfg, k))
    elif f["t"] == "x":
        ctl = C.texte(["v", k], v, "")
    else:
        entier = k in COMPTES or k in cfg.entiers
        ctl = C.num(["v", k], v, _unite(f), dec=3, entier=entier, mini=1 if entier else None)
    return (sym or lab), ctl, _aide(f, cfg, u)


def ligne_profil(cfg: Config, u: Dict, titre: str, k_prof: str, k_nu: str) -> str:
    """Une PIÈCE et son ACIER sur UNE ligne (le propriétaire, 25/11/2026 : « quand on a le nom du profilé principal, on
    a la qualité de l'acier juste à côté, sur une seule ligne ») : le nom de la pièce, son profilé (ou sa cornière), sa
    nuance. L'aide ⓘ dit les deux libellés longs de l'écran Streamlit."""
    fp, fn = cfg.E.CHAMPS[k_prof], cfg.E.CHAMPS[k_nu]
    aide = _aide(fp, cfg, u) + " · " + _aide(fn, cfg, u)
    a = f'<span class="aide" title="{C.esc(aide)}">{C.icon("info")}</span>'
    return (f'<div class="row2 asm-profil"><label><span>{C.esc(titre)}</span>{a}</label>'
            f'{C.choix(["v", k_prof], u.get(k_prof), _options(cfg, k_prof))}'
            f'{C.choix(["v", k_nu], u.get(k_nu), _options(cfg, k_nu))}</div>')


def _grp(titre: str, aide: str = "") -> str:
    """Un titre de groupe du cadre Données. Son ``aide`` (HTML ou texte) ne prend plus un paragraphe de la colonne
    compacte : elle se lit sous ⓘ, au survol ou au toucher (js/etabli.js) — en texte, les indices à plat (« p3 »)."""
    if not aide:
        return f'<div class="grp">{titre}</div>'
    plat = html.unescape(re.sub(r"<[^>]+>", "", aide))
    return f'<div class="grp">{titre} <span class="aide" title="{C.esc(plat)}">{C.icon("info")}</span></div>'


def champs(cfg: Config, u: Dict, cles: Sequence[str]) -> str:
    """Les champs visibles (``entrees.champ_visible``, les conditions de l'écran Streamlit) parmi ``cles``. Aucun n'est
    verrouillé : l'écran du site est toujours en vérification (``sans_mode_predim``)."""
    def vu(cle):
        return cle in cfg.E.CHAMPS and cfg.E.champ_visible(u, cle)

    out = ""
    for k in cles:
        if isinstance(k, tuple) and k[0] == "lib":        # un champ sous le libellé de son mode : ("lib", clé, (sym, lab))
            _g, cle, lab = k
            if vu(cle):
                out += champ(cfg, u, cle, libelle=lab)
            continue
        if isinstance(k, tuple) and k[0] == "duo":        # DEUX champs sur une ligne : ("duo", clé, clé) — un seul visible : sa ligne
            vus = [c for c in k[1:] if vu(c)]
            cells = [_cellule(cfg, u, c) for c in vus]
            if len(vus) == 2 and all(cells):
                out += C.ligne2(*cells)
            else:
                out += "".join(champ(cfg, u, c) for c in vus)
            continue
        if isinstance(k, tuple) and k[0] == "profil":     # une pièce et son acier sur une ligne : ("profil", nom, profilé, nuance)
            _g, titre, kp, kn = k
            if vu(kp) and vu(kn):
                out += ligne_profil(cfg, u, titre, kp, kn)
            else:
                out += "".join(champ(cfg, u, c) for c in (kp, kn) if vu(c))
            continue
        if isinstance(k, tuple):
            genre, x = k[0], k[1]
            if genre == "grp":                             # ("grp", titre) ou ("grp", titre, aide)
                out += _grp(x, k[2] if len(k) > 2 else "")
            elif genre == "aide":
                out += C.aide(x)
            elif genre == "html":
                out += x
            continue
        if vu(k):
            out += champ(cfg, u, k)
    return out


def _menu_configuration(el: Dict) -> str:
    """Le menu « Configuration » : les sept attaches du registre, sur toute la largeur du cadre (« Poutre – Poutre ·
    Platine d'about » ne tient pas à côté d'un libellé)."""
    opts = []
    for f in RG.FAMILLES:
        for a in f.assemblages:
            if a.id in CONFIGS:
                opts.append((a.id, f"{f.titre} · {CONFIGS[a.id].nom_menu or a.court or a.titre}"))
    aide = ("Les sept attaches du registre des assemblages (EN 1993-1-8) : poutre–poutre, poutre–poteau (aile ou "
            "âme), pied de poteau sur béton. Les saisies communes (profilés, boulons, efforts) suivent dans la même famille.")
    return _grp("Configuration", aide) + f'<div class="asm-config">{C.choix(["type"], el["type"], opts)}</div>'


def formulaire(etat: Dict, R=None) -> str:
    """Le cadre Données : la configuration en tête, puis les rubriques de la configuration (leurs numéros et leurs clés
    sont ceux de la famille) — la première seule ouverte ; « Options » secondaire. Le REPÈRE de l'assemblage n'y est
    plus : il se modifie sur sa ligne, en tête de la colonne."""
    el = _actif(etat)
    cfg = _cfg(el)
    u = el["values"]
    out = ""
    # (l'option de la NOTE que la rubrique « Options » montre : passée aux sections avec l'assemblage, sans y être écrite)
    vu = dict(el, _note_taux=etat.get("note_taux", True) is not False)
    for n, (cle, titre, resume, items, _ouvert) in enumerate(cfg.sections(u, R, vu), start=1):
        corps = champs(cfg, u, [k for k in items if k != "id_rep"])
        if n == 1:
            corps = _menu_configuration(el) + corps
        if corps:
            out += C.section(n, titre, resume, corps, n == 1, cle, secondaire=cle in SECONDAIRES)
    return out


def _dims(el: Dict) -> str:
    """« · Plat d'âme » : ce qu'on lit d'un assemblage dans la liste de la note (HTML)."""
    return f"· {C.esc(_cfg(el).court)}"


def arbre(etat: Dict, R=None) -> str:
    """La colonne de gauche COMPACTE (api_web/etabli_compact.arbre_compact, la même que la poutre) : la ligne de
    l'assemblage ouvert (son repère, qu'un clic modifie ; la liste des assemblages de la note ; copier, supprimer), que
    l'écran pose dans l'en-tête du panneau, puis les rubriques de sa configuration."""
    noms = [(_repere(e, i), _dims(e), False) for i, e in enumerate(etat["assemblages"])]
    return E.arbre(GENRE, noms, etat["actif"], formulaire(etat, R), "assemblage", compact=True)


# ce que la case de la note dit (« Options », toutes les configurations) — le propriétaire, 25/11/2026 : « si je dimensionne
# tout, je n'ai pas envie qu'on voie en un clin d'œil que j'ai dimensionné tout à 60 %. Mais je veux pouvoir l'afficher »
LIBELLE_NOTE_TAUX = "Afficher les taux (%) dans la note de calcul"
AIDE_NOTE_TAUX = ("Décochée : la note PDF garde chaque effort, chaque résistance et chaque verdict, sans aucun pourcentage. "
                  "Vaut pour toute la note (tous ses assemblages).")


def section_options(cfg: Config, u: Dict, el: Dict, coefficients: Sequence = (), avec_visserie: bool = True,
                    libelle_visserie: str = "Visserie", aide_visserie: str = "") -> tuple:
    """La rubrique « Options », la dernière et la seule secondaire (le propriétaire, 25/11/2026 : « ta cartouche,
    affichage, coefficients, modèle : moi, je mettrais plutôt ça dans un truc d'option ») : les ``coefficients`` et le
    modèle de la configuration ; les règles du prédimensionnement (taux cible, diamètres admis, pinces k·d0) quand
    elle en a un ; la NOTE de calcul (afficher ou non les taux) ; le cartouche (rédacteur, visserie, projet, date) ;
    les dessins (niveau de cotation) ; les exemples publiés à charger et le retour aux valeurs par défaut."""
    items = list(coefficients)
    if cfg.predim:
        # (l'écran Streamlit ne montre ces règles qu'en mode prédimensionnement — ``entrees.champ_visible`` ; le site, qui
        #  n'a plus ce mode, les montre toujours : elles règlent les propositions)
        # (26/11/2026 : plus de plage de diamètres « Ø min – Ø max » — les propositions parcourent tout le catalogue des
        #  boulons et rendent une solution par diamètre qui convient, ``chercher_solutions``)
        items += [("grp", "Prédimensionnement", "Les règles des solutions proposées : le taux à tenir, les pinces et entraxes "
                                               "de détail (k · d0). Tous les diamètres du catalogue sont essayés. Une solution "
                                               "ne change jamais un effort, un profilé, un acier, un niveau ni le grugeage."),
                  ("html", champ(cfg, u, "eta_c")),
                  ("html", C.ligne2(_cellule(cfg, u, "k_e1"), _cellule(cfg, u, "k_p1"))),
                  ("html", champ(cfg, u, "k_e2"))]
    items += [("grp", "Note de calcul"),
              ("html", C.case(["note_taux"], el.get("_note_taux", True) is not False, LIBELLE_NOTE_TAUX)),
              ("aide", AIDE_NOTE_TAUX),
              ("grp", "Cartouche"), "id_red"]
    if avec_visserie:
        items.append(("html", C.ligne(libelle_visserie, C.texte(["visserie"], el.get("visserie"), cfg.visserie_defaut), "",
                                      aide_visserie or "Rondelles et écrous par boulon, portés au cartouche du plan. Ex. : "
                                      "« 1 rondelle + 2 écrous (contre-écrou) ».", full=True)))
    items += ["id_projet", "id_date", ("grp", "Dessins")]
    items.append(("html", C.ligne("Cotes", C.segments(["cotation"], str(el.get("cotation", 1)), NIVEAUX_COTATION), "",
                                  "Niveau de cotation des dessins : vue simple, édition (toutes les cotes saisies), "
                                  "cotations complètes (grandeurs calculées comprises).", full=True)))
    ex = exemples(cfg)
    if ex:
        opts = [("", "—")] + [(i, lab) for i, lab, _d in ex]
        items += [("grp", "Exemples publiés" if not cfg.exemples else "Exemples et cas de validation"),
                  ("html", C.ligne("Charger", C.choix(["exemple"], "", opts), "",
                                   "Remplace les données par celles d'un exemple publié ; le repère est gardé.", full=True))]
    items.append(("html", f'<button type="button" class="addrow" data-chemin="reinitialiser" data-valeur="1" title="Le repère est gardé">{C.icon("history")}'
                          'Rétablir les valeurs par défaut</button>'))
    return ("op", "Options", "coefficients · note · cartouche", items, False)


def d0_items(u: Dict) -> List:
    """La case du trou imposé, puis d0 s'il est imposé (Streamlit : un champ vide = trou normal)."""
    if "d0_u" not in u:
        return []
    oui = (u.get("d0_u") or 0) > 0
    out = [("html", C.case(["d0_impose"], oui, "Trou de diamètre d<sub>0</sub> imposé (sinon trou normal, Tab. 3.3)"))]
    if oui:
        out.append("d0_u")
    return out


# ===================================================================== le résultat
SANS_TAUX_INFORMATION = "hors verdict"   # ce qu'une ligne d'information porte à la place d'un taux (_resultat)


def information(cfg: Config, R, c) -> bool:
    """Une vérification affichée EN INFORMATION, hors verdict (pied de poteau : béton d'ancrage EN 1992-4 quand le
    périmètre est l'EN 1993-1-8 seule, niveau 2, pression maximale — ``synthese.info``) : elle ne colore ni sa pièce
    ni le verdict, comme dans l'écran Streamlit."""
    f = getattr(cfg.S, "info", None)
    return bool(f and f(R, c.key))


def _groupes(cfg: Config, R) -> List:
    """Les pièces vérifiées (synthese.ELEMENTS) : (groupe, nom, η, ok, pire, [vérifications actives], information).
    Le taux d'une pièce est celui que synthese.taux_par_element nomme ; une pièce qui n'a que des vérifications
    d'information est une ligne d'information (grise), hors verdict."""
    out = []
    par = cfg.S.taux_par_element(R)
    for grp, _court in cfg.S.ELEMENTS:
        on = [c for c in R.checks if c.grp == grp and c.active]
        if not on:
            continue
        utiles = [c for c in on if not information(cfg, R, c)]
        if not utiles:
            pire = max(on, key=lambda c: c.eta)
            out.append((grp, grp, pire.eta, True, pire, on, True))
            continue
        t = next((x for x in par if x[3] in utiles), None)
        pire = t[3] if t else max(utiles, key=lambda c: c.eta)
        out.append((grp, grp, pire.eta, all(c.ok for c in utiles), pire, on, False))
    return out


def _slug(s: str) -> str:
    import unicodedata
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-") or "g"


def _court(cfg: Config, c) -> str:
    return cfg.S.court(c)


def _comparaison(cfg: Config, c) -> str:
    ed, rd, un = cfg.S.ed_rd(c)
    u = f" {un}" if un else ""
    return f"{ed}{u} {'≤' if c.ok else '&gt;'} {rd}{u}"


def premiere_formule(f) -> str:
    """La formule principale d'une vérification : son texte jusqu'au premier « ; » ou « — » HORS parenthèses (« tp ≥
    max(tT ; tS ; tc ; tb) — … » garde sa parenthèse entière)."""
    f = f or ""
    prof = 0
    for i, ch in enumerate(f):
        prof += (ch == "(") - (ch == ")")
        if prof <= 0 and (f.startswith(" ; ", i) or f.startswith(" — ", i)):
            return f[:i]
    return f


def _ligne_vtab(cfg: Config, c, gov: bool, R=None) -> Dict:
    ed, rd, un = cfg.S.ed_rd(c)
    u = f" {un}" if un else ""
    form = premiere_formule(c.formula)
    sous = C.esc(c.nat) + " · " + C.esc(cfg.N.ref_courte(c.ref))
    info = R is not None and information(cfg, R, c)
    if info:
        sous += " · information, hors verdict"
    return {"nom": C.esc(_court(cfg, c)), "sous": sous, "formule": math_html(form), "valeur": f"{ed}{u}", "limite": f"{rd}{u}",
            "taux": taux(c.eta, 1) if info else taux_c(c, 1), "niveau": "c" if info else niveau_c(c), "gov": gov}


def _hypotheses(cfg: Config, R, u: Dict) -> List[str]:
    """Les hypothèses en pastilles : aciers, boulon, coefficients partiels."""
    h = []
    aciers = []
    noms = getattr(cfg, "noms_aciers", None) or {}           # poutre–poteau : « P » est le poteau, « S » la poutre portée
    for X, nom in (("P", "principale"), ("S", "secondaire"), ("L", getattr(cfg, "nom_plat", "plat")), ("C", "cornières"),
                   ("c", "poteau"), ("p", "platine")):
        nom = noms.get(X, nom)
        fy, fu = R.get("fy_" + X), R.get("fu_" + X)
        m = (R.get("materiau") or {}).get(X) or {}
        # la valeur RETENUE pour la pièce, avec l'épaisseur qui l'a décidée (tableau 3.3 ANB) ; « Personnalisé » : saisie
        ep = f" (t = {C.nb(m['t'])} mm)" if m.get("t") and m.get("nom") != PERSO else ""
        if fy:
            aciers.append(f"{nom} f<sub>y</sub> = {C.nb(fy)} · f<sub>u</sub> = {C.nb(fu)}{ep}" if fu
                          else f"{nom} f<sub>y</sub> = {C.nb(fy)}{ep}")
    if aciers:
        h.append("Aciers · " + " ; ".join(aciers) + " N/mm²")
    if R.get("boulon"):
        cl = u.get("classe") or ""
        d0 = R.get("d_0")
        h.append(f"Boulons <b>{C.esc(R.boulon)} {C.esc(cl)}</b>" + (f" · d<sub>0</sub> = {C.nb(d0)} mm" if d0 else "")
                 + (f" · f<sub>ub</sub> = {C.nb(R.f_ub)} N/mm²" if R.get("f_ub") else ""))
    gs = [(k, v) for k, v in u.items() if k.startswith("g_M") and v is not None and cfg.E.champ_visible(u, k)]
    if gs:
        h.append(" · ".join(f"γ<sub>{C.esc(k[2:].replace('n', ',net').replace('s', ',ser'))}</sub> = {C.nb(v)}" for k, v in gs))
    if cfg.hypotheses:                            # pied de poteau : les tiges et le béton
        h += cfg.hypotheses(R, u)
    return h


def perimetre(cfg: Config, R) -> str:
    """Ce que la vérification NE COUVRE PAS, au pied de chaque fenêtre de calcul (HTML) : les « non revérifiés » de la
    configuration (``Config.non_reverifies`` : les limites que l'écran Streamlit déclare) et le « sans objet » de ce
    cas. L'onglet « Méthode » de la toile, qui les portait, est retiré (25/11/2026) : une limite de validité ne
    disparaît pas avec son onglet."""
    sans = [_court(cfg, c) for c in R.checks if not c.active]
    # ce que l'écran Streamlit ajoute au « sans objet » (poutre–poteau sur l'aile : pourquoi l'aile n'est pas vérifiée)
    sans += list(getattr(cfg, "sans_objet", None) and cfg.sans_objet(R) or ())
    nr = non_reverifies(cfg, R)
    out = ""
    if nr:
        out += f"<br><b>{C.esc(cfg.titre_non_verifies or 'Non revérifiés ici')}</b> : {C.esc(' ; '.join(nr))}."
    if sans:
        out += f"<br>Sans objet dans cette configuration : {C.esc(' ; '.join(sans))}."
    return out


def volets(cfg: Config, R, u: Dict, el: Dict) -> str:
    """Les fenêtres de calcul : une par pièce (tableau des vérifications, détail des formules) et la géométrie
    (Tableau 3.3 et paramètres retenus)."""
    hyps = _hypotheses(cfg, R, u)
    out = ""
    limites = perimetre(cfg, R)
    for grp, nom, eta, ok, pire, on, info in _groupes(cfg, R):
        lignes = [_ligne_vtab(cfg, c, c is pire and not info, R) for c in on]
        detail = (cfg.blocs_tete(R, grp) or "") if cfg.blocs_tete else ""
        for c in on:
            aide, lf = cfg.formules(R, c)
            detail += (f'<div class="ck-g"><div class="ck-t">{C.esc(_court(cfg, c))} · {C.esc(c.nat)}</div>'
                       + (C.aide(math_html(aide)) if aide else "") + C.lignes_fx(lf) + "</div>")
        for titre, tab in (cfg.tableaux_boulons(R) if cfg.tableaux_boulons and grp == "Boulons" else []):
            if tab:
                detail += (f'<div class="ck-g asm-large"><div class="ck-t">Répartition élastique par boulon · {C.esc(titre)}</div>'
                           + tableau(["Rangée / file", "x (mm)", "y (mm)", "F<sub>x</sub> (kN)", "F<sub>z</sub> (kN)", "F (kN)"],
                                     [[f"{b.i} / {b.j}", C.fr(b.x, 1), C.fr(b.y, 1), C.fr(b.fx, 2), C.fr(b.fz, 2), f"<b>{C.fr(b.f, 2)}</b>"]
                                      for b in tab], droite=(1, 2, 3, 4, 5), classe="asm-tab") + "</div>")
        if cfg.blocs:
            detail += cfg.blocs(R, grp) or ""
        pied = f'<div class="ck-autres">{C.esc(cfg.N.LEGENDE_REFERENCES)}{limites}</div>'
        sous = f"{C.esc(cfg.court)} · {C.esc(_court(cfg, pire))} · {C.esc(cfg.normes.get(grp, 'EN 1993-1-8'))}"
        out += C.fenetre_calcul(_slug(grp), C.esc(nom), sous, hyps, lignes, detail, pied)
    out += _volet_geometrie(cfg, R, hyps)
    return out


def _taux_distance(x) -> float:
    """Le rapport d'une pince à sa limite (e,min / e, ou e / e,max), une PROJECTION pour la jauge et la couleur de la
    ligne du Tableau 3.3 (l'écran Streamlit n'y montre que ✓ / ✗) ; le verdict reste celui du moteur (``x.ok``)."""
    t = 0.0
    if x.min and x.val:
        t = max(t, x.min / x.val)
    elif x.min and not x.val:
        t = 9.99
    if x.max:
        t = max(t, x.val / x.max)
    # une pince que le moteur déclare conforme (sa tolérance : val ≥ min − 0,001 mm) ne passe pas 100 % : p₁ = 48,4 mm
    # pour 2,2·d₀ = 48,400000000000006 mm s'écrivait « 101 % » rouge, quand le Tableau 3.3 la dit conforme
    return min(t, 1.0) if x.ok else min(t, 9.99)


def _volet_geometrie(cfg: Config, R, hyps) -> str:
    dist = list(R.get("dist") or [])
    lignes = []
    for x in dist:
        t = _taux_distance(x)
        niv = "r" if not x.ok else C.niveau(t)
        lim = f"min {C.fr(x.min, 1)}" + (f" · max {C.fr(x.max, 0)}" if x.max is not None else "")
        regle = (x.rule or "").split(";")[0].strip()
        lignes.append({"nom": C.esc(x.lab), "sous": C.esc(x.rule), "formule": math_html(regle) if regle else "",
                       "valeur": f"{C.fr(x.val, 1)} mm", "limite": f"{lim} mm", "taux": C.pct(t, 1), "niveau": niv, "gov": not x.ok})
    params = cfg.parametres(R) if cfg.parametres else []
    detail = ""
    if params:
        detail = ('<div class="ck-g asm-large"><div class="ck-t">Paramètres retenus</div>'
                  + tableau(["Paramètre", "Valeur"], [[C.esc(a), f"<b>{C.esc(b)}</b>"] for a, b in params], droite=(1,), classe="asm-tab asm-param")
                  + "</div>")
    regle = getattr(cfg, "regle_33", None) or ("e ≥ 1,2·d<sub>0</sub> ; p<sub>1</sub> ≥ 2,2·d<sub>0</sub> ; "
                                                 "p<sub>2</sub> ≥ 2,4·d<sub>0</sub>")
    pied = (f'<div class="ck-autres">{regle} ; '
            'p ≤ min(14t ; 200 mm) ; e ≤ 4t + 40 mm si exposé (EN 1993-1-8 Tableau 3.3).</div>') if dist else ""
    if cfg.legende_33:                            # pied de poteau : la règle que l'écran écrit sous son Tableau 3.3
        pied = f'<div class="ck-autres">{cfg.legende_33}</div>'
    verdict = "conformes" if R.get("dist_ok", True) else "NON conformes"
    return C.fenetre_calcul("geometrie", "Géométrie · pinces et entraxes", f"Tableau 3.3 : {verdict} · paramètres retenus",
                            hyps, lignes, detail, pied)


def phrase_hors_table(err: str) -> Optional[str]:
    """La phrase d'une pièce au-delà du tableau de l'ANB (``err`` : l'erreur de ``calculer``, « HorsTable : … »), telle
    que le moteur l'a composée (la pièce, la nuance, l'épaisseur, la borne : ``acier/assemblages/materiau
    .refus_hors_table``), sans nom de classe Python ; None pour une autre erreur. L'écran (``motif_impossible``) et la
    note PDF (``note_assemblages._motif``) la lisent ici."""
    classe, sep, phrase = err.partition(" : ")
    return phrase if sep and classe == "HorsTable" else None


def motif_impossible(err: str) -> str:
    """Ce que le verdict écrit sous « Calcul impossible » (``err`` : l'erreur de ``calculer``, « Classe : message »).
    Une pièce au-delà du tableau de l'ANB (``HorsTable``) se dit par sa phrase (``phrase_hors_table``) ; un autre
    calcul impossible garde « Données incomplètes » et son motif (comme l'écran Streamlit)."""
    return phrase_hors_table(err) or "Données incomplètes : " + err


def _bilan(cfg: Config, el: Dict) -> Dict:
    """Le calcul d'un assemblage et son résumé (liste, note)."""
    refus = saisies_refusees(cfg, el["values"])
    R, vides, err = calculer(cfg, el)
    if err:
        return {"R": None, "taux": None, "niveau": "x", "statut": "Calcul impossible", "erreur": err, "vides": vides,
                "refus": refus}
    if vides or refus:
        return {"R": R, "taux": None, "niveau": "c", "statut": "À compléter" if vides else "À corriger", "erreur": None,
                "vides": vides, "refus": refus}
    niv = niveau_R(R)
    return {"R": R, "taux": eta_R(R), "niveau": niv, "statut": C.STATUTS[niv][1], "erreur": None, "vides": [], "refus": []}


def resume_note(etat: Dict, bilans: List[Dict]) -> Dict:
    """Le résumé de la NOTE : son assemblage le plus chargé ; un assemblage non vérifié sous 100 % (géométrie)
    passe devant un assemblage vérifié."""
    vals = [((b["niveau"] == "r", b["taux"]), i) for i, b in enumerate(bilans) if b["taux"] is not None]
    if not vals:
        b0 = bilans[etat["actif"]]
        return {"taux": None, "niveau": b0["niveau"], "statut": b0["statut"], "gouvernant": ""}
    _, i = max(vals)
    b = bilans[i]
    el = etat["assemblages"][i]
    cfg = pour(_cfg(el), b["R"])
    g = b["R"].gov
    cause = _cause_geometrie(b["R"])
    if cause is not None:
        gouv = f"{_repere(el, i)} · {cfg.court} · {cause[0]}"
    else:
        gouv = f"{_repere(el, i)} · {cfg.court}" + (f" · {g.grp} · {_court(cfg, g)}" if g else "")
    return {"taux": taux(b["taux"]), "niveau": b["niveau"], "statut": b["statut"], "gouvernant": gouv}


def elements(etat: Dict, bilans: List[Dict]) -> str:
    """Rien : les assemblages de la note sont la LIGNE de l'élément, en tête de la colonne de gauche (``arbre``)."""
    return ""


def _messages(cfg: Config, R, dites: frozenset = frozenset()) -> str:
    out = ""
    # « À vérifier » : le verdict dit la raison, l'avis du moteur (ancr_info, tige_info, fjd_info) dit quoi faire — la
    # phrase d'information la redirait (une seule fois à l'écran : brief v12, « pas de blabla »)
    note = None if (R.verified and R.get("a_verifier")) else getattr(cfg, "note_information", None)
    if note and note(R):
        out += C.message(C.esc(note(R)))
    # « À vérifier » (un contrôle hors périmètre au-delà de 100 % — pied de poteau) : la raison que le moteur nomme, dite
    # ici depuis que la tête ne porte plus de verdict
    if R.verified and R.get("a_verifier"):
        out += C.message(f"<b>À vérifier</b> — {C.esc(R.a_verifier)}")
    for a in R.alerts:
        if a.id in dites:                         # (déjà dite, avec ses retouches, dans le bloc « À corriger »)
            continue
        titre, det = cfg.N.ligne_alerte(a, R)
        out += C.message(f"<b>{C.esc(titre)}</b>" + (f" — {C.esc(det)}" if det else ""), grave=a.block)
    # « Vérifié sous réserve » ne s'écrit que d'un assemblage VÉRIFIÉ : sous « Non conforme » (une tige hors des
    # pinces), la phrase contredisait le verdict ; « À vérifier » (un contrôle hors périmètre au-delà de 100 %) : sa
    # raison est dans le verdict, elle ne se répète pas ici
    if R.get("reserve") and R.verified and not R.get("a_verifier"):
        out += C.message("Vérifié sous réserve : voir les remarques ci-dessus et la fenêtre de la pièce concernée.")
    return out


def _minuscule(s: str) -> str:
    """Un nom de vérification après « Pièce · » : sa première lettre en minuscule, le reste tel quel (« Ailes B – gorge
    minimale » → « ailes B – … » ; un ``lower()`` écrivait « ailes b », « groupe s », « tab. 3.3 »), un sigle intact."""
    if len(s) > 1 and s[1].isupper():
        return s
    return s[:1].lower() + s[1:]


def _rangee_geometrie(R, gov: bool = False) -> str:
    """La ligne « Géométrie » du résultat : le Tableau 3.3 (pinces et entraxes), conforme ou non selon le moteur ;
    marquée gouvernante quand c'est la géométrie qui gouverne (``_cause_geometrie``).

    Comme la ligne d'une pièce, elle dit CE QU'ELLE COMPARE dès qu'une distance n'est pas conforme : la pire, nommée,
    sa valeur et sa limite (« Platine – e2 (bord latéral) : 30,0 mm < 31,2 mm ») — depuis le 26/11/2026 la tête ne
    porte plus de verdict, et c'est lui qui l'écrivait ; conforme, le compte des distances vérifiées."""
    dist = list(R.get("dist") or [])
    t = max([_taux_distance(x) for x in dist] or [0.0])
    niv = "r" if not (R.get("dist_ok", True) and R.get("geo_ok", True)) else C.niveau(t)
    n = len(dist)
    txt = (f"{n} pinces et entraxes" if n > 1 else "1 distance au bord") if dist else "géométrie"
    p = _pince_ko(R)
    if p is not None:
        cmp_ = (f"{C.fr(p.val, 1)} mm &lt; {C.fr(p.min, 1)} mm" if p.min is not None and p.val < p.min
                else f"{C.fr(p.val, 1)} mm &gt; {C.fr(p.max, 1)} mm")
        quoi = f"{C.esc(p.lab)} : {cmp_}"       # (le nom tel que le moteur l'écrit : « S – e2 cornière » est le groupe S)
    else:
        quoi = f"Tab. 3.3 · {txt}"
    return C.ligne_verif("Géométrie", quoi, C.pct(t), niv, calcul="geometrie", gov=gov)


def _statut_note(bilans: List[Dict], niv: str) -> str:
    """Le statut dit dans l'en-tête des résultats : celui de l'assemblage ouvert quand il est seul (une réserve, une
    géométrie non conforme ne se lisent pas dans la couleur du taux) ; dès deux assemblages, celui de la NOTE — le moins
    bon de ses éléments."""
    if len(bilans) < 2:
        return C.statut(niv)
    nivs = [b["niveau"] for b in bilans]
    return C.statut(next((n for n in ("x", "c", "r", "v", "f") if n in nivs), "p"))


def resultat(etat: Dict) -> Dict:
    """Le calcul de l'assemblage ouvert et sa mise en forme : la tête (le repère ; la configuration, les pièces et les
    efforts), le verdict, le bloc « Vérifications » (une ligne par pièce, puis la géométrie), le bloc
    « Prédimensionnement » (il ouvre les propositions vérifiées), les messages ; les fenêtres de calcul, les dessins
    sous leur en-tête technique, la colonne de gauche, le résumé de la note."""
    el = _actif(etat)
    cfg = _cfg(el)
    u = el["values"]
    bilans = [_bilan(_cfg(e), e) for e in etat["assemblages"]]
    b = bilans[etat["actif"]]
    R = b["R"]
    tete = E.tete_resultats(C.esc(_repere(el, etat["actif"])), phrase(cfg, u))
    pied = ""                                     # (25/11/2026 : plus de cadre au pied du résultat — ``commun.infos``)
    if R is None:
        verdict = (f'<div class="verdict"><div class="gov"><b>Calcul impossible</b>{C.esc(motif_impossible(b["erreur"]))}</div></div>')
        return {"resultat": f'<div class="pbody">{tete}{verdict}</div>{pied}', "volets": "", "vues": [], "phrase": "",
                "statut_html": _statut_note(bilans, "x"), "resume": resume_note(etat, bilans), "donnees": arbre(etat, None),
                "elements": elements(etat, bilans)}
    if b["vides"] or b["refus"]:
        corps = ""
        if b["vides"]:
            noms = ", ".join(_nom_champ(cfg, k) for k in b["vides"])
            corps = (f'<div class="verdict"><div class="gov"><b>À compléter</b>Dimensions à saisir : {C.esc(noms)}. Vérification '
                     f'suspendue ; le dessin garde des dimensions provisoires.</div></div>')
        if b["refus"]:
            if not corps:
                corps = ('<div class="verdict"><div class="gov"><b>À corriger</b>Des données relues de la note ne sont pas '
                         'admises (l\'écran Streamlit les calculerait en silence, V<sub>Ed</sub> vide pris égal à 0, '
                         'γ nul…). Vérification suspendue jusqu\'à leur correction dans le cadre Données.</div></div>')
            corps += "".join(C.message(C.esc(msg), grave=True) for _k, msg in b["refus"])
        html_res, vol = f'<div class="pbody">{tete}{corps}</div>{pied}', ""
        niv = "c"
    else:
        cfg = pour(cfg, R)
        niv = niveau_R(R)
        rows = ""
        # la ligne marquée gouvernante est celle que la tête nomme : la géométrie quand c'est elle (une tige hors des
        # pinces), sinon la vérification gouvernante du moteur
        geo_gouverne = _cause_geometrie(R) is not None
        gouv = None if geo_gouverne else R.gov
        # lignes de plus (pied de poteau : les quatre critères de l'épaisseur requise, sous la ligne Platine) — un
        # texte va à la fin, un dict {groupe: html} sous la ligne de ce groupe
        extra = cfg.lignes_resultat(R, u) if cfg.lignes_resultat else ""
        groupes = _groupes(cfg, R)
        for grp, nom, eta, ok, pire, on, info in groupes:
            texte, pk = cfg.piece(R, u, grp)
            if info:
                mot = cfg.mot_information(R, grp) if cfg.mot_information else "information"
                texte = (texte + " · " if texte else "") + C.esc(mot)
            # une ligne d'INFORMATION ne porte pas de taux à la place des taux qui décident (petits chantiers,
            # 10/11/2026) : « hors verdict », en gris, sans jauge — un « 454 % » gris sous « Conforme » se lisait comme
            # un dépassement ignoré ; pour la même raison elle ne dit pas non plus ce qu'elle compare. Son taux se lit
            # dans sa fenêtre de calcul, et la phrase d'information (``note_information``) dit le plus sollicité.
            vu = eta if info else eta_vu(eta, ok)
            # ce que la pièce compare : sa vérification la plus chargée, nommée, puis valeur et limite
            quoi = "" if info else f"{C.esc(_minuscule(_court(cfg, pire)))} : {_comparaison(cfg, pire)}"
            rows += C.ligne_verif(nom, quoi, None if info else taux(vu), "c" if info else ("r" if not ok else C.niveau(vu)),
                                  calcul=_slug(grp), pk=pk or "", piece=texte, gov=bool(gouv is not None and gouv in on and not info),
                                  etat_txt=SANS_TAUX_INFORMATION if info else "")
            if isinstance(extra, dict):
                rows += extra.pop(grp, "")
        rows += "".join(extra.values()) if isinstance(extra, dict) else extra
        rows += _rangee_geometrie(R, gov=geo_gouverne)
        # « tout le calcul » du bloc : la fenêtre de ce qui gouverne (la géométrie, ou la pièce de la vérification
        # gouvernante), sinon celle de la première pièce
        fen = "geometrie" if geo_gouverne or not groupes else _slug(gouv.grp if gouv is not None else groupes[0][0])
        # (pas de ligne d'efforts : la tête, juste au-dessus, dit déjà la configuration, les pièces et les efforts)
        blocs = E.bloc(0, "Vérifications", CLASSES_BLOC.get(niv, "inc"), f"{C.STATUTS[niv][1]} · {C.pc(taux(eta_R(R)))}{C.NBSP}%",
                       "", rows, theme=True, calcul=fen)
        # Un assemblage que le moteur ne vérifie pas s'ouvre sur « À corriger » (assemblages_corriger.bloc : les défauts
        # de géométrie et leurs retouches, la solution vérifiée) ; vérifié, le bloc « Prédimensionnement » suit les
        # vérifications, comme avant. Plus de GROS taux en tête (le propriétaire, 26/11/2026 : « un gros 131 % et une
        # autre ligne […] dans le module en béton, ça on avait supprimé, parce que ça ne sert à rien de l'afficher alors
        # qu'en dessous on le voit ») : l'en-tête du bloc dit l'état et le taux, la ligne qui gouverne est marquée.
        corriger, dites = AC.bloc(cfg, R, u)
        if cfg.predim and not corriger:
            blocs += bloc_propositions()
        msg = _messages(cfg, R, dites)
        html_res = f'<div class="pbody">{tete}<div class="et-blocs">{corriger}{blocs}</div>{msg}</div>{pied}'
        vol = volets(cfg, R, u, el)
    cfg = pour(cfg, R)
    donnees = arbre(etat, R)
    vs = vues(cfg, R, el, donnees)
    sous, lignes, bande = entete_vue(cfg, u, R)
    for v in vs:
        v["entete"] = E.entete(v["titre"].upper(), sous, lignes, bande, v.get("legende", ""))
    return {"resultat": html_res, "volets": vol, "vues": vs, "phrase": "", "statut_html": _statut_note(bilans, niv),
            "resume": resume_note(etat, bilans), "donnees": donnees, "elements": elements(etat, bilans)}


# les pièces que l'en-tête d'une vue nomme, dans l'ordre : la porteuse, la portée (``Config.noms_pieces``)
NOMS_PIECES = ("Principale", "Secondaire")
# les efforts de la bande de l'en-tête : (clé, symbole, unité) — V toujours, les autres quand ils ne sont pas nuls
EFFORTS_BANDE = (("V_Ed", "V", "kN"), ("N_Ed", "N", "kN"), ("H_Ed", "H", "kN"), ("M_Ed", "M", "kN·m"))


def piece_txt(u: Dict, X: str) -> str:
    """« HEA 400 · S355 » : le profilé d'une pièce et la nuance de son acier, sur une ligne (texte)."""
    prof = u.get("prof_" + X)
    nu = u.get("nu_" + X)
    return (f"{'personnalisé' if prof == PERSO else (prof or '?')} · "
            f"{'acier personnalisé' if nu == PERSO else (nu or '?')}")


def bande_efforts(u: Dict) -> List:
    """La bande des efforts de l'en-tête d'une vue : V_Ed toujours, N_Ed, H_Ed et M_Ed quand ils sont saisis non nuls."""
    out = []
    for cle, s, un in EFFORTS_BANDE:
        if cle in u and (cle == "V_Ed" or _nombre(u.get(cle))):
            out.append((s, "Ed", _nombre(u.get(cle)), un))
    return out


def _nombre(v) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return 0.0
    return x if math.isfinite(x) else 0.0


def entete_vue(cfg: Config, u: Dict, R):
    """(sous-titre, lignes, bande) de l'en-tête des vues d'un assemblage (le propriétaire, 25/11/2026 : « au-dessus de la
    zone de dessin, le profilé principal, le profilé secondaire, la qualité d'acier juste à côté, sur une seule ligne ») :
    le nom de l'attache ; UNE ligne par pièce — « Principale HEA 400 · S355 », « Secondaire HEA 300 · S355 » — ; les
    efforts dans la bande, à droite. Une configuration qui a mieux à dire le dit (``Config.entete``) ; sans profilés
    porteur et porté, la ligne de la liste du projet (``projet.description``)."""
    if getattr(cfg, "entete", None):
        return cfg.entete(u, R)
    if "prof_P" in u and "prof_S" in u:
        nP, nS = getattr(cfg, "noms_pieces", NOMS_PIECES)
        appui = PJ.APPUI_COURT.get(str(u.get("appui") or ""))
        sous = C.esc(cfg.court) + (f" · {C.esc(appui)}" if appui else "")
        return sous, [f"{nP} {piece_txt(u, 'P')}", f"{nS} {piece_txt(u, 'S')}"], bande_efforts(u)
    d = PJ.description(u)
    return C.esc(cfg.court), [d] if d else [], None


def phrase(cfg: Config, u: Dict) -> str:
    """La phrase sous le titre du premier dessin : la configuration, les pièces et les efforts (acier/projet.description,
    la ligne de la liste du projet Streamlit)."""
    d = PJ.description(u)
    return C.esc(cfg.court + (" · " + d if d else ""))


# ===================================================================== les vues de la toile
def _hl(R) -> Dict:
    """Les cotes et pièces en cause dans les alertes, en rouge sur les dessins (Streamlit : celles de l'alerte
    sélectionnée ; le site les montre toutes)."""
    dims, elems = set(), set()
    for a in R.alerts:
        dims |= set(a.dims)
        if a.block:
            elems |= set(a.elems)
    return {"dims": dims, "elems": elems} if (dims or elems) else None


def vues(cfg: Config, R, el: Dict, donnees: str = "") -> List[Dict]:
    """Les DESSINS du moteur (``schemas`` de la configuration : élévation, vue en plan, vue de droite ou coupe), et eux
    seuls (le propriétaire, 25/11/2026 : « dans la partie centrale, on devrait juste avoir élévation, plan, droite »).
    Le prédimensionnement s'ouvre du résultat ; la note texte, la méthode et la validation ne sont plus des onglets.

    Ils se MANIPULENT (le propriétaire, 26/11/2026 : « avant, je cliquais sur le dessin et je pouvais tout choisir ») :
    une cote se tape sur le dessin, une pièce ouvre son sélecteur ou sa rubrique, « + » et « − » règlent les rangées
    d'un groupe de boulons — ``dessin_assemblages.manipulable``, d'après le cadre Données rendu (``donnees``) : le
    dessin ne mène qu'à un champ qui y EXISTE (R1 : un raccourci, jamais le seul accès)."""
    niveau = int(el.get("cotation", 1))
    chemins = frozenset(re.findall(r'data-chemin="([^"]+)"', donnees))
    roles = frozenset(_selecteurs(cfg))
    unites = {k: _unite(f) for k, f in cfg.E.CHAMPS.items()}
    return [{"cle": cle, "titre": titre, "court": court, "legende": legende,
             "svg": DA.manipulable(dessin.svg(identifiant=f"asm_{cle}"), R.u, chemins, roles, unites, COMPTES_MAXI, SIGNEES)}
            for cle, titre, court, dessin, legende in cfg.vues(R, niveau, _hl(R))]


def non_reverifies(cfg: Config, R) -> tuple:
    """Ce que l'écran Streamlit déclare « non revérifié » (son repli Périmètre) : une liste fixe, ou une fonction du
    résultat (poutre–poteau : les limites dépendent de l'appui, aile ou âme)."""
    nr = cfg.non_reverifies
    return tuple(nr(R) if callable(nr) else nr or ())


# ===================================================================== les sélecteurs
def _avec(cfg: Config, u: Dict, **k):
    """Le calcul de l'assemblage avec quelques saisies changées (une ligne de sélecteur)."""
    v = dict(u)
    v.update(k)
    try:
        return moteur(cfg, v)
    except Exception:  # noqa: BLE001 — une ligne impossible (profilé trop petit…) se montre en rouge, sans arrêter la liste
        return None


def _ligne_sel(nom: str, col: str, R, cur: bool, prop: str) -> Dict:
    if R is None:
        return {"nom": nom, "col": col, "taux": 999, "niveau": "r", "cur": cur, "opt": False, "prop": prop + " · calcul impossible", "_ok": False}
    # « _ok » : vérifié SANS raison à justifier ; « _ok2 » : vérifié, une raison nommée restant à justifier (orange) —
    # lot de clôture du 27/11/2026 (N9) : une ligne « à vérifier » ne passe jamais pour une ligne vérifiée
    return {"nom": nom, "col": col, "taux": C.pct(min(eta_R(R), 9.99)), "niveau": niveau_R(R), "cur": cur, "opt": False,
            "prop": prop + f" · {C.esc(R.statut.lower())}", "_ok": bool(R.verified and not R.get("a_verifier")),
            "_ok2": bool(R.verified)}


def _marquer_optimal(rows: List[Dict]) -> List[Dict]:
    """L'étoile « le plus petit qui tient » : la première ligne vérifiée sans raison à justifier ; à défaut — la raison
    tient aux données gardées (poutre grugée non maintenue, effort inversé…), aucune ligne ne peut la lever — la
    première ligne vérifiée, qui reste orange et dit sa raison."""
    for cle in ("_ok", "_ok2"):
        for r in rows:
            if r.get(cle):
                r["opt"] = True
                return rows
    return rows


def _debut(rows: List[Dict]) -> int:
    i_o = next((i for i, r in enumerate(rows) if r["opt"]), 0)
    i_c = next((i for i, r in enumerate(rows) if r["cur"]), i_o)
    return max(0, min(i_o, i_c) - 4)


def sel_boulon(cfg: Config, u: Dict, familles=None) -> str:
    rows = []
    for b in DB["boulons"]:
        R = _avec(cfg, u, boulon_u=b["n"])
        rows.append(_ligne_sel(b["n"], C.fr(b["As"], 0), R, b["n"] == u.get("boulon_u"),
                               f"{b['n']} · d<sub>0</sub> = {C.nb(b['d0'])} mm · A<sub>s</sub> = {C.fr(b['As'], 1)} mm²"))
    _marquer_optimal(rows)
    return C.selecteur("boulon", f"Boulons · classe {C.esc(u.get('classe') or '')}", "triés par diamètre · un clic retient le boulon",
                       "", rows, _debut(rows), "A<sub>s</sub> mm²", etoile="le plus petit qui tient")


def _fam(nom: str) -> str:
    return (nom or "").split()[0]


FAMILLES_PROFILS = sorted({_fam(p["n"]) for p in DB["profils"]}, key=lambda f: ["IPE", "HEA", "HEB", "HEM"].index(f) if f in ("IPE", "HEA", "HEB", "HEM") else 9)


def sel_profil(cle: str, titre: str):
    """Le sélecteur d'un profilé du catalogue des assemblages (acier/bibliotheques) : par famille (puces), trié par
    hauteur ; le taux de l'assemblage avec chaque profilé."""
    def rendre(cfg: Config, u: Dict, familles=None) -> str:
        cur = u.get(cle)
        fams = [f for f in (familles or []) if f in FAMILLES_PROFILS] or [_fam(cur) if _fam(cur) in FAMILLES_PROFILS else FAMILLES_PROFILS[0]]
        rows = []
        for p in sorted((p for p in DB["profils"] if _fam(p["n"]) in fams), key=lambda p: (FAMILLES_PROFILS.index(_fam(p["n"])), p["h"], p["b"])):
            R = _avec(cfg, u, **{cle: p["n"]})
            rows.append(_ligne_sel(p["n"], C.fr(p["h"], 0), R, p["n"] == cur,
                                   f"{p['n']} · h {C.nb(p['h'])} · b {C.nb(p['b'])} · t<sub>w</sub> {C.nb(p['tw'])} · t<sub>f</sub> {C.nb(p['tf'])} mm"))
        _marquer_optimal(rows)
        filtres = "".join(f'<button type="button" class="fchip{" on" if f in fams else ""}" data-famille="{f}">{f}</button>' for f in FAMILLES_PROFILS)
        return C.selecteur(cle, titre, "triés par hauteur · un clic retient le profilé", filtres, rows, _debut(rows), "h mm",
                           etoile="le plus petit qui tient")
    return rendre


def _choisir_liste(cle: str, liste: str):
    def choisir(cfg: Config, u: Dict, nom: str) -> None:
        find(DB[liste], nom)                      # un nom inconnu lève ValueError
        u[cle] = valeur_widget(cfg, cle, nom)
    return choisir


def _selecteurs(cfg: Config) -> Dict:
    s = {"boulon": {"rendre": sel_boulon, "choisir": _choisir_liste("boulon_u", "boulons")}} if "boulon_u" in cfg.E.CHAMPS else {}
    titres = getattr(cfg, "titres_profils", {})
    for cle, titre in (("prof_S", "Poutre secondaire · profilé"), ("prof_P", "Poutre principale · profilé")):
        if cle in cfg.E.CHAMPS:
            s[cle] = {"rendre": sel_profil(cle, titres.get(cle, titre)), "choisir": _choisir_liste(cle, "profils")}
    if cfg.predim:
        s["solution"] = {"rendre": sel_solution, "choisir": choisir_solution}
        # (sans aucune solution : les profilés plus hauts, chacun avec sa solution vérifiée — assemblages_corriger)
        s["profil_solution"] = {"rendre": AC.sel_profils, "choisir": AC.choisir_profil}
    s.update(cfg.selecteurs)
    return s


# ===================================================================== les propositions du prédimensionnement
# Ce qu'une proposition change, et ce qu'elle garde (le propriétaire, 25/11/2026 : « il faut que ça me garde mes données
# de base — les efforts, le profilé, le niveau ; c'est la plaque, le nombre de boulons qui doit changer ») : dit dans le
# bloc du résultat et dans le sélecteur. C'est la règle de ``acier/assemblages/propositions.py`` ; le test la rejoue
# sur chaque proposition (tests/test_assemblages_predim.py).
TITRE_PROPOSITIONS = "Solutions vérifiées"
SOUS_TITRE_SOLUTIONS = "un clic recopie boulons, pièce d'attache et gorge · efforts, profilés et niveaux gardés"
PROPOSITION_GARDE = "efforts, profilés et niveaux gardés"
# la dernière recherche (UNE seule) : le clic qui recopie une proposition ne la refait pas
_RECHERCHE: Dict = {}


def bloc_propositions() -> str:
    """Le bloc « Prédimensionnement » du résultat, sous les vérifications (le propriétaire, 25/11/2026 : « à droite, on
    a la vérification. En dessous, on a le prédimensionnement. Je trouve que c'est là qu'on devrait l'avoir ») : une
    ligne, dont le bouton ouvre les propositions. La recherche se fait AU CLIC (un calcul complet par candidat : elle
    ne ralentit pas la saisie). Pas de « tout le calcul » ici : une proposition recopiée se lit dans les vérifications."""
    tete = ('<div class="et-bloc-h"><button type="button" class="et-bloc-t" data-bloc="1" aria-expanded="true" title="Replier ou déplier">'
            f'{C.icon("chevron-down")}<span class="n">Prédimensionnement</span><span class="e">calcul complet</span></button></div>')
    row = C.ligne_verif("Solutions", PROPOSITION_GARDE, None, "c", pk="solution", piece="Proposer", etat_txt="vérifiées")
    return (f'<section class="et-bloc inc asm-prop" data-theme="1">{tete}<div class="et-bloc-c"><div class="et-bloc-ef"></div>'
            f'<div class="els">{row}</div></div></section>')


def propositions(cfg: Config, u: Dict):
    """Les propositions VÉRIFIÉES pour les saisies de l'écran (``acier/assemblages/propositions.chercher`` : chaque
    candidat est jugé par le calcul complet du moteur). La dernière recherche est gardée : choisir une ligne du
    sélecteur ne la refait pas."""
    cle = (cfg.cle, json.dumps(u, sort_keys=True, default=str, ensure_ascii=False))
    if _RECHERCHE.get("cle") != cle:
        X = chercher_solutions(cfg, u)
        _RECHERCHE.clear()
        _RECHERCHE.update(cle=cle, X=X)
    return _RECHERCHE["X"]


# la plage de diamètres de l'écran Streamlit (« Ø min », « Ø max ») : elle n'est plus une saisie du site
PLAGE_DIAMETRES = ("pd_dmin", "pd_dmax")


def chercher_solutions(cfg: Config, u: Dict):
    """La recherche des propositions VÉRIFIÉES pour des saisies, sans mémoire — sur TOUT le catalogue des boulons (le
    propriétaire, 26/11/2026 : « dans les options, ça propose un diamètre 16 à 22 […] que ça ne mette pas ça. Que ça
    mette les boulons qui conviennent ») : plus de plage à saisir, UNE solution par diamètre qui convient.

    La plage que la note garde est ignorée. Celle des DÉFAUTS du moteur (``entrees.defaults`` : les diamètres courants)
    ne sert plus qu'à ranger : à taux cible égal, un diamètre courant est conseillé avant un M12 ou un M36."""
    motif = trop_grand(cfg, u)
    if motif:
        raise ValueError(motif)
    defauts = cfg.E.defaults()
    base = dict(a_calculer(cfg, u), **{k: defauts[k] for k in PLAGE_DIAMETRES})
    return PR.chercher(cfg.predim["moteur"], cfg.S, base, cfg.predim["genre"], nb_max=len(DB["boulons"]), tout=True)


def changements(cfg: Config, u: Dict, v: Dict) -> Dict:
    """Ce qu'une proposition (ses saisies ``v``) change dans celles de l'écran : {clé: valeur du widget} — les seules
    clés qui diffèrent du calcul de l'écran (``a_calculer`` : une dimension vide y est provisoire, elle reste vide)."""
    base = a_calculer(cfg, u)
    return {k: valeur_widget(cfg, k, x) for k, x in v.items()
            if k in u and k not in cfg.listes and k not in PLAGE_DIAMETRES and x != base.get(k) and valeur_widget(cfg, k, x) != u.get(k)}


def _detail_proposition(cfg: Config, s) -> str:
    """La ligne d'une proposition sous la liste (HTML) : sa géométrie, ce qui la gouverne et son taux, ses réserves."""
    R, g = s.R, s.R.get("gov")
    c = pour(cfg, R)
    quoi = f" · {C.esc(g.grp)} : {C.esc(_minuscule(_court(c, g)))} {C.pc(taux_c(g, 0))}{C.NBSP}%" if g is not None else ""
    cible = "" if s.cible else " · au-dessus du taux cible"
    reserve = "".join(f" · avis : {C.esc(c.N.ligne_alerte(a, R)[0])}" for a in s.reserves[:2])
    # (N9) une solution dont le moteur dit « À VÉRIFIER » le dit ici, avec sa raison — elle est orange dans la liste
    a_verif = f" · <b>à vérifier</b> : {C.esc(R.a_verifier)}" if (R.verified and R.get("a_verifier")) else ""
    return C.esc(cfg.predim["detail"](s.u)) + quoi + cible + reserve + a_verif


# les conseils quand RIEN ne passe : la pièce dont la vérification bloque (l'ordre de ``synthese.ELEMENTS``)
CONSEIL_PORTEE = "Changer le profilé {piece} (une âme plus épaisse, une poutre plus haute){grugeage}."
CONSEIL_PORTEUSE = "Changer le profilé {piece} (une âme ou une aile plus épaisse)."
CONSEIL_HAUTEUR = ("La hauteur disponible de l'âme portée ({hav} mm) ne loge pas assez de boulons : une poutre plus haute, un "
                   "grugeage plus court ou une attache placée plus haut.")
VERIFS_GRUGEAGE = ("stN", "stD", "mN", "m2")     # les vérifications de la section grugée : réduire le grugeage aide


def _de_la(groupe: str) -> str:
    """« de la poutre secondaire », « du poteau porteur » : le groupe d'une vérification, après « le profilé »."""
    nom = groupe[:1].lower() + groupe[1:]
    return ("de la " if nom.startswith("poutre") else "du ") + nom


def aucune_solution(cfg: Config, X, court: bool = False) -> str:
    """Ce que le sélecteur dit quand aucune disposition ne passe (HTML) — le propriétaire, 25/11/2026 : « la seule raison
    pour laquelle ça n'irait pas, ce serait que les profilés ne seraient pas suffisants. Et qu'on devrait changer de
    profilé si on a 0 solution » : la vérification qui reste au-delà de 100 % dans le meilleur candidat, nommée, puis
    quoi changer."""
    tete = "<b>Aucune solution avec ces profilés.</b> "
    b = X.blocage
    hav = C.nb(round(X.hav)) if X.get("hav") is not None else "?"
    if b is None and X.get("geometrie") is not None:
        # aucune disposition n'a une géométrie valide : une donnée que les propositions ne touchent pas (une semelle qui
        # heurte la poutre porteuse, un grugeage trop court…) — l'alerte bloquante du moteur, telle qu'il la dit
        R = X.geometrie
        a = next(x for x in R.alerts if x.block)
        titre, det = pour(cfg, R).N.ligne_alerte(a, R)
        return (f"<b>Aucune solution : la géométrie n'est pas valide.</b> Quelle que soit la disposition des boulons — "
                f"{C.esc(titre)}" + (f" {C.esc(det)}" if det else "") + " À corriger d'abord (rubrique des poutres).")
    if b is None or b.gov is None:
        return (f'{tete}Aucune disposition de boulons (M12 à M36, deux rangées au moins) ne tient dans la hauteur disponible '
                f'de l\'âme portée ({hav}{C.NBSP}mm). Une poutre plus haute, un grugeage plus court ou une attache placée plus haut.')
    c = pour(cfg, b.R)
    g = b.gov
    portee, porteuse = c.S.ELEMENTS[2][0], c.S.ELEMENTS[3][0]
    # (``court`` — le bloc « À corriger » du résultat : sans la phrase qui dit ce qui a été essayé, que le sélecteur garde)
    essayees = ("Au mieux" if court else
                "Toutes les dispositions ont été essayées (M12 à M36, 2 à 8 rangées, une ou deux files, pièce plus épaisse) : au mieux")
    reste = (f"{essayees}, <b>{C.esc(g.grp)} · {C.esc(_minuscule(_court(c, g)))}</b> reste à "
             f"{C.pc(taux(min(b.R.eta_max, 9.99)))}{C.NBSP}% ({_comparaison(c, g)}). ")
    if g.grp == portee:
        conseil = CONSEIL_PORTEE.format(piece=C.esc(_de_la(portee)),
                                        grugeage=", ou réduire le grugeage" if g.key in VERIFS_GRUGEAGE else "")
    elif g.grp == porteuse:
        conseil = CONSEIL_PORTEUSE.format(piece=C.esc(_de_la(porteuse)))
    else:
        conseil = CONSEIL_HAUTEUR.format(hav=hav)
    return tete + reste + conseil


def sel_solution(cfg: Config, u: Dict, familles=None) -> str:
    """Le sélecteur « Solutions » : les propositions VÉRIFIÉES, la conseillée d'abord (★ : au taux cible, sans réserve,
    sur une file, le moins de boulons) ; chacune avec son nombre de
    boulons et son taux — celui du calcul complet, pas une estimation. Sans proposition : pourquoi, et quoi changer."""
    X = propositions(cfg, u)
    rows = []
    for k, s in enumerate(X.solutions):
        rows.append({"nom": cfg.predim["nom"](s.u), "col": C.nb(s.boulons), "taux": C.pct(min(eta_R(s.R), 9.99)),
                     "niveau": niveau_R(s.R), "cur": not changements(cfg, u, s.u), "opt": k == 0,
                     "prop": _detail_proposition(cfg, s)})
    tete = "" if rows else f'<div class="asm-aucune">{aucune_solution(cfg, X)}</div>'
    return C.selecteur("solution", TITRE_PROPOSITIONS, SOUS_TITRE_SOLUTIONS, tete, rows, 0, "boulons",
                       etoile="conseillée", vide="")


def choisir_solution(cfg: Config, u: Dict, nom: str) -> None:
    """Une proposition recopiée dans les saisies : ses boulons, ses rangées et ses files, ses pinces, sa pièce
    d'attache et sa gorge (``changements``) — jamais un effort, un profilé, un acier, un niveau ni le grugeage."""
    for s in propositions(cfg, u).solutions:
        if cfg.predim["nom"](s.u) == nom:
            u.update(changements(cfg, u, s.u))
            return
    raise ValueError(f"solution inconnue : {nom}")


def selecteur(etat: Dict, role: str, familles=None, froid: bool = True) -> str:
    el = _actif(etat)
    cfg = _cfg(el)
    s = _selecteurs(cfg).get(role)
    if s is None:
        raise ValueError(f"sélecteur inconnu : {role}")
    return s["rendre"](cfg, el["values"], familles)


# ===================================================================== la note PDF
def telecharger(etat: Dict, quoi: str, infos: Optional[Dict] = None) -> Optional[Dict]:
    """« note_pdf » : la note de calcul PDF de TOUTE la note — garde, récapitulatif, puis la note de chaque assemblage,
    faite par son générateur validé de l'écran Streamlit (api_web/note_assemblages.py) ; ``infos`` : le nom, le
    chantier, l'indice et la date de la note."""
    if quoi != "note_pdf":
        return None
    from . import note_assemblages as NA
    return NA.fichier(etat, infos)


# ===================================================================== les familles
# chargées en DERNIER : elles décrivent leurs configurations avec les briques ci-dessus (enregistrer, champs…)
from . import assemblages_corriger as AC  # noqa: E402
from . import assemblages_poutre  # noqa: E402,F401
from . import assemblages_poteau  # noqa: E402,F401
from . import assemblages_pied  # noqa: E402,F401
