# -*- coding: utf-8 -*-
"""La STATIQUE d'une barre chargée : chaque cas de charge résolu par le formulaire de poutres du dépôt (rdm/poutres.py,
écritures fermées), puis superposé — le comportement est linéaire. docs/acier/BARRES_ACIER.md § 9.

Unités de la barre : m, kN, kN/m, kN·m (celles de l'écran et du formulaire). Les moteurs de vérification travaillent en
N et mm : ``efforts`` convertit. Conventions du formulaire, reprises telles quelles : une charge vers le bas est
positive ; M > 0 tend la fibre inférieure (la fibre HAUTE est comprimée) ; flèche positive vers le bas.

    poids propre   g = masse linéique × 9,81 / 1000 (kN/m), un cas permanent de plus
    une combinaison  M(x) = Σ γ_i·M_i(x),  V(x) = Σ γ_i·V_i(x),  N = Σ γ_i·N_i,  f(x) = Σ γ_i·f_i(x)
    sections à vérifier : les appuis, chaque rupture de chargement, et les extremums du moment — là où l'effort
    tranchant de la combinaison s'annule. Entre deux ruptures, V est un polynôme de degré 2 au plus (charges
    uniformes et triangulaires) : trois lectures donnent ses racines, sans balayage.

Les lectures sont GARDÉES : toutes les combinaisons relisent les mêmes sections des mêmes cas.

LES TRONÇONS DE DÉVERSEMENT : entre deux sections tenues en déplacement latéral ET en torsion — les appuis (pris en
fourche : hypothèse dite dans la note), l'encastrement d'une console, et chaque maintien « complet ». Un maintien d'une
seule semelle (« haut », « bas ») reste À L'INTÉRIEUR de son tronçon. Le bout libre d'une console est libre.
"""
import math
from typing import Dict, List, Optional, Sequence, Tuple

from rdm import poutres as PO

from . import mcr as MC
from .resultat import Refus

G_PESANTEUR = 9.81               # m/s²
POIDS_PROPRE = "Poids propre"
GENRES_MAINTIEN = ("complet", "haut", "bas")
NEGLIGEABLE = 1e-9               # un effort tranchant plus petit que cette part du plus grand est pris nul


def poids_propre(s: Dict) -> float:
    """Le poids propre du profilé en kN/m."""
    if not s.get("masse"):
        raise Refus("la masse linéique du profilé manque : le poids propre en dépend")
    return s["masse"] * G_PESANTEUR / 1000.0


def cas_complets(barre: Dict, s: Dict) -> List[Dict]:
    """Les cas de charge de la barre, le poids propre en tête s'il est demandé (un cas permanent)."""
    cas = [dict(c) for c in barre["cas"]]
    if barre.get("poids_propre", True):
        L = sum(barre["travees"])
        cas.insert(0, {"nom": POIDS_PROPRE, "nature": "permanent", "N": 0.0,
                       "charges": [{"type": "q", "v": poids_propre(s), "a": 0.0, "b": L}]})
    return cas


class Lecture:
    """Un cas résolu par le formulaire, dont les sections lues sont gardées (``evaluer``) ; le reste de la solution —
    travées, appuis, réactions — se lit comme sur elle."""

    def __init__(self, sol):
        self.sol = sol
        self.lus: Dict[float, Dict] = {}
        self.moments: Dict[float, float] = {}

    def evaluer(self, x: float) -> Dict:
        e = self.lus.get(x)
        if e is None:
            e = self.lus[x] = self.sol.evaluer(x)
        return e

    def moment(self, x: float) -> float:
        """M dans la section x — à droite ; à gauche au bout de la barre : la valeur de ``evaluer``, sans le reste
        (effort tranchant, rotation, flèche). Le moment critique lit le moment en une centaine de points par tronçon."""
        m = self.moments.get(x)
        if m is None:
            sol = self.sol
            xc = min(sol.L, max(0.0, x))
            droite = xc < sol.L
            t = next((t for t in sol.travees if xc < t.x0 + t.L or (xc == t.x0 + t.L and (not droite or t is sol.travees[-1]))),
                     sol.travees[-1])
            m = self.moments[x] = t.M(min(t.L, max(0.0, xc - t.x0)), droite)
        return m

    def __getattr__(self, nom: str):
        return getattr(self.sol, nom)


def resoudre(barre: Dict, cas: Sequence[Dict], EI: Optional[float] = None) -> List[Lecture]:
    """Une solution du formulaire par cas (``EI`` en kN·m² pour la flèche)."""
    out = []
    for c in cas:
        try:
            out.append(Lecture(PO.resoudre(barre["modele"], barre["travees"], c.get("charges") or [], EI)))
        except PO.ErreurDonnees as e:
            raise Refus(f"cas « {c['nom']} » : {e}") from None
    return out


class Combinaison:
    """Les efforts d'une combinaison le long de la barre (kN, m) : la somme pondérée des cas."""

    def __init__(self, nom: str, sols: Sequence, facteurs: Sequence[float], N_cas: Sequence[float]):
        self.nom, self.facteurs = nom, list(facteurs)
        self.paires = [(f, s) for f, s in zip(facteurs, sols) if f]
        self.N = sum(f * n for f, n in zip(facteurs, N_cas))
        self.L = sols[0].L if sols else 0.0
        self.lus: Dict[float, Dict] = {}

    def lire(self, x: float) -> Dict:
        """M et V de part et d'autre de la section x, la flèche (None sans E·I). Le résultat est gardé : ne pas l'écrire."""
        o = self.lus.get(x)
        if o is not None:
            return o
        o = self.lus[x] = {"x": x, "M_g": 0.0, "M_d": 0.0, "V_g": 0.0, "V_d": 0.0, "f": 0.0}
        for f, s in self.paires:
            e = s.evaluer(x)
            for k in ("M_g", "M_d", "V_g", "V_d"):
                o[k] += f * e[k]
            o["f"] = None if (o["f"] is None or e["f"] is None) else o["f"] + f * e["f"]
        return o

    def M(self, x: float) -> float:
        """Le moment dans la section x (à droite ; à gauche au bout de la barre) — continu sauf sous un couple. C'est
        la valeur de ``lire`` (M_d, ou M_g au bout), lue sans l'effort tranchant ni la flèche."""
        return sum(f * s.moment(x) for f, s in self.paires)


def ruptures(sols: Sequence) -> List[float]:
    """Les abscisses globales où une expression change : appuis, débuts et fins de charge, charges ponctuelles."""
    pts = set()
    for s in sols:
        for t in s.travees:
            for x in t.ruptures():
                pts.add(round(t.x0 + x, 9))
            for m in t.morceaux:
                if m["type"] in ("P", "C"):
                    pts.add(round(t.x0 + m["a"], 9))
    return sorted(pts)


def _racines(y0: float, ym: float, y1: float, seuil: float) -> List[float]:
    """Les racines dans ]0 ; 1[ du polynôme de degré 2 au plus qui passe par (0, y0), (½, ym), (1, y1) ; aucune quand
    les trois valeurs sont sous ``seuil`` (un effort tranchant nul sur tout l'intervalle : le moment y est constant)."""
    ech = max(abs(y0), abs(ym), abs(y1))
    if ech <= seuil:
        return []
    A = 2.0 * (y0 + y1 - 2.0 * ym)
    B = y1 - y0 - A
    if abs(A) < 1e-12 * ech:
        r = [-y0 / B] if abs(B) > 1e-12 * ech else []
    else:
        d = B * B - 4.0 * A * y0
        if d < 0:
            return []
        q = -(B + math.copysign(math.sqrt(d), B)) / 2.0             # la forme stable
        r = [q / A] + ([y0 / q] if q != 0 else [])
    return sorted(t for t in r if 1e-12 < t < 1.0 - 1e-12)


def sections(barre: Dict, comb: Combinaison, pts: Sequence[float]) -> List[float]:
    """Les sections à vérifier pour cette combinaison : ``pts`` (les ruptures, triées) et les extremums du moment — les
    racines de l'effort tranchant entre deux ruptures."""
    out = set(pts)
    lus = [comb.lire(x) for x in pts]
    seuil = NEGLIGEABLE * max((max(abs(e["V_g"]), abs(e["V_d"])) for e in lus), default=0.0)
    for u, v, eu, ev in zip(pts, pts[1:], lus, lus[1:]):
        if v - u <= 1e-9:
            continue
        for t in _racines(eu["V_d"], comb.lire(0.5 * (u + v))["V_d"], ev["V_g"], seuil):
            out.add(round(u + t * (v - u), 6))
    return sorted(out)


def troncons(barre: Dict, s: Dict) -> List[Dict]:
    """Les tronçons de déversement : [{"x1", "x2" (m), "appuis" (les deux bouts), "maintiens": [(x local en mm, cote z)]}]."""
    L = sum(barre["travees"])
    console = barre["modele"] == "console"
    tenus = {0.0: MC.ENCASTRE if console else MC.FOURCHE}
    if not console:
        x = 0.0
        for Lt in barre["travees"]:
            x += Lt
            tenus[round(x, 9)] = MC.FOURCHE
    interieurs = []
    for m in barre.get("maintiens") or []:
        x, genre = float(m["x"]), m.get("genre", "complet")
        if genre not in GENRES_MAINTIEN:
            raise Refus(f"maintien : genre parmi {', '.join(GENRES_MAINTIEN)} — reçu {genre!r}")
        if not 0.0 <= x <= L:
            raise Refus(f"maintien à {x:g} m : hors de la barre (0 à {L:g} m)")
        if genre == "complet":
            tenus.setdefault(round(x, 9), MC.FOURCHE)
        else:
            interieurs.append((x, genre))
    if console and round(L, 9) not in tenus:
        tenus[round(L, 9)] = MC.LIBRE
    bornes = sorted(tenus)
    cote = ((s.get("h") or 0.0) - (s.get("tf") or s.get("t") or 0.0)) / 2.0        # le plan moyen d'une semelle
    out = []
    for a, b in zip(bornes, bornes[1:]):
        if b - a <= 1e-9:
            continue
        dedans = [((x - a) * 1e3, cote if genre == "haut" else -cote) for x, genre in interieurs if a + 1e-9 < x < b - 1e-9]
        out.append({"x1": a, "x2": b, "appuis": (tenus[a], tenus[b]), "maintiens": dedans})
    return out


def charges_du_troncon(cas: Sequence[Dict], facteurs: Sequence[float], tr: Dict, zg: float) -> Tuple[List, List]:
    """Les charges de la combinaison portées par le tronçon, en N et mm, abscisses locales, appliquées à la cote ``zg`` :
    (réparties [(x1, x2, q1, q2, zg)], ponctuelles [(x, P, zg)]). Les couples n'ont pas de hauteur d'application."""
    a, b = tr["x1"], tr["x2"]
    rep, pon = [], []
    for f, c in zip(facteurs, cas):
        if not f:
            continue
        for ch in c.get("charges") or []:
            if ch["type"] == "P":
                if a - 1e-9 <= ch["a"] <= b + 1e-9:
                    pon.append(((ch["a"] - a) * 1e3, f * ch["v"] * 1e3, zg))
            elif ch["type"] in ("q", "tri"):
                ca, cb = ch.get("a", 0.0), ch.get("b", b)
                u, v = max(a, ca), min(b, cb)
                if v - u <= 1e-9:
                    continue
                if ch["type"] == "q":
                    q1 = q2 = ch["v"]
                else:
                    croissante = ch.get("sens", "croissante") == "croissante"
                    def q(x, ca=ca, cb=cb, v_=ch["v"], cr=croissante):
                        t = (x - ca) / (cb - ca)
                        return v_ * (t if cr else 1.0 - t)
                    q1, q2 = q(u), q(v)
                rep.append(((u - a) * 1e3, (v - a) * 1e3, f * q1, f * q2, zg))        # 1 kN/m = 1 N/mm
    return rep, pon
