# -*- coding: utf-8 -*-
"""Les configurations courantes : des dimensions → un groupe de cordons, les
efforts au bon point et dans le bon sens, et les pièces du dessin.

Repère de chaque cas (plan de joint z = 0) :
- C1 recouvrement : plan de joint = interface des deux plats ; x le long de l'effort N, pièce
  rapportée B sur 0 ≤ x ≤ L_rec, |y| ≤ b/2 ;
- C2 jonction en T : plan de joint = face de A ; la pièce B debout, d'épaisseur t_B, le long de x ;
- C3 console : plan de joint = face du poteau ; x horizontal dans la face, y vertical (haut > 0),
  z vers l'extérieur ; le plat de la console est perpendiculaire à la face, d'épaisseur t le long de x ;
- C4 gousset : plan de joint = face d'appui ; le plat b_x × b_y posé à plat, origine à son coin bas-gauche ;
- C5 platine d'about : plan de joint = face de la platine ; profilé centré, semelles le long de x
  (axe fort de l'EN 1993 = x), âme le long de y ;
- C6 tube sur platine : idem, tube centré ;
- C7 bout à bout : plan de joint = plan du plat ; cordon le long de y (largeur b), effort N le long de x ;
- C8 cordons libres : tel que saisi — segments et arcs.

TYPE DE JONCTION d'une pièce rapportée posée en T (C2, C3, C5, C6) — ``jonction`` :
- « angle » : cordons d'angle (une ou deux faces), gorge a ;
- « partielle » : pénétration partielle p par face (§4.7.2) ; avec un cordon de renfort de gorge
  a_r, cordon à pénétration profonde de gorge p + a_r (§4.5.2(3)) ; sans renfort, gorge p
  parallèle à la face d'appui ; deux faces avec p₁ + p₂ ≥ t et c = t − 2p ≤ min(t/5 ; 3 mm) ⇒
  traitée comme pleine (§4.7.3) ;
- « pleine » : pleine pénétration — la soudure vaut la pièce (§4.7.1) : trois lignes de gorge
  (bords et milieu, poids de Simpson) qui rendent la section t·l de la pièce, vérifiées au métal
  de base. C'est le cas d'une cornière reconstituée de deux plats épais soudés à pleine pénétration.

Soudure DISCONTINUE : chaque configuration accepte ``troncons = {"n": k, "l": mm}`` (n = 0 :
cordon continu) ; les cordons droits et les pourtours deviennent k tronçons de l mm
régulièrement répartis (``trace.py``). Les efforts se saisissent en kN et kN·m dans le sens
du dessin ; ``efforts`` les convertit en N et N·mm au point de référence. ``pieces`` décrit
les pièces pour le dessin (polygones dans le plan de joint, mm, profilés du catalogue).
"""
import math
from typing import Dict, List, Optional, Tuple

import numpy as np

from acier import materiaux as MA

from .cordon import Cordon, beta_Lw, cordon_angle, cordon_bout_a_bout, cordon_bout_a_bout_T, lignes_pleine_penetration
from .groupe import Efforts
from . import trace as TR

CONFIGS: Dict[str, Dict] = {
    "C1": {"libelle": "Recouvrement", "vue": "plan",
           "description": "Deux plats à recouvrement : cordons latéraux (cisaillés le long) et frontaux (sollicités en travers)."},
    "C2": {"libelle": "Jonction en T", "vue": "elevation",
           "description": "Pièce debout soudée sur une face — cordons d'angle, pénétration partielle ou pleine : arrachement, cisaillement, flexion du T."},
    "C3": {"libelle": "Console fléchie", "vue": "elevation",
           "description": "Plat en console soudé sur l'aile d'un poteau : V à l'excentricité e → flexion + cisaillement des cordons verticaux."},
    "C4": {"libelle": "Gousset en torsion", "vue": "plan",
           "description": "Plat posé à plat sur l'aile d'un poteau, soudé sur un à quatre côtés, chargé dans son plan hors du centre : torsion + cisaillement."},
    "C5": {"libelle": "Platine d'about de profilé", "vue": "face",
           "description": "Profilé du catalogue soudé sur une platine : semelles et âme (cordons d'angle, pénétration partielle ou pleine) sous N, V, M, T."},
    "C6": {"libelle": "Tube sur platine", "vue": "face",
           "description": "Tube rond, carré ou rectangulaire soudé sur son pourtour, en continu ou par tronçons : N, V, M, T."},
    "C7": {"libelle": "Bout à bout", "vue": "plan",
           "description": "Pleine pénétration : la pièce gouverne ; pénétration partielle : cordon de gorge = pénétration."},
    "C8": {"libelle": "Cordons libres", "vue": "plan",
           "description": "N'importe quelle géométrie : segments et arcs, continus ou par tronçons, et six composantes d'effort au point de référence."},
}
JONCTIONS = {"angle": "cordons d'angle", "partielle": "pénétration partielle", "pleine": "pleine pénétration"}

# efforts de chaque cas : (clé, libellé, unité, aide — le sens est celui du dessin)
EFFORTS: Dict[str, List[Tuple[str, str, str, str]]] = {
    "C1": [("N", "N (kN)", "kN", "Traction dans le plat rapporté, le long des cordons latéraux (> 0 : tire la pièce B)."),
           ("V", "V (kN)", "kN", "Effort transversal dans le plan des plats, en travers des cordons latéraux.")],
    "C2": [("N", "N (kN)", "kN", "Arrachement de la pièce debout (> 0 : traction perpendiculaire à la face)."),
           ("Va", "V∥ (kN)", "kN", "Cisaillement le long de la jonction."),
           ("Vp", "V⊥ (kN)", "kN", "Cisaillement dans la face, en travers de la jonction."),
           ("M", "M (kN·m)", "kN·m", "Flexion de la pièce debout autour de la jonction (repris par le couple des deux cordons).")],
    "C3": [("V", "V (kN)", "kN", "Charge verticale vers le bas à l'extrémité, à l'excentricité e de la face du poteau."),
           ("N", "N (kN)", "kN", "Traction horizontale dans la console (> 0 : tire la console hors du poteau), à mi-hauteur.")],
    "C4": [("V", "V (kN)", "kN", "Effort dans le plan du plat, vertical sur le dessin (> 0 vers le bas), au point (x_V ; y_V)."),
           ("H", "H (kN)", "kN", "Effort dans le plan du plat, horizontal (> 0 vers la droite), au même point."),
           ("N", "N (kN)", "kN", "Arrachement du plat (> 0 : tire le plat hors de l'appui), au même point.")],
    "C5": [("N", "N (kN)", "kN", "Effort normal (> 0 : traction, tire le profilé hors de la platine)."),
           ("Vz", "V_z (kN)", "kN", "Cisaillement selon l'âme (axe fort)."),
           ("Vy", "V_y (kN)", "kN", "Cisaillement selon les semelles (axe faible)."),
           ("My", "M_y (kN·m)", "kN·m", "Flexion d'axe fort (> 0 : tend la semelle supérieure)."),
           ("Mz", "M_z (kN·m)", "kN·m", "Flexion d'axe faible (> 0 : tend le bout de semelle de gauche)."),
           ("T", "T (kN·m)", "kN·m", "Torsion autour de l'axe du profilé.")],
    "C6": [("N", "N (kN)", "kN", "Effort normal (> 0 : traction)."),
           ("Vz", "V_z (kN)", "kN", "Cisaillement vertical sur le dessin."),
           ("Vy", "V_y (kN)", "kN", "Cisaillement horizontal sur le dessin."),
           ("My", "M_y (kN·m)", "kN·m", "Flexion autour de l'axe horizontal (> 0 : tend le haut)."),
           ("Mz", "M_z (kN·m)", "kN·m", "Flexion autour de l'axe vertical (> 0 : tend la gauche)."),
           ("T", "T (kN·m)", "kN·m", "Torsion autour de l'axe du tube.")],
    "C7": [("N", "N (kN)", "kN", "Traction perpendiculaire à la soudure, dans le plan du plat."),
           ("V", "V (kN)", "kN", "Cisaillement le long de la soudure, dans le plan du plat."),
           ("M", "M (kN·m)", "kN·m", "Flexion dans le plan du plat (> 0 : tend le bord y > 0).")],
    "C8": [("N", "N (kN)", "kN", "Normal au plan de joint (> 0 : arrachement)."),
           ("Vx", "V_x (kN)", "kN", "Dans le plan, selon x."), ("Vy", "V_y (kN)", "kN", "Dans le plan, selon y."),
           ("Mx", "M_x (kN·m)", "kN·m", "Flexion, vecteur selon x (> 0 : tend y > 0)."),
           ("My", "M_y (kN·m)", "kN·m", "Flexion, vecteur selon y (> 0 : comprime x > 0)."),
           ("Mz", "M_z (kN·m)", "kN·m", "Torsion autour de la normale.")],
}

CONTINU = {"n": 0, "l": 60.0}
POTEAU_DEFAUT = "HEB 200"

PARAMS_DEFAUT: Dict[str, Dict] = {
    "C1": {"b": 100.0, "tB": 10.0, "tA": 10.0, "L_rec": 120.0, "lateraux": True, "frontaux": 1, "a": 5.0, "retours": False,
           "troncons": dict(CONTINU), "nuance_A": "S235", "nuance_B": "S235"},
    "C2": {"l": 200.0, "tB": 10.0, "tA": 12.0, "deux_cordons": True, "a": 5.0, "retours": False, "troncons": dict(CONTINU),
           "jonction": "angle", "p": 6.0, "renfort": 0.0, "nuance_A": "S235", "nuance_B": "S235"},
    "C3": {"h": 200.0, "t": 10.0, "e": 150.0, "deux_cordons": True, "a": 5.0, "retours": False, "troncons": dict(CONTINU),
           "jonction": "angle", "p": 6.0, "renfort": 0.0, "poteau": POTEAU_DEFAUT, "nuance_A": "S235", "nuance_B": "S235"},
    "C4": {"bx": 200.0, "by": 150.0, "t": 10.0, "cotes": ["gauche", "haut", "bas"], "a": 5.0, "retours": False,
           "troncons": dict(CONTINU), "xV": 250.0, "yV": 75.0, "poteau": POTEAU_DEFAUT, "nuance_A": "S235", "nuance_B": "S235"},
    "C5": {"profil": "IPE 200", "a_f": 5.0, "a_w": 4.0, "semelles": "deux faces", "ame": True, "retours": True,
           "jonction_semelles": "angle", "p_f": 6.0, "renfort_f": 0.0, "jonction_ame": "angle", "p_w": 4.0, "renfort_w": 0.0,
           "troncons_semelles": dict(CONTINU), "troncons_ame": dict(CONTINU), "tp": 15.0, "nuance_A": "S235", "nuance_B": "S235"},
    "C6": {"profil": "SHS 100x100x5", "a": 4.0, "troncons": dict(CONTINU), "jonction": "angle", "p": 4.0, "renfort": 0.0, "tp": 15.0,
           "nuance_A": "S235", "nuance_B": "S235"},
    "C7": {"b": 150.0, "t": 12.0, "penetration": "pleine", "p": 5.0, "deux_faces": True, "nuance_A": "S235", "nuance_B": "S235"},
    "C8": {"elements": [{"type": "segment", "x1": -50.0, "y1": -100.0, "x2": -50.0, "y2": 100.0, "a": 5.0, "cote": -1, "retours": False,
                         "troncons": dict(CONTINU)},
                        {"type": "segment", "x1": 50.0, "y1": -100.0, "x2": 50.0, "y2": 100.0, "a": 5.0, "cote": 1, "retours": False,
                         "troncons": dict(CONTINU)}],
           "xR": 0.0, "yR": 0.0, "zR": 0.0, "nuance_A": "S235", "nuance_B": "S235"},
}
EFFORTS_DEFAUT: Dict[str, Dict[str, float]] = {
    "C1": {"N": 80.0, "V": 0.0}, "C2": {"N": 40.0, "Va": 0.0, "Vp": 0.0, "M": 1.0}, "C3": {"V": 60.0, "N": 0.0},
    "C4": {"V": 40.0, "H": 0.0, "N": 0.0}, "C5": {"N": 0.0, "Vz": 60.0, "Vy": 0.0, "My": 30.0, "Mz": 0.0, "T": 0.0},
    "C6": {"N": 50.0, "Vz": 20.0, "Vy": 0.0, "My": 5.0, "Mz": 0.0, "T": 0.0}, "C7": {"N": 200.0, "V": 0.0, "M": 0.0},
    "C8": {"N": 0.0, "Vx": 0.0, "Vy": -60.0, "Mx": 9.0, "My": 0.0, "Mz": 0.0},
}

ELEMENT_SEGMENT = {"type": "segment", "x1": 0.0, "y1": 0.0, "x2": 100.0, "y2": 0.0, "a": 5.0, "cote": 1, "retours": False,
                   "troncons": dict(CONTINU)}
ELEMENT_ARC = {"type": "arc", "xc": 0.0, "yc": 0.0, "r": 50.0, "ang1": 0.0, "ang2": 360.0, "a": 5.0, "cote": 1,
               "troncons": dict(CONTINU)}


def _kn(v):
    return float(v) * 1e3


def _knm(v):
    return float(v) * 1e6


def _tr(p: Dict, cle: str = "troncons") -> Dict:
    """Le paramètre de tronçons normalisé : {"n": entier ≥ 0, "l": mm}."""
    t = p.get(cle) or {}
    return {"n": int(t.get("n", 0) or 0), "l": float(t.get("l", CONTINU["l"]) or CONTINU["l"])}


def _droit(nom, p1, p2, a, cote, retours, tr, constructeur=cordon_angle, **kw) -> List[Cordon]:
    return TR.cordons_droits_ou_troncons(nom, p1, p2, a, cote, retours, tr, constructeur=constructeur, **kw)


def _profil(nom: str) -> Dict:
    from acier.profiles import catalogue as CAT
    rec = CAT.par_nom().get(nom)
    if rec is None:
        raise ValueError(f"profilé inconnu au catalogue : {nom}")
    return rec


def _poteau(p: Dict) -> Optional[Dict]:
    """Le profilé support (aile de poteau) du dessin, ou None pour un plat."""
    nom = p.get("poteau") or ""
    if not nom or nom == "plat":
        return None
    return _profil(nom)


# ------------------------------------------------------------------ jonction d'une pièce en T
def jonction_T(nom: str, p1, p2, t: float, jonction: str, a: float, p: float, renfort: float, deux_faces: bool,
               retours: bool, tr: Dict, notes: List[str], faces: Tuple[str, str] = ("1", "2")) -> List[Cordon]:
    """Les cordons du bord d'une pièce rapportée d'épaisseur t, debout sur la face
    d'appui le long de son plan moyen p1 → p2 : face « 1 » à +n·t/2 (n = normale à
    gauche du sens de parcours), face « 2 » à −n·t/2.
    - angle : cordon d'angle de gorge a sur chaque face (ou la face 1 seule) ;
    - partielle : pénétration p par face ; cordon de renfort a_r ⇒ gorge p + a_r en
      cordon d'angle à pénétration profonde (§4.5.2(3)) ; sans renfort, gorge p
      parallèle à la face d'appui ; règle du T (§4.7.3) : deux faces, 2p ≥ t et
      t − 2p ≤ min(t/5 ; 3) ⇒ pleine ;
    - pleine : trois lignes de gorge (bords ±t/2 à t/6, milieu à 2t/3) vérifiées au
      métal de base (§4.7.1)."""
    P1 = np.array([float(p1[0]), float(p1[1]), 0.0])
    P2 = np.array([float(p2[0]), float(p2[1]), 0.0])
    ea = (P2 - P1) / (np.linalg.norm(P2 - P1) or 1.0)
    n = np.cross(np.array([0.0, 0.0, 1.0]), ea)                  # normale à GAUCHE du sens de parcours
    f1 = (P1 + n * t / 2, P2 + n * t / 2, -1)                      # face 1 : la pièce est à droite du cordon
    f2 = (P1 - n * t / 2, P2 - n * t / 2, +1)                      # face 2 : à gauche
    nom1, nom2 = (f"{nom} {faces[0]}".strip(), f"{nom} {faces[1]}".strip())
    if jonction == "pleine":
        return lignes_pleine_penetration(nom, tuple(P1[:2]), tuple(P2[:2]), t, cote=-1)   # bord 1 du côté de la face 1 (à gauche du parcours)
    if jonction == "partielle":
        p = float(p)
        if deux_faces and 2.0 * p >= t - 1e-9 and (t - 2.0 * p) <= min(t / 5.0, 3.0) + 1e-9:
            notes.append(f"{nom} : pénétration partielle des deux faces avec p₁ + p₂ = {2 * p:g} ≥ t = {t:g} mm et "
                         f"c = {max(0.0, t - 2 * p):g} ≤ min(t/5 ; 3 mm) → traitée comme pleine pénétration (EN 1993-1-8 §4.7.3)")
            return lignes_pleine_penetration(nom, tuple(P1[:2]), tuple(P2[:2]), t, cote=-1)   # bord 1 du côté de la face 1 (à gauche du parcours)
        out = []
        for (q1, q2, cote), nm in ((f1, nom1), (f2, nom2)):
            if float(renfort) > 0:                                  # pénétration profonde : gorge p + a_r à 45°
                out += _droit(nm, tuple(q1[:2]), tuple(q2[:2]), p + float(renfort), cote, retours, tr)
            else:                                                   # gorge p parallèle à la face d'appui
                out += _droit(nm, tuple(q1[:2]), tuple(q2[:2]), p, cote, True, tr, constructeur=cordon_bout_a_bout_T)
            if not deux_faces:
                break
        return out
    out = _droit(nom1, tuple(f1[0][:2]), tuple(f1[1][:2]), a, f1[2], retours, tr)
    if deux_faces:
        out += _droit(nom2, tuple(f2[0][:2]), tuple(f2[1][:2]), a, f2[2], retours, tr)
    return out


def _desc_jonction(jonction: str, a: float, p: float, renfort: float, deux: bool, t: float) -> Dict:
    return {"type": jonction, "a": float(a), "p": float(p), "renfort": float(renfort), "deux_faces": bool(deux), "t": float(t)}


# ------------------------------------------------------------------ C1 recouvrement
def c1(p: Dict, e: Dict) -> Dict:
    b, L, a = float(p["b"]), float(p["L_rec"]), float(p["a"])
    ret = bool(p.get("retours", False))
    tr = _tr(p)
    cs: List[Cordon] = []
    disc = []
    if p.get("lateraux", True):
        cs += _droit("latéral haut", (0, b / 2), (L, b / 2), a, -1, ret, tr)
        cs += _droit("latéral bas", (0, -b / 2), (L, -b / 2), a, +1, ret, tr)
        if tr["n"] >= 1:
            disc.append({"nom": "cordons latéraux", "n": tr["n"], "l": tr["l"], "espacement": TR.espacement_troncons(L, False, tr["n"], tr["l"])})
    nf = int(p.get("frontaux", 1))
    if nf >= 1:    # le bout du plat B (dessus) soudé sur A : visible de dessus
        cs.append(cordon_angle("frontal (bout de B)", (0, -b / 2), (0, b / 2), a, cote=-1, retours=ret))
    if nf >= 2:    # le bout du plat A (dessous) soudé sous B
        cs.append(cordon_angle("frontal (bout de A)", (L, -b / 2), (L, b / 2), a, cote=+1, retours=ret))
    blw = beta_Lw(L, a) if p.get("lateraux", True) else 1.0
    eff = Efforts(Vx=_kn(e.get("N", 0)), Vy=_kn(e.get("V", 0)), reference=(L / 2, 0.0, 0.0))
    pieces = {"vue": "plan", "A": [(-L * 0.6, -b * 0.75), (L, -b * 0.75), (L, b * 0.75), (-L * 0.6, b * 0.75)],
              "B": [(0, -b / 2), (L * 1.6, -b / 2), (L * 1.6, b / 2), (0, b / 2)], "tA": float(p["tA"]), "tB": float(p["tB"]),
              "L": L, "b": b, "t_min": min(float(p["tA"]), float(p["tB"])), "a": a, "frontaux": nf, "lateraux": bool(p.get("lateraux", True))}
    return {"cordons": cs, "efforts": eff, "beta_Lw": blw, "pieces": pieces, "discontinu": disc, "notes": []}


# ------------------------------------------------------------------ C2 jonction en T
def c2(p: Dict, e: Dict) -> Dict:
    l, tB, a = float(p["l"]), float(p["tB"]), float(p["a"])
    ret = bool(p.get("retours", False))
    tr = _tr(p)
    notes: List[str] = []
    jon = p.get("jonction", "angle")
    cs = jonction_T("cordon", (0, 0), (l, 0), tB, jon, a, float(p.get("p", 6.0)), float(p.get("renfort", 0.0)),
                    bool(p.get("deux_cordons", True)), ret, tr, notes)
    disc = [{"nom": "cordons de la jonction", "n": tr["n"], "l": tr["l"], "espacement": TR.espacement_troncons(l, False, tr["n"], tr["l"])}] \
        if tr["n"] >= 1 and jon != "pleine" else []
    eff = Efforts(N=_kn(e.get("N", 0)), Vx=_kn(e.get("Va", 0)), Vy=_kn(e.get("Vp", 0)), Mx=_knm(e.get("M", 0)),
                  reference=(l / 2, 0.0, 0.0))
    pieces = {"vue": "elevation", "tA": float(p["tA"]), "tB": tB, "l": l, "hB": max(120.0, 6 * tB), "t_min": min(float(p["tA"]), tB),
              "jonction": _desc_jonction(jon, a, float(p.get("p", 6.0)), float(p.get("renfort", 0.0)), bool(p.get("deux_cordons", True)), tB),
              "t_rapporte": tB}
    return {"cordons": cs, "efforts": eff, "beta_Lw": 1.0, "pieces": pieces, "discontinu": disc, "notes": notes}


# ------------------------------------------------------------------ C3 console
def c3(p: Dict, e: Dict) -> Dict:
    h, t, ex, a = float(p["h"]), float(p["t"]), float(p["e"]), float(p["a"])
    ret = bool(p.get("retours", False))
    tr = _tr(p)
    notes: List[str] = []
    jon = p.get("jonction", "angle")
    # le plat est debout sur la face, son plan moyen est l'axe y (x = 0) ; parcouru de haut en bas, la face 1
    # (à gauche du parcours) est la face DROITE (x = +t/2) : « cordon droit »
    cs = jonction_T("cordon", (0, h / 2), (0, -h / 2), t, jon, a, float(p.get("p", 6.0)), float(p.get("renfort", 0.0)),
                    bool(p.get("deux_cordons", True)), ret, tr, notes, faces=("droit", "gauche"))
    disc = [{"nom": "cordons verticaux", "n": tr["n"], "l": tr["l"], "espacement": TR.espacement_troncons(h, False, tr["n"], tr["l"])}] \
        if tr["n"] >= 1 and jon != "pleine" else []
    eff = Efforts(Vy=-_kn(e.get("V", 0)), N=_kn(e.get("N", 0)), reference=(0.0, 0.0, ex))
    pot = _poteau(p)
    t_sup = pot["tf"] if pot else t
    pieces = {"vue": "elevation", "h": h, "t": t, "e": ex, "longueur": ex * 1.35, "t_min": min(t, t_sup), "poteau": pot,
              "jonction": _desc_jonction(jon, a, float(p.get("p", 6.0)), float(p.get("renfort", 0.0)), bool(p.get("deux_cordons", True)), t),
              "t_rapporte": t}
    return {"cordons": cs, "efforts": eff, "beta_Lw": 1.0, "pieces": pieces, "discontinu": disc, "notes": notes}


# ------------------------------------------------------------------ C4 gousset
def c4(p: Dict, e: Dict) -> Dict:
    bx, by, a = float(p["bx"]), float(p["by"]), float(p["a"])
    ret = bool(p.get("retours", False))
    tr = _tr(p)
    cotes = p.get("cotes", ["gauche"])
    cs: List[Cordon] = []
    disc = []
    for nom, p1, p2, cote, L in (("gauche", (0, 0), (0, by), -1, by), ("droite", (bx, 0), (bx, by), +1, by),
                                 ("bas", (0, 0), (bx, 0), +1, bx), ("haut", (0, by), (bx, by), -1, bx)):
        if nom in cotes:
            cs += _droit(nom, p1, p2, a, cote, ret, tr)
            if tr["n"] >= 1:
                disc.append({"nom": f"côté {nom}", "n": tr["n"], "l": tr["l"], "espacement": TR.espacement_troncons(L, False, tr["n"], tr["l"])})
    xV, yV = float(p.get("xV", bx)), float(p.get("yV", by / 2))
    eff = Efforts(Vy=-_kn(e.get("V", 0)), Vx=_kn(e.get("H", 0)), N=_kn(e.get("N", 0)), reference=(xV, yV, 0.0))
    pot = _poteau(p)
    t_sup = pot["tf"] if pot else float(p["t"])
    # l'appui A couvre la zone soudée ; le plat B déborde jusqu'au point d'application (porte-à-faux)
    pieces = {"vue": "plan", "A": [(-25, -30), (bx + 25, -30), (bx + 25, by + 30), (-25, by + 30)],
              "B": [(0, 0), (max(bx, xV + 20), 0), (max(bx, xV + 20), by), (0, by)], "bx": bx, "by": by,
              "t": float(p["t"]), "xV": xV, "yV": yV, "t_min": min(float(p["t"]), t_sup), "poteau": pot, "a": a, "cotes": list(cotes)}
    return {"cordons": cs, "efforts": eff, "beta_Lw": 1.0, "pieces": pieces, "discontinu": disc, "notes": []}


# ------------------------------------------------------------------ C5 platine d'about
def c5(p: Dict, e: Dict) -> Dict:
    rec = _profil(p["profil"])
    h, b, tw, tf, r = rec["h"], rec["b"], rec["tw"], rec["tf"], rec.get("r", rec.get("r1", 0.0))
    af, aw = float(p["a_f"]), float(p["a_w"])
    ret = bool(p.get("retours", True))
    trf, trw = _tr(p, "troncons_semelles"), _tr(p, "troncons_ame")
    notes: List[str] = []
    jf, jw = p.get("jonction_semelles", "angle"), p.get("jonction_ame", "angle")
    pf, rf = float(p.get("p_f", 6.0)), float(p.get("renfort_f", 0.0))
    pw, rw = float(p.get("p_w", 4.0)), float(p.get("renfort_w", 0.0))
    deux = p.get("semelles", "deux faces") == "deux faces"
    cs: List[Cordon] = []
    disc = []
    if jf == "angle":
        cs += _droit("semelle sup. ext.", (-b / 2, h / 2), (b / 2, h / 2), af, -1, ret, trf)
        cs += _droit("semelle inf. ext.", (-b / 2, -h / 2), (b / 2, -h / 2), af, +1, ret, trf)
        if trf["n"] >= 1:
            disc.append({"nom": "semelles", "n": trf["n"], "l": trf["l"], "espacement": TR.espacement_troncons(b, False, trf["n"], trf["l"])})
        if deux:
            x0 = tw / 2 + r
            for nom, p1, p2, cote in (("semelle sup. int. droite", (x0, h / 2 - tf), (b / 2, h / 2 - tf), +1),
                                      ("semelle sup. int. gauche", (-b / 2, h / 2 - tf), (-x0, h / 2 - tf), +1),
                                      ("semelle inf. int. droite", (x0, -h / 2 + tf), (b / 2, -h / 2 + tf), -1),
                                      ("semelle inf. int. gauche", (-b / 2, -h / 2 + tf), (-x0, -h / 2 + tf), -1)):
                tri = {"n": min(trf["n"], 1), "l": trf["l"]} if trf["n"] >= 1 else trf
                cs += _droit(nom, p1, p2, af, cote, ret, tri)
    else:
        # pénétration (partielle ou pleine) sur l'épaisseur de chaque semelle : plan moyen à ±(h/2 − tf/2)
        for nom, y, sens in (("semelle sup.", h / 2 - tf / 2, +1), ("semelle inf.", -h / 2 + tf / 2, -1)):
            cs += jonction_T(nom, (-b / 2 * sens, y), (b / 2 * sens, y), tf, jf, af, pf, rf, deux, ret, trf, notes, faces=("ext.", "int."))
    if p.get("ame", True):
        d = h / 2 - tf - r
        if jw == "angle":
            cs += _droit("âme droite", (tw / 2, -d), (tw / 2, d), aw, +1, ret, trw)
            cs += _droit("âme gauche", (-tw / 2, -d), (-tw / 2, d), aw, -1, ret, trw)
            if trw["n"] >= 1:
                disc.append({"nom": "âme", "n": trw["n"], "l": trw["l"], "espacement": TR.espacement_troncons(2 * d, False, trw["n"], trw["l"])})
        else:   # parcourue de haut en bas : la face 1 (à gauche du parcours) est la face droite (x = +tw/2)
            cs += jonction_T("âme", (0, d), (0, -d), tw, jw, aw, pw, rw, True, ret, trw, notes, faces=("droite", "gauche"))
    eff = Efforts(N=_kn(e.get("N", 0)), Vy=_kn(e.get("Vz", 0)), Vx=_kn(e.get("Vy", 0)),
                  Mx=_knm(e.get("My", 0)), My=_knm(e.get("Mz", 0)), Mz=_knm(e.get("T", 0)), reference=(0.0, 0.0, 0.0))
    pieces = {"vue": "face", "profil": rec, "platine": [(-b / 2 - 40, -h / 2 - 40), (b / 2 + 40, -h / 2 - 40), (b / 2 + 40, h / 2 + 40), (-b / 2 - 40, h / 2 + 40)],
              "t_min": min(tw, tf), "tp": float(p.get("tp", 15.0)),
              "jonction_semelles": _desc_jonction(jf, af, pf, rf, deux, tf), "jonction_ame": _desc_jonction(jw, aw, pw, rw, True, tw),
              "t_rapporte": tf}
    return {"cordons": cs, "efforts": eff, "beta_Lw": 1.0, "pieces": pieces, "discontinu": disc, "notes": notes}


# ------------------------------------------------------------------ C6 tube
def contour_tube(rec: Dict, retrait: float = 0.0) -> List[Tuple[float, float]]:
    """Le pourtour du tube (ligne de racine des cordons), sens trigonométrique,
    rentré de ``retrait`` (0 : face extérieure ; t/2 : ligne moyenne de la paroi) :
    24 cordes pour un rond, côtés droits + 4 cordes par coin arrondi pour un carré ou un rectangle."""
    if rec["famille"] in ("CHS", "CHS-F", "TUBE"):
        rr = rec["d"] / 2 - retrait
        n = 24
        return [(rr * math.cos(2 * math.pi * k / n), rr * math.sin(2 * math.pi * k / n)) for k in range(n)]
    from acier.profiles import familles as F
    from acier.profiles import geometrie as G
    h, b, t = rec["h"] - 2 * retrait, rec["b"] - 2 * retrait, rec["t"]
    re, _ = F.rayons(rec["famille"], t)
    re = max(0.0, re - retrait)
    coins = [(-b / 2, -h / 2), (b / 2, -h / 2), (b / 2, h / 2), (-b / 2, h / 2)]
    ring = G.arrondir(coins, [re] * 4, n=4)
    return [(float(x), float(y)) for x, y in ring]


def c6(p: Dict, e: Dict) -> Dict:
    rec = _profil(p["profil"])
    a = float(p["a"])
    t = float(rec.get("t", 0.0) or 0.0)
    tr = _tr(p)
    notes: List[str] = []
    jon = p.get("jonction", "angle")
    pen, renf = float(p.get("p", 4.0)), float(p.get("renfort", 0.0))
    pts = contour_tube(rec)
    ymax = max(y for _, y in pts)
    s_haut = TR.abscisse_pres(pts, True, (0.0, ymax))      # le premier tronçon centré en haut
    if jon == "pleine" and t > 0:
        ligne = contour_tube(rec, t / 2)
        cs = TR.chaine("pourtour", ligne, t, +1, ferme=True, constructeur=cordon_bout_a_bout_T, pleine=True, t_piece=t)
    elif jon == "partielle" and t > 0:
        if renf > 0:
            cs = TR.chaine_ou_troncons("pourtour", pts, pen + renf, +1, True, tr, s_origine=s_haut)
        else:
            cs = TR.chaine_ou_troncons("pourtour", pts, pen, +1, True, tr, s_origine=s_haut, constructeur=cordon_bout_a_bout_T)
    else:
        cs = TR.chaine_ou_troncons("pourtour", pts, a, +1, True, tr, s_origine=s_haut)
    L = TR.longueur_chemin(pts, True)
    disc = [{"nom": "pourtour", "n": tr["n"], "l": tr["l"], "espacement": TR.espacement_troncons(L, True, tr["n"], tr["l"])}] \
        if tr["n"] >= 1 and jon != "pleine" else []
    eff = Efforts(N=_kn(e.get("N", 0)), Vy=_kn(e.get("Vz", 0)), Vx=_kn(e.get("Vy", 0)),
                  Mx=_knm(e.get("My", 0)), My=_knm(e.get("Mz", 0)), Mz=_knm(e.get("T", 0)), reference=(0.0, 0.0, 0.0))
    ext = max(max(abs(x) for x, _ in pts), max(abs(y) for _, y in pts)) + 40
    pieces = {"vue": "face", "profil": rec, "contour": pts, "platine": [(-ext, -ext), (ext, -ext), (ext, ext), (-ext, ext)],
              "t_min": t, "perimetre": L, "tp": float(p.get("tp", 15.0)), "jonction": _desc_jonction(jon, a, pen, renf, False, t),
              "t_rapporte": t}
    return {"cordons": cs, "efforts": eff, "beta_Lw": 1.0, "pieces": pieces, "discontinu": disc, "notes": notes}


# ------------------------------------------------------------------ C7 bout à bout
def c7(p: Dict, e: Dict) -> Dict:
    b, t = float(p["b"]), float(p["t"])
    pleine = p.get("penetration", "pleine") == "pleine"
    notes: List[str] = []
    cs: List[Cordon] = []
    if pleine:
        cs.append(cordon_bout_a_bout("soudure bout à bout", (0, -b / 2), (0, b / 2), t, cote=+1, retours=True, pleine=True, t_piece=t))
    else:
        pen = float(p["p"])
        deux = bool(p.get("deux_faces", True))
        if deux and 2.0 * pen >= t - 1e-9:
            notes.append(f"pénétration des deux faces avec p₁ + p₂ = {2 * pen:g} ≥ t = {t:g} mm : la pénétration est complète → soudure bout à bout "
                         "à pleine pénétration, la pièce gouverne (§4.7.1)")
            cs.append(cordon_bout_a_bout("soudure bout à bout", (0, -b / 2), (0, b / 2), t, cote=+1, retours=True, pleine=True, t_piece=t))
            pleine = True
        else:
            cs.append(cordon_bout_a_bout("pénétration face 1", (0, -b / 2), (0, b / 2), pen, cote=+1, retours=True))
            if deux:
                cs.append(cordon_bout_a_bout("pénétration face 2", (0, -b / 2), (0, b / 2), pen, cote=+1, retours=True))
    eff = Efforts(Vx=_kn(e.get("N", 0)), Vy=_kn(e.get("V", 0)), Mz=_knm(e.get("M", 0)), reference=(0.0, 0.0, 0.0))
    pieces = {"vue": "plan", "b": b, "t": t, "pleine": pleine, "A": [(-b, -b / 2), (0, -b / 2), (0, b / 2), (-b, b / 2)],
              "B": [(0, -b / 2), (b, -b / 2), (b, b / 2), (0, b / 2)], "t_min": t, "p": float(p.get("p", t / 2)),
              "deux_faces": bool(p.get("deux_faces", True)), "t_rapporte": t}
    return {"cordons": cs, "efforts": eff, "beta_Lw": 1.0, "pieces": pieces, "discontinu": [], "notes": notes}


# ------------------------------------------------------------------ C8 libre
def elements_c8(p: Dict) -> List[Dict]:
    """Les éléments saisis, normalisés (l'ancienne clé ``cordons`` — segments seuls — reste lue)."""
    src = p.get("elements")
    if src is None:
        src = p.get("cordons", [])
    out = []
    for i, c in enumerate(src, 1):
        typ = c.get("type", "segment")
        base = dict(ELEMENT_ARC if typ == "arc" else ELEMENT_SEGMENT)
        base.update(c)
        base["type"] = typ
        base.setdefault("nom", "")
        base["nom"] = base.get("nom") or (f"arc {i}" if typ == "arc" else f"cordon {i}")
        out.append(base)
    return out


def c8(p: Dict, e: Dict) -> Dict:
    cs: List[Cordon] = []
    disc = []
    elements = elements_c8(p)
    for el in elements:
        tr = _tr(el)
        if el["type"] == "arc":
            pts = TR.arc((float(el["xc"]), float(el["yc"])), float(el["r"]), float(el["ang1"]), float(el["ang2"]))
            ferme = TR.est_ferme_arc(float(el["ang1"]), float(el["ang2"]))
            s0 = TR.abscisse_pres(pts, True, (float(el["xc"]), float(el["yc"]) + float(el["r"]))) if ferme else 0.0
            cs += TR.chaine_ou_troncons(el["nom"], pts, float(el["a"]), int(el.get("cote", 1)), ferme, tr, s_origine=s0)
            L = TR.longueur_chemin(pts, ferme)
        else:
            p1, p2 = (float(el["x1"]), float(el["y1"])), (float(el["x2"]), float(el["y2"]))
            cs += _droit(el["nom"], p1, p2, float(el["a"]), int(el.get("cote", 1)), bool(el.get("retours", False)), tr)
            L, ferme = math.dist(p1, p2), False
        if tr["n"] >= 1:
            disc.append({"nom": el["nom"], "n": tr["n"], "l": tr["l"], "espacement": TR.espacement_troncons(L, ferme, tr["n"], tr["l"])})
    eff = Efforts(N=_kn(e.get("N", 0)), Vx=_kn(e.get("Vx", 0)), Vy=_kn(e.get("Vy", 0)), Mx=_knm(e.get("Mx", 0)),
                  My=_knm(e.get("My", 0)), Mz=_knm(e.get("Mz", 0)),
                  reference=(float(p.get("xR", 0)), float(p.get("yR", 0)), float(p.get("zR", 0))))
    pieces = {"vue": "plan", "elements": elements, "t_min": None}
    return {"cordons": cs, "efforts": eff, "beta_Lw": 1.0, "pieces": pieces, "discontinu": disc, "notes": []}


CONSTRUCTEURS = {"C1": c1, "C2": c2, "C3": c3, "C4": c4, "C5": c5, "C6": c6, "C7": c7, "C8": c8}


# ------------------------------------------------------------------ l'épaisseur qui fixe f_y et f_u de chaque pièce
def _paroi_profil(nom: str) -> Tuple[float, str]:
    """(épaisseur, produit) d'un profilé du catalogue : LA règle du site, ``acier/flambement/section.py`` (``epaisseur`` :
    un I ou un H pris comme un tout, sa paroi la plus épaisse max(t_f, t_w) — la plus petite f_y ; un tube, sa paroi t ;
    ``produit`` : fini à chaud ou formé à froid selon ``FABRICATION``), sans copie."""
    from acier.flambement import section as SEC
    rec = _profil(nom)
    return SEC.epaisseur(rec), (SEC.produit(rec) if rec["famille"] in SEC.FABRICATION else "lamine")


def _mm(t: float) -> str:
    return f"{t:g}".replace(".", ",")


def epaisseurs(config: Optional[str], p: Dict) -> Dict:
    """L'épaisseur nominale (mm) et le produit (« lamine », « creux_chaud », « creux_froid ») de chaque pièce — A le
    support, B la pièce rapportée : c'est elle qui fixe f_y et f_u (NBN EN 1993-1-1 ANB:2018, 3.2.1(1), option a ;
    tableaux 3.3 ANB à 3.11 ANB, ``acier/materiaux.py``). Une pièce simple prend SON épaisseur ; un profilé, sa paroi
    la plus épaisse (``_paroi_profil``). None : la configuration ne connaît pas l'épaisseur — les cordons libres C8 sans
    ``tA`` ni ``tB``, et eux seuls ; ailleurs, une épaisseur nulle, négative ou illisible est REFUSÉE (MA.HorsTable
    « épaisseur invalide », un refus nommé), jamais prise pour « inconnue ».

    Un support « plat » (C3, C4) n'a pas d'épaisseur saisie : celle que l'appelant connaît (``tA`` — le garde-corps y
    met sa platine), sinon celle du plat soudé t (la convention de ``t_min`` ci-dessus) — HYPOTHÈSE dite dans
    ``hypothese`` (l'aide des aciers et la note l'écrivent). Sans configuration (un appelant qui ne passe que les
    paramètres), chaque pièce prend la plus grande épaisseur saisie : du côté sûr."""
    def lam(t):
        try:
            x = float(t)
        except (TypeError, ValueError):
            raise MA.HorsTable(f"épaisseur invalide : {t!r}") from None
        if not x > 0.0:
            raise MA.HorsTable(f"épaisseur invalide : {x:g} mm")
        return (x, "lamine")
    if config is None:
        ts = [float(p[k]) for k in ("tA", "tB", "t", "tp") if isinstance(p.get(k), (int, float)) and p[k] > 0]
        for k in ("profil", "poteau"):
            if p.get(k) and p[k] != "plat":
                try:
                    ts.append(_paroi_profil(p[k])[0])
                except ValueError:
                    pass
        return {"A": lam(max(ts)) if ts else None, "B": lam(max(ts)) if ts else None}
    if config in ("C1", "C2"):
        return {"A": lam(p["tA"]), "B": lam(p["tB"])}
    if config in ("C3", "C4"):
        pot = _poteau(p)
        if pot:
            return {"A": _paroi_profil(pot["nom"]), "B": lam(p["t"])}
        if p.get("tA"):
            return {"A": lam(p["tA"]), "B": lam(p["t"])}
        B = lam(p["t"])
        return {"A": B, "B": B, "hypothese": f"pièce A (plat support) : épaisseur non saisie, prise égale à t = {_mm(B[0])} mm"}
    if config == "C5":
        return {"A": lam(p.get("tp", 15.0)), "B": _paroi_profil(p["profil"])}
    if config == "C6":
        return {"A": lam(p.get("tp", 15.0)), "B": _paroi_profil(p["profil"])}
    if config == "C7":
        return {"A": lam(p["t"]), "B": lam(p["t"])}
    if config == "C8":
        # cordons libres : la SEULE configuration où une épaisseur absente (ou 0) reste « inconnue »
        return {"A": lam(p["tA"]) if p.get("tA") else None, "B": lam(p["tB"]) if p.get("tB") else None}
    raise ValueError(f"configuration inconnue : {config}")


def construire(config: str, params: Dict, efforts: Dict) -> Dict:
    """Groupe de cordons, efforts et pièces d'une configuration."""
    if config not in CONSTRUCTEURS:
        raise ValueError(f"configuration inconnue : {config}")
    return CONSTRUCTEURS[config](params, efforts)
