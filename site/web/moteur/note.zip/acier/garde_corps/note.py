# -*- coding: utf-8 -*-
"""Note de calcul « Garde-corps » (version 3) — DEUX pages A4 paysage, sur le kit ``ndc_pdf`` des
notes de l'application (palette Encre, mêmes marges et mêmes polices que les notes d'assemblage,
de plancher et de soudures), avec les symboles COMPOSÉS (``ndc_pdf.riche`` : q_h, W_el,y, σ_adm en
vraie typographie, dans les hypothèses, les charges, les formules, les tableaux) et peu de prose.

Page 1 · CALCUL, les hypothèses d'abord :
- bandeau : statut, η max, l'élément gouvernant, son critère et son cas de charge, la méthode ;
- colonne 1 : HYPOTHÈSES en lignes « libellé · valeur » (garde-corps, hauteur, sections, acier,
  méthode, limites, fixation), les QUATRE CHARGES — le symbole et la valeur sur la première ligne,
  le nom et l'origine dessous —, la règle des cas, les DESSINS (élévation, coupe A-A, vue en
  plan) peints depuis les mêmes scènes que l'écran ;
- colonnes 2 et 3 : 1 · MONTANT (ou la console au mur), 2 · MAIN COURANTE, 3 · BARREAUX (ou lisses,
  ou panneau), 4 · ANCRAGE (soudure, chevilles ou boulons, platine) — chaque élément porte sa
  pastille η, son cas gouvernant et les autres cas, une ligne de données, puis ses formules
  DÉVELOPPÉES par GROUPE dans l'ordre de lecture (charges → sollicitations → contraintes → flèche
  → taux ; ``formules.py``, testées contre le moteur) avec le résultat calé à droite ; le
  RÉCAPITULATIF (barres de taux) ; la CONCLUSION.

Page 2 · DÉTAILS ET MÉTHODE : la platine en plan et la coupe sur la fixation, le tableau des
MONTANTS (ou des consoles), la section de l'élément principal et la BIBLIOTHÈQUE, la SOUDURE (vue
et formules du module Soudures), les textes de MÉTHODE (``methode.py``) de la méthode choisie,
les références, le cartouche.

``derniers_avertissements`` : débordements de colonne (vide si tout tient) ; la note est
d'abord composée en taille normale, puis en taille réduite si une colonne déborde.

Page 3 · SUITE (09/11/2026) — seulement quand une colonne déborde ENCORE en taille réduite (forme
L ou U avec « Cumuler qh et qv », montant soudé en L ou en U… : 86 des 240 états de la grille de
tests/test_note_garde_corps_grille.py) : les blocs du BAS de la colonne qui déborde passent, un à
un, sur une page de suite (``mise_en_page``), jusqu'à ce que tout tienne ; la colonne d'origine le
dit (« Suite p. 3 : … »). Un bloc reporté est d'abord dessiné, sur un brouillon, au moment où il
l'aurait été, puis redessiné en page 3 avec l'état de sa page d'alors (``Suite``) : sa numérotation
et son contenu ne changent pas. Une note
qui tient dans ses deux pages n'a pas de page 3 et ne change pas d'un caractère (preuve : la grille
figée). Avant, ces notes sortaient tronquées sans un mot (le récapitulatif sous la conclusion, la
bibliothèque sous le cartouche et hors de la page).
"""
import io
import math
import os
import re
import tempfile
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from reportlab.lib.pagesizes import A4, landscape

from ndc_pdf import data as ndc_data
from ndc_pdf import kit as KIT
from ndc_pdf import riche as RI
from ndc_pdf.kit import Doc, Frame, chip, hx, mix
from ndc_pdf.mathx import MathStyle
from ndc_pdf.styles import Encre
from acier.assemblages.poutre_poutre.doubles_cornieres.rapport import peindre as peindre_scene   # peintre des scènes du kit
from acier.soudures import formules as FOS
from acier.soudures import schemas as SCS

from . import bibliotheque as BI
from . import charges as CH
from . import etat as ET
from . import fixation as FX
from . import formules as FO
from . import membres as ME
from . import methode as MT
from . import schemas as SC
from . import types as TY

A4L = landscape(A4)
M, BAS, GAP = 22, 40, 12
LARG = (286, 246)
S_TAB_H = 5.6
LEAD_TAB = 8.8
LAB_W = 58
TITRE = "Garde-corps"
STATUTS = {ET.OK: ("CONFORME", "ok"), ET.ATTENTION: ("CONFORME · ATTENTION", "att"), ET.NOK: ("NON CONFORME", "ko"), ET.REFUS: ("CALCUL IMPOSSIBLE", "mut")}
VERT_PALE = "#D9ECDF"     # le fond d'une pastille η en dessous du seuil d'attention (code couleur du bureau, 06/11/2026)
MODES = {ME.ELS: "Vérification à l'ELS", ME.EUROCODE: "Eurocode (ELU)"}
MODES_PHRASE = {ME.ELS: "vérification à l'ELS (charges de service, contraintes admissibles)", ME.EUROCODE: "vérification à l'ELU selon l'Eurocode (efforts de calcul)"}
LEGENDE = ("Dessins à l'échelle, cotes en mm · ◉ l'élément gouvernant et son taux · flèches rouges : les charges (⊙ vers soi) · A-A : plan de la coupe · "
           "cordons en ocre à leur taille a·√2, chevilles en gris · chaque montant reçoit la charge de sa longueur tributaire.")
VARIANTES = ((1.0, "normale"), (0.92, "serrée"))
FIXATIONS = {"platine": "platine boulonnée", "laterale": "platine latérale en nez de dalle", "soudee": "montant soudé sur un plat existant", "scellee": "montant scellé"}
# Les BLOCS de chaque colonne, (page, rang de la colonne) → méthodes de la page, dans l'ordre de lecture : la
# composition des pages ET l'ordre dans lequel les blocs du bas d'une colonne qui déborde passent en page 3
BLOCS = {(1, 0): ("hypotheses", "table_charges", "dessins"),
         (1, 1): ("element_principal", "main_courante", "recapitulatif"),
         (1, 2): ("remplissage", "ancrage"),
         (2, 0): ("details_fixation", "table_montants", "section_et_bibliotheque"),
         (2, 1): ("soudure",),
         (2, 2): ("methode",)}
# le nom d'un bloc dans la mention « Suite p. 3 : … » de sa colonne d'origine
NOMS_BLOCS = {"hypotheses": "hypothèses", "table_charges": "charges", "dessins": "dessins", "element_principal": "élément principal",
              "main_courante": "main courante", "recapitulatif": "récapitulatif", "remplissage": "remplissage", "ancrage": "ancrage",
              "details_fixation": "détail de l'ancrage", "table_montants": "tableau des montants",
              "section_et_bibliotheque": "section et bibliothèque", "soudure": "soudure", "methode": "méthode et références"}
TITRES_PAGES = {1: "calcul", 2: "détails et méthode"}


class Debord(str):
    """Un débordement de colonne : le texte de toujours (« page 1, colonne 320 : 28 pt ») et la colonne qui déborde,
    ``colonne`` = (page, rang) — ce que ``mise_en_page`` lit pour savoir quel bloc passer en page 3."""

    def __new__(cls, page: int, rang: int, x: float, pt: float):
        s = str.__new__(cls, f"page {page}, colonne {x:.0f} : {pt:.0f} pt")
        s.colonne = (page, rang)
        return s


def _etat_page(page):
    """L'état d'une page (et de la page 1 qu'une page 2 emprunte pour ses briques) : ses attributs, copiés."""
    return [(o, dict(vars(o))) for o in (page, getattr(page, "note1", None)) if o is not None]


def _remettre(etat):
    for o, attrs in etat:
        o.__dict__.clear()
        o.__dict__.update(attrs)


def _colonne(page, d, fr, cle):
    """Les blocs de la colonne ``cle`` posés dans ``fr`` ; ceux que la page de suite prend (les derniers) y partent."""
    suite = page.suite
    reportes = []
    for nom in BLOCS[cle]:
        if suite is not None and suite.prend(cle, nom):
            reportes.append(nom)
        else:
            getattr(page, nom)(d, fr)
    if reportes:
        suite.reporter(d, page, cle, reportes, fr)


def _fmt(x, nd=1) -> str:
    if x is None:
        return "—"
    if isinstance(x, float) and (math.isinf(x) or math.isnan(x)):
        return "∞"
    return f"{x:,.{nd}f}".replace(",", " ").replace(".", ",")


def _g(v) -> str:
    return f"{float(v):g}".replace(".", ",")


def _pct(t) -> str:
    if t is None:
        return "—"
    return f"{t * 100:.0f} %"


def _cas(lbl: Optional[str]) -> str:
    """Un libellé de cas de charge en texte riche (« cas 1 · $q_h$ seule »)."""
    return RI.auto(lbl or "")


def _efforts(txt: str) -> str:
    """« N = 0,00 kN, V = 0,45 kN, M = 0,495 kN·m (…) » avec ses symboles composés."""
    return re.sub(r"\b([NVMP]) = ", r"$\1$ = ", txt)


def _sans_parentheses(txt: str) -> str:
    return re.sub(r"\s*\([^)]*\)", "", txt).strip()


class Calcul:
    """Tout ce que la note imprime, calculé une fois : moteur, dessins, textes."""

    def __init__(self, etat: Dict, cas: Dict):
        self.etat, self.cas = etat, ET.normaliser_cas(cas)
        self.res = ET.verifier(self.cas)
        vues = SC.vues(self.res, SC.options_schemas(lvl=1))
        self.vues = {cle: d for cle, _, d in vues}
        self.titres = {cle: t for cle, t, _ in vues}
        if "coupe" in self.vues:
            # la coupe A-A, à côté de l'élévation, reçoit une police plus grande : elle est peinte petite
            opt = SC.options_schemas(lvl=1)
            opt.fs_force = 44.0
            self.vues["coupe"] = SC.coupe(self.res, opt)
        self.meth = self.res["methode"]
        self.acier = self.res["acier"]
        self.fo = FO.toutes(self.res)
        s = (self.res.get("fixation") or {}).get("soudure")
        self.vues_soudure = SCS.vues(s["res"], SCS.options_schemas(lvl=1)) if s else []

    def systeme(self) -> str:
        return self.cas["geometrie"].get("systeme", "montants")

    def type_libelle(self) -> str:
        return TY.TYPES[TY.type_de(self.cas)]["libelle"]

    def sous_titre(self) -> str:
        lib = self.type_libelle().lower()
        if self.res["geometrie"].get("sans_montant"):
            return lib.replace(" sur montants", "") + " de mur à mur"
        return lib + ("" if self.systeme() == "mur" or " sur " in lib else " sur montants")

    def fleche_adm(self) -> str:
        m = self.meth
        return f"$L$/{_g(m.get('fleche_val', 100))}" if m.get("fleche_mode", "L/x") == "L/x" else f"{_g(m.get('fleche_val', 0))} mm"

    # --- les hypothèses, en lignes « libellé · valeur » (valeur en texte riche)
    def hypotheses(self) -> List[Tuple[str, str]]:
        res, cas, geo = self.res, self.cas, self.res["geometrie"]
        L = [("Garde-corps", f"{self.type_libelle()} · {geo['phrase']}")]
        if self.systeme() == "mur":
            c = res.get("console") or {}
            L.append(("Hauteur", f"$H$ = {_g(geo['H'])} mm{self.h_defaut()} au-dessus du sol · consoles à $e$ = {_g(c.get('e', 0))} mm du mur"))
            L.append(("Consoles", (c.get("section") or {}).get("nom", "—")))
        elif geo.get("sans_montant"):
            L.append(("Hauteur", f"$H$ = {_g(geo['H'])} mm{self.h_defaut()} au-dessus de la dalle"))
            L.append(("Montants", "aucun : la main courante porte de mur à mur"))
        elif geo.get("laterale"):
            L.append(("Hauteur", f"$H$ = {_g(geo['H'])} mm{self.h_defaut()} au-dessus de la dalle · descente $d_h$ = {_g(geo['d_h'])} mm jusqu'au haut de la platine latérale : "
                                 f"le montant est une console de {_g(geo['H_post'])} mm"))
            L.append(("Montants", (res.get("section_montant") or {}).get("nom", "—")))
        else:
            L.append(("Hauteur", f"$H$ = {_g(geo['H'])} mm{self.h_defaut()} au-dessus de la platine"))
            L.append(("Montants", (res.get("section_montant") or {}).get("nom", "—")))
        li = (res.get("lisse") or {}).get("section") or {}
        L.append(("Main courante", f"{li.get('nom', '—')} · portée {_g(geo['s_max'])} mm, {ME.APPUIS[cas['lisse'].get('appuis', 'deux')]}"))
        rp = res.get("remplissage") or {}
        if rp.get("type") == "barreaux" and rp.get("section"):
            L.append(("Barreaux", f"{rp['section']['nom']} · $e_b$ = {_g(rp['entraxe'])} mm · portée {_g(round(rp['L']))} mm, déduite de $H$, $h_{{bas}}$ = {_g(rp['h_bas'])} mm et des sections"))
            if rp.get("section_basse"):
                L.append(("Lisse basse", f"{rp['section_basse']['nom']} (non calculée)"))
        elif rp.get("type") == "lisses" and rp.get("section"):
            L.append(("Lisses", f"{rp.get('n', 1)} lisses intermédiaires {rp['section']['nom']} · $e_l$ = {_g(rp['entraxe'])} mm"))
        elif rp.get("type") == "panneau":
            L.append(("Panneau", "verre, tôle ou câbles, justifié par son fournisseur" + (f" · lisse basse {rp['section_basse']['nom']}" if rp.get("section_basse") else "")))
        else:
            L.append(("Remplissage", "sans remplissage"))
        ac, m, lim = self.acier, self.meth, res["limites"]
        # la valeur RETENUE (chaque élément est vérifié à l'acier de SON épaisseur, NBN EN 1993-1-1 ANB 3.2.1(1)) : la plus épaisse des pièces
        fy_txt = (f"$f_y$ = {_g(ac['fy'])} N/mm²{ET.origine_retenue(ac)} · $f_u$ = {_g(ac['fu'])} N/mm²" if ac.get("fy") is not None
                  else "$f_y$, $f_u$ : —")
        L.append(("Acier", f"{ac['nuance']} · {fy_txt} · $E$ = {_fmt(float(m.get('E') or ME.E_ACIER), 0)} N/mm²"))
        fl = self.fleche_adm()
        commune = ET.texte_limite_commune(ac)      # la limite commune est la plus faible ; chaque élément à la sienne
        if m["mode"] == ME.ELS:
            L.append(("Vérification", f"à l'ELS, charges de service sans coefficient : $σ$ ≤ $σ_{{adm}}$ = $f_y$/{_g(lim['coef'])} = {_fmt(lim['sigma'])} N/mm²{commune} · "
                                      f"$τ$ ≤ $τ_{{adm}}$ = $σ_{{adm}}$/$\\sqrt{{3}}$ = {_fmt(lim['tau'])} N/mm² · $σ_{{eq}}$ = $\\sqrt{{σ^2 + 3τ^2}}$ ≤ $σ_{{adm}}$ · "
                                      f"flèche ≤ {fl} · soudure $k$ = {_g(m.get('k', 100))} kg/(mm·cm) · ancrages : résistances de calcul / $γ_F$ = {_g(m.get('gamma_F', 1.5))}"))
        else:
            L.append(("Vérification", f"à l'ELU selon l'Eurocode, charges × $γ_Q$ = {_g(m.get('gamma_Q', 1.5))} : $σ$ ≤ $f_y/γ_{{M0}}$ = {_fmt(lim['sigma'])} N/mm²{commune} (élastique, $W_{{el}}$) · "
                                      f"$τ$ ≤ $f_y/(\\sqrt{{3}}·γ_{{M0}})$ = {_fmt(lim['tau'])} N/mm² · $σ_{{eq}}$ = $\\sqrt{{σ^2 + 3τ^2}}$ ≤ $f_y/γ_{{M0}}$ · flèche ≤ {fl} sous charges de service · "
                                      f"soudure EN 1993-1-8 {m.get('ec', 'directionnelle')}, $γ_{{M2}}$ = {_g(m.get('gamma_M2', 1.25))}"))
        L.append(("Fixation", self.hyp_fixation()))
        sans = bool(geo.get("sans_montant"))               # sans montant, le bloc « ancrage » dit déjà les réactions des murs
        for msg in [x for x in res.get("messages", []) if not x.startswith("Refus") and not x.startswith("Sans montant") and not x.startswith("Montant scellé")
                    and not x.startswith("Hauteur non saisie")
                    and not (sans and x.startswith("Ancrage de la main courante dans le mur"))][:2]:
            L.append(("Note", RI.auto(msg)))
        return L

    def h_defaut(self) -> str:
        """« (champ vide : valeur par défaut) » après la hauteur quand le champ H est resté vide (brief v12 § 19.1 point 8)."""
        return " (champ vide : valeur par défaut)" if self.res["geometrie"].get("H_defaut") else ""

    def hyp_fixation(self) -> str:
        fx = self.cas["fixation"]
        typ = fx.get("type", "platine")
        if self.res["geometrie"].get("sans_montant"):
            return "sans montant : la main courante est ancrée dans les murs, ses ancrages sont à justifier avec les réactions du calcul"
        if typ == "scellee":
            return "montant scellé : la fixation n'est pas vérifiée"
        pl, anc = fx["platine"], fx["ancrage"]
        if typ == FX.LATERALE and self.systeme() == "montants":
            return (f"{FIXATIONS[typ]} · {RI.auto(FX.texte_platine(fx))} · soudure {RI.auto(FX.texte_soudure(fx['soudure']))} le long de la platine · "
                    f"{RI.auto(FX.texte_ancrage(anc))}, rangées à $e_x$ = {_g(anc['ex'])} mm (vertical), colonnes à $e_y$ = {_g(anc['ey'])} mm")
        s = f"{FIXATIONS[typ]} · soudure {RI.auto(FX.texte_soudure(fx['soudure']))}"
        if typ in ("platine", FX.LATERALE):
            s += f" · platine {_g(pl['bp'])} × {_g(pl['lp'])} × {_g(pl['tp'])} mm · {RI.auto(FX.texte_ancrage(anc))}, rangées à $e_x$ = {_g(anc['ex'])} mm, $e_y$ = {_g(anc['ey'])} mm"
        return s

    def reactions_murs(self) -> List[Tuple[str, float, float]]:
        """Les réactions (kN, service) de la main courante à chaque mur d'extrémité : (où, H, V)."""
        geo, ch = self.res["geometrie"], self.res["charges"]
        s_max = geo.get("s_max") or 0.0
        qh = (ch["P"] * 1e3 / s_max if ch["mode"] == "P" else ch["qh"]) if s_max > 0 else 0.0
        return [(r["ou"], qh * r["trib"] / 1e3, ch["qv"] * r["trib"] / 1e3) for r in geo.get("reprises_mur", [])]

    def ligne_cas(self) -> str:
        if self.res["charges"].get("cumul"):
            return "$q_h$ et $q_v$ agissent ensemble (cas 1 + 2, côté sûr) ; $Q_r$ et $q_r$ en cas séparés (3 et 4) ; chaque élément est vérifié sous chaque cas, le pire gouverne."
        return "Les quatre charges agissent SÉPARÉMENT (cas 1 à 4) : chaque élément est vérifié sous chaque cas, le pire gouverne."

    def charges_lignes(self) -> List[Dict]:
        rows = list(self.res["charges_tableau"])
        ch = self.res["charges"]
        if ch.get("Q", 0) > 0:
            rows.append({"n": "+", "symbole": "Q", "nom": "charge ponctuelle horizontale sur la main courante", "valeur": ch["Q"], "unite": "kN",
                         "norme": f"option, {self.meth.get('comb', 'somme')} avec q_h"})
        return rows

    def role_principal(self) -> str:
        return "lisse" if self.systeme() == "mur" or self.res["geometrie"].get("sans_montant") else "montant"

    def taux_de(self, cle: str) -> Optional[float]:
        for e in self.res.get("elements", []):
            if e["cle"] == cle:
                return e["taux"]
        return None


class Note:
    """Page 1 · CALCUL."""

    def __init__(self, calc: Calcul, doc_meta: Dict, k: float = 1.0, suite: Optional["Suite"] = None):
        self.C, self.doc, self.k = calc, doc_meta, k
        self.suite = suite
        self.S = Encre()
        self.warnings: List[str] = []
        self.s_txt = 6.1 * k
        self.s_tab = 6.2 * k
        self.lead = LEAD_TAB * k
        self.echelle = None
        self._ms: Dict = {}
        self.n_bloc = 0

    def numero(self) -> str:
        """Le numéro du prochain bloc d'élément (1 · MONTANT, 2 · MAIN COURANTE…), dans l'ordre de lecture."""
        self.n_bloc += 1
        return f"{self.n_bloc} · "

    # --- composition
    def ms(self, col=None, op=None, res=None) -> MathStyle:
        """Le style mathématique d'un texte : symboles en Carlito italique, mots et nombres en romain,
        opérateurs dans la couleur ``op`` (grise dans les formules), résultat en gras ``res``."""
        S = self.S
        key = (str(col), str(op), str(res))
        st = self._ms.get(key)
        if st is None:
            st = MathStyle(var="Carlito-Italic", rom="Carlito", num="Carlito", op="Carlito", ink=hx(col or S.ink), accent=hx(S.acc), rule=hx(col or S.ink),
                           res="Carlito-Bold", res_color=hx(res or S.acc), op_color=hx(op) if op else None, tight=0.88)
            self._ms[key] = st
        return st

    def rt(self, d, x, y, s, size, col=None, font=None, align="left", width=None):
        col = col or self.S.ink
        return RI.texte(d, x, y, s, font or self.S.f_b, size, col, self.ms(col), align, width)

    def rp(self, d, fr, s, size=None, col=None, font=None, indent=0, lead=1.32, max_lignes=None):
        col = col or self.S.ink
        return RI.paragraphe(d, fr, s, font or self.S.f_b, size or self.s_txt, col, self.ms(col), lead, indent, max_lignes)

    # --- briques
    def couleurs_eta(self, taux) -> Tuple[str, str]:
        """(texte, fond) d'une pastille η — le code couleur des taux, les seuils du moteur (``membres.statut``) :
        rouge au-dessus de 100 %, vert foncé de 95 à 100 %, vert pâle (texte vert) en dessous."""
        S = self.S
        s = ME.statut(taux)
        if s == ET.NOK:
            return "#FFFFFF", S.ko
        if s == ET.ATTENTION:
            return "#FFFFFF", S.ok
        return S.ok, VERT_PALE

    def titre(self, d, fr, txt, taux=None):
        """Un titre de bloc en petites capitales espacées, sa pastille η à droite ; il se resserre avant de se tronquer."""
        S = self.S
        fr.down(10)
        wc = 0.0
        if taux is not None:
            lab = "η " + _pct(taux)
            wc = d.w(lab, "Carlito-Bold", 5.8) + 10
            fg, bg = self.couleurs_eta(taux)
            chip(d, fr.x1 - wc, fr.y - 2.5, lab, "Carlito-Bold", 5.8, fg, bg, pad=5, h=8.4)
        avail = fr.w - (wc + 6 if wc else 0.0)
        size, track = 6.2, 1.3
        while size > 5.0 and d.w(txt, S.f_v, size) + track * len(txt) > avail:
            size -= 0.2
            track -= 0.1
        d.t(fr.x, fr.y, d.fit(txt, S.f_v, size, avail - track * len(txt)), S.f_v, size, S.acc, track=track)
        fr.down(3.2)
        d.line(fr.x, fr.y, fr.x1, fr.y, mix(S.rule, S.ink, 0.12), 0.5)

    def etiquette(self, d, fr, txt):
        """Le libellé d'un groupe de formules, en petites capitales grises (tronqué à la colonne)."""
        fr.down(self.s_txt * 1.6)
        size = 4.9 * self.k
        d.t(fr.x, fr.y, d.fit(txt.upper(), self.S.f_v, size, fr.w - 1.0 * len(txt)), self.S.f_v, size, self.S.mut, track=1.0)

    def ligne_hyp(self, d, fr, label, val, col=None):
        """« LIBELLÉ   valeur » : le libellé en petites capitales à gauche, la valeur composée à droite, repliée."""
        S = self.S
        size = self.s_txt
        col = col or S.ink
        lab_w = LAB_W * self.k
        lignes = RI.envelopper(val, S.f_b, size, self.ms(col), fr.w - lab_w)
        fr.down(size * 1.42)
        d.t(fr.x, fr.y + 0.2, label.upper(), S.f_v, 4.9 * self.k, S.mut, track=0.9)
        for i, l in enumerate(lignes):
            if i:
                fr.down(size * 1.3)
            RI.dessiner(d, fr.x + lab_w, fr.y, l, S.f_b, size, col, self.ms(col))

    def barre(self, d, x, y, w, taux, col):
        """Une barre de taux : la piste vaut 100 %, le remplissage s'arrête au taux (plein au-delà)."""
        S = self.S
        d.box(x, y, w, 2.6, fill=mix(S.rule, "#FFFFFF", 0.35), r=1.3)
        d.box(x, y, max(2.6, w * min(taux, 1.0)), 2.6, fill=col, r=1.3)

    def table(self, d, fr, titre, cols, lignes, note=None):
        """Un tableau : cellules ``(style, texte riche, …)`` — lab (gras si retenu), ref (gris), num (à droite, gras),
        eta (couleur du verdict, gras si gouverne, barre de taux si un taux est donné). Le corps est la brique
        partagée ``ndc_pdf.kit.table`` (texte riche : ``ms``), le titre et la barre de taux restent ceux de la note."""
        if titre:
            self.titre(d, fr, titre)
        fr.down(8)
        KIT.table(d, fr, cols, lignes, self.S, self.s_tab, self.lead, S_TAB_H, ms=self.ms, note=note, barre=self.barre)

    def formules(self, d, fr, groupes, indent=4):
        """Les formules par groupe : l'étiquette du groupe, puis chaque substitution « nom = littéral =
        numérique » avec son résultat calé à droite (les taux η en vert ou en rouge)."""
        S = self.S
        size = self.s_txt
        ms = self.ms(S.ink, op=S.mut)
        for lib, subs in groupes:
            if not subs:
                continue
            if lib:
                self.etiquette(d, fr, lib)
            for sub in subs:
                parts, res = FO.morceaux(sub)
                col_res = None
                if sub.nom.startswith("η") and sub.res is not None and math.isfinite(sub.res):
                    col_res = S.ok if sub.res <= 1.0 else S.ko
                RI.formule_calee(d, fr, [RI.tex(p) for p in parts], self.res_tex(sub, res), ms, size, ms_res=self.ms(S.ink, op=S.mut, res=col_res),
                                 indent=indent, retrait=10, lead=1.38, min_size=4.8, cale="droite" if col_res is not None else "suite")

    @staticmethod
    def res_tex(sub, res: str) -> str:
        """Le résultat d'une substitution en mini-LaTeX accentué : « \\res{0,45 \\t{kN}} »."""
        if sub.nd == -1 or not sub.unit:
            return r"\res{" + RI.tex(res) + "}"
        return r"\res{" + RI.tex(FO.fmt(sub.res, sub.nd)) + r" \t{" + sub.unit + "}}"

    def bloc(self, d, fr, titre, bloc, taux=None, donnees=None):
        """Un élément : titre et pastille η, le cas qui gouverne et les autres cas, la ligne de données, les formules par groupe."""
        if not bloc or not bloc.get("subs"):
            return
        S = self.S
        self.titre(d, fr, titre, taux)
        fr.down(0.5)
        if bloc.get("cas"):
            autres = ", ".join(f"{_cas(lib)} ({_pct(t)})" for lib, t in bloc.get("cas_taux", []))
            self.rp(d, fr, f"Gouverne : {_cas(bloc['cas'])}" + (f" · autres cas : {autres}" if autres else ""), size=self.s_txt * 0.95, col=S.mut)
        if donnees:
            self.rp(d, fr, donnees, size=self.s_txt * 0.95, col=S.mut)
        self.formules(d, fr, bloc["groupes"])
        fr.down(2)

    # --- bandeau
    def bandeau(self, d):
        S, C, doc = self.S, self.C, self.doc
        res, cas = C.res, C.cas
        W, H = d.W, d.H
        y = H - M - 4
        d.t(M, y, doc.get("bureau", ""), S.f_v, 8.0, S.acc, track=1.4)
        d.t(W - M, y, "Note de calcul · " + doc.get("date", "") + " · indice " + str(doc.get("indice", "")), S.f_b, 8, S.mut, "right")
        y -= 15
        d.t(M, y, f"{TITRE} — {C.sous_titre()}", S.f_h, 12.5, S.ink)
        ident = " · ".join(str(x) for x in (doc.get("projet"), doc.get("partie"), "cas " + cas["nom"]) if x)
        d.t(W - M, y, d.fit(ident, S.f_b, 8, 300), S.f_b, 8, S.ink, "right")
        y -= 8
        d.line(M, y, W - M, y, S.ink, 1.0)
        y -= 15
        libelle, cle = STATUTS[res["statut"]]
        col = {"ok": S.ok, "att": S.att, "ko": S.ko, "mut": S.mut}[cle]
        w = chip(d, M, y - 3.2, libelle, S.f_v, 6.6, "#FFFFFF", col)
        x = M + w + 8
        g = res.get("gouvernant")
        if res["statut"] == ET.REFUS or not g:
            d.t(x, y, d.fit((res["messages"] or ["—"])[0], S.f_b, 8, W - M - x), S.f_b, 8, S.ink)
        else:
            t1 = "η max " + _pct(res["taux_max"])
            d.t(x, y, t1, "Carlito-Bold", 8.6, col)
            x += d.w(t1, "Carlito-Bold", 8.6) + 5
            crit = ME.critere_texte(g["critere"]) if g["cle"] not in ("soudure", "ancrage", "platine") else g["critere"]
            cas_g = (next((e for e in res["elements"] if e["cle"] == g["cle"]), {}).get("detail") or {}).get("cas_charge")
            t2 = f"— gouverne : {RI.auto(g['libelle'])} · {RI.auto(crit)}" + (f" · {_cas(CH.CAS_LIBELLES.get(cas_g, cas_g))}" if cas_g else "")
            t3 = FO.TITRES[FO.cle_methode(res)]
            wt = d.w(t3, "Carlito-Bold", 7.6)
            xr = W - M - wt
            self.rt(d, x, y, t2, 8, S.ink, width=xr - x - 6)
            d.t(xr, y, t3, "Carlito-Bold", 7.6, S.acc)
        y -= 6
        d.line(M, y, W - M, y, mix(S.rule, S.ink, 0.3), 0.6)
        return y - 4

    # --- colonne 1 : hypothèses, charges, dessins
    def hypotheses(self, d, fr):
        self.titre(d, fr, "HYPOTHÈSES")
        fr.down(1)
        for label, val in self.C.hypotheses():
            self.ligne_hyp(d, fr, label, val, self.S.mut if label == "Note" else None)
        fr.down(2)

    def table_charges(self, d, fr):
        """Les charges, une à une : le symbole et la valeur sur la première ligne, le nom dessous, l'origine en gris."""
        S, C = self.S, self.C
        st = self.s_tab
        self.titre(d, fr, "CHARGES — " + C.res["limites"]["nature"].split(" (")[0] + ", quatre cas de charge")
        fr.down(8)
        x_sym = fr.x + 14
        d.t(fr.x, fr.y, "N°", S.f_b, S_TAB_H, S.mut)
        d.t(x_sym, fr.y, "CHARGE", S.f_b, S_TAB_H, S.mut)
        d.t(fr.x1 - 3, fr.y, "VALEUR", S.f_b, S_TAB_H, S.mut, "right")
        fr.down(2.5)
        d.line(fr.x, fr.y, fr.x1, fr.y, S.acc, 0.5)
        for c in C.charges_lignes():
            fr.down(st * 1.8)
            d.t(fr.x + 8, fr.y, str(c["n"]), "Carlito-Bold", st, S.mut, "right")
            self.rt(d, x_sym, fr.y, "$" + RI.tex(c["symbole"]) + "$", st * 1.2, S.ink)
            d.t(fr.x1 - 3, fr.y, _fmt(c["valeur"], 2) + " " + c["unite"], "Carlito-Bold", st, S.ink, "right")
            self.rp(d, fr, c["nom"], size=st * 0.95, indent=14, lead=1.3, max_lignes=2)
            self.rp(d, fr, RI.auto(c["norme"]), size=st * 0.86, col=S.mut, indent=14, lead=1.26, max_lignes=2)
            fr.down(2.4)
            d.line(fr.x, fr.y, fr.x1, fr.y, mix(S.rule, S.ink, 0.06), 0.4)
        fr.down(st * 0.4)
        self.rp(d, fr, C.ligne_cas(), size=st * 0.9, col=S.mut, lead=1.24)
        fr.down(2)

    def dessins(self, d, fr):
        S, C = self.S, self.C
        vues = C.vues
        self.titre(d, fr, "DESSINS — élévation, coupe A-A, plan (détails p. 2)")
        dispo = fr.room() - 6
        if not vues:
            fr.down(20)
            d.t(fr.x, fr.y + 6, (C.res.get("messages") or ["Calcul impossible"])[0][:90], S.f_b, self.s_txt, S.ko)
            return
        # l'élévation et la coupe A-A côte à côte (comme sur une planche), la vue en plan dessous
        d0, dc = vues["elevation"], vues.get("coupe")
        w0 = 0.72 * fr.w if dc is not None else fr.w
        h0 = min(max(70.0, w0 * d0.viewbox[3] / d0.viewbox[2], (fr.w - w0 - 4) * dc.viewbox[3] / dc.viewbox[2] if dc is not None else 0.0), 0.66 * dispo)
        fr.down(h0 + 3)
        self.echelle = peindre_scene(d, d0, fr.x, fr.y, w0, h0)
        if dc is not None:
            peindre_scene(d, dc, fr.x + w0 + 4, fr.y, fr.w - w0 - 4, h0)
        dp = vues.get("plan")
        if dp is not None:
            h1 = min(max(40.0, fr.w * dp.viewbox[3] / dp.viewbox[2]), dispo - h0 - 10)
            fr.down(h1 + 3)
            peindre_scene(d, dp, fr.x, fr.y, fr.w, h1 - 2)

    # --- colonnes 2 et 3 : les éléments un à un, avec leurs formules
    def element_principal(self, d, fr):
        C = self.C
        res = C.res
        if C.systeme() == "montants" and res.get("montant"):
            m = res["montant"]
            v = m["verif"]
            geo = res["geometrie"]
            h_txt = (f"$H$ = {_g(v['H'])} mm ({_g(geo['H'])} au-dessus de la dalle + descente $d_h$ = {_g(geo['d_h'])})" if geo.get("laterale")
                     else f"$H$ = {_g(v['H'])} mm")
            self.bloc(d, fr, f"{self.numero()}MONTANT {m['nom']} — {m['section']['nom']}", C.fo["montant"], C.taux_de("montant"),
                      f"{h_txt} · " + (f"$s_{{trib,1}}$ = {_g(v['trib2'] if v.get('orientation_inversee') else v['trib1'])} mm · $s_{{trib,2}}$ = {_g(v['trib1'] if v.get('orientation_inversee') else v['trib2'])} mm"
                                 if v["coin"] else f"$s_{{trib}}$ = {_g(v['trib1'] + v['trib2'])} mm") + " · console encastrée en pied" + (" · montant d'angle : deux directions" if v["coin"] else ""))
        elif res.get("console"):
            c = res["console"]
            v = c["verif"]
            self.bloc(d, fr, f"{self.numero()}CONSOLE {c['nom']} — {c['section']['nom']}", C.fo["console"], C.taux_de("console"),
                      f"$e$ = {_g(c['e'])} mm du mur · $s_{{trib}}$ = {_g(v['trib1'] + v['trib2'])} mm · encastrée dans le mur")

    def main_courante(self, d, fr):
        C = self.C
        li = C.res.get("lisse")
        if not li:
            return
        v = li["verif"]
        cont = li["appuis"] == "continue" and li["n_travees"] >= 2
        donnees = f"$L$ = {_g(v['L'])} mm (l'entraxe le plus grand) · {ME.APPUIS['continue'] if cont else ME.APPUIS['deux']}"
        if cont and v.get("kM"):
            donnees += f" · {li['n_travees']} travées : $k_M$ = {_g(v['kM'])}, $k_V$ = {_g(v['kV'])}, $k_f$ = {_g(v['kf'])}"
        if C.res["geometrie"].get("sans_montant"):
            donnees = f"$L$ = {_g(v['L'])} mm de mur à mur · {ME.APPUIS['deux']} · la main courante est l'élément porteur"
        self.bloc(d, fr, f"{self.numero()}MAIN COURANTE — {li['section']['nom']}", C.fo["lisse"], C.taux_de("lisse"), donnees)

    def remplissage(self, d, fr):
        C = self.C
        rp = C.res.get("remplissage") or {}
        if rp.get("verif"):
            v = rp["verif"]
            barreaux = rp["type"] == "barreaux"
            nom = "BARREAUX" if barreaux else "LISSES INTERMÉDIAIRES"
            ent = ("$e_b$" if barreaux else "$e_l$") + f" = {_g(rp['entraxe'])} mm"
            self.bloc(d, fr, f"{self.numero()}{nom} — {rp['section']['nom']}", C.fo["barre"], C.taux_de("barreau" if barreaux else "lisse_inter"),
                      f"$L$ = {_g(round(v['L']))} mm · {ent} · sur deux appuis · $Q_r$ à mi-portée (cas 3) ou $q_r$ × entraxe (cas 4)")
        elif rp.get("type") == "panneau":
            self.titre(d, fr, f"{self.numero()}PANNEAU")
            fr.down(1)
            self.rp(d, fr, f"Remplissage en panneau (verre, tôle, câbles) : sa résistance sous $Q_r$ = {_g(C.res['charges']['Qr'])} kN et $q_r$ = {_g(C.res['charges']['qr'])} kN/m² "
                           "est à justifier par le fournisseur ; la lisse basse n'est pas calculée.")
            fr.down(2)

    def ancrage(self, d, fr):
        S, C = self.S, self.C
        fx = C.res.get("fixation") or {}
        s = fx.get("soudure")
        if C.res["geometrie"].get("sans_montant"):
            self.titre(d, fr, f"{self.numero()}ANCRAGE — main courante ancrée dans les murs")
            fr.down(1)
            self.rp(d, fr, "Chaque mur reprend une demi-travée de la main courante ; les ancrages (chevilles, scellements) sont à justifier avec ces réactions de service :",
                    size=self.s_txt * 0.95, col=S.mut)
            for ou, Hr, Vr in C.reactions_murs():
                self.rp(d, fr, f"mur de {ou} : $H$ = {_fmt(Hr, 2)} kN (horizontal, du $q_h$) · $V$ = {_fmt(Vr, 2)} kN (vertical, du $q_v$)", indent=4)
            fr.down(2)
            return
        if not s:
            if C.cas["fixation"].get("type") == "scellee":
                self.titre(d, fr, f"{self.numero()}ANCRAGE — montant scellé")
                fr.down(1)
                self.rp(d, fr, "Montant scellé : la fixation n'est pas vérifiée (scellement à justifier séparément).")
            return
        pl = fx.get("platine")
        typ = C.cas["fixation"].get("type", "platine")
        if typ == FX.LATERALE and C.systeme() == "mur":
            typ = "platine"
        cas_g = (pl or {}).get("cas_charge") or s.get("cas_charge")
        self.titre(d, fr, f"{self.numero()}ANCRAGE — " + FIXATIONS.get(typ, typ), fx.get("taux_max"))
        fr.down(0.5)
        ou = "au centre de la platine latérale" if typ == FX.LATERALE else ("à la platine de la console" if self.C.systeme() == "mur" else "en pied du montant")
        self.rp(d, fr, f"Gouverne : {_cas(CH.CAS_LIBELLES.get(cas_g, cas_g))} · {ou} : {_efforts(s['efforts_txt'])}", size=self.s_txt * 0.95, col=S.mut)
        fos = C.fo["soudure"]
        lib_s = (f"Soudure — deux cordons le long de la platine ({s['res']['config']}), détail p. 2" if typ == FX.LATERALE
                 else f"Soudure — {s['res']['config']} du module Soudures, {s['position']}, détail p. 2")
        groupes = [(lib_s, (fos["point"][:1] if fos["point"] else []) + fos["critere"])]
        if pl and pl.get("taux_max") is not None:
            groupes += C.fo["platine"]["groupes"]
        self.formules(d, fr, groupes)
        if pl and pl.get("taux_max") is None:
            for m in pl.get("messages", []):
                self.rp(d, fr, m, col=S.ko)
        fr.down(2)

    def recapitulatif(self, d, fr):
        C = self.C
        res = C.res
        g = res.get("gouvernant") or {}
        rows = []
        for e in res.get("elements", []):
            dd = e["detail"] if isinstance(e["detail"], dict) else {}
            gouv = e["cle"] == g.get("cle")
            cas_c = CH.CAS_LIBELLES.get(dd.get("cas_charge"), dd.get("cas_charge") or "—")
            crit = ME.critere_texte(e["critere"]) if e["cle"] in ("montant", "lisse", "barreau", "lisse_inter", "console") else e["critere"]
            lib = [_sans_parentheses(x) for x in e["libelle"].split(" · ")]
            if e["cle"] == "ancrage" and len(lib) > 1:
                lib[0] = "Ancrages"                                # le détail dit déjà « 2 × 2 chevilles M12 » ou « 2 × 2 boulons M12 8.8 »
            rows.append([("lab", RI.auto(" · ".join(lib[:2])), gouv), ("ref", _cas(cas_c).replace("cas ", "")), ("eta", _pct(e["taux"]), e["taux"] <= 1.0, gouv, e["taux"]),
                         ("ref", RI.auto(crit[:24]))])
        if not rows:
            return
        w = fr.w
        cols = [("ÉLÉMENT", w - 48 - 44 - 46, "left"), ("CAS", 48, "left"), ("η", 44, "right"), ("CRITÈRE", 46, "left")]
        self.s_tab = 6.0 * self.k
        self.table(d, fr, "RÉCAPITULATIF — éléments, cas gouvernants, taux", cols, rows)
        self.s_tab = 6.2 * self.k

    def conclusion(self, d, x, w):
        S, C = self.S, self.C
        res = C.res
        libelle, cle = STATUTS[res["statut"]]
        col = {"ok": S.ok, "att": S.att, "ko": S.ko, "mut": S.mut}[cle]
        g = res.get("gouvernant")
        if res["statut"] == ET.REFUS or not g:
            txt = (res["messages"] or ["Calcul impossible."])[0]
        else:
            crit = ME.critere_texte(g["critere"]) if g["cle"] not in ("soudure", "ancrage", "platine") else g["critere"]
            cas_g = (next((e for e in res["elements"] if e["cle"] == g["cle"]), {}).get("detail") or {}).get("cas_charge")
            # les éléments RÉELLEMENT vérifiés, dans l'ordre de la note, puis ce qui reste à justifier
            cles = [e["cle"] for e in res["elements"]]
            noms = {"montant": "montant", "console": "consoles", "lisse": "main courante", "barreau": "barreaux", "lisse_inter": "lisses intermédiaires"}
            elts = [noms[k] for k in ("montant", "console", "lisse", "barreau", "lisse_inter") if k in cles]
            if any(k in cles for k in ("soudure", "ancrage", "platine")):
                elts.append("ancrage")
            restes = []
            if res["geometrie"].get("sans_montant"):
                restes.append("ancrages aux murs à justifier")
            elif C.cas["fixation"].get("type") == "scellee" and C.systeme() == "montants":
                restes.append("scellement à justifier séparément")
            if (res.get("remplissage") or {}).get("type") == "panneau":
                restes.append("panneau à justifier par le fournisseur")
            elts_txt = ", ".join(elts[:-1]) + " et " + elts[-1] if len(elts) > 1 else (elts[0] if elts else "éléments")
            porte = (f"Le garde-corps porte les charges retenues : {elts_txt} vérifié{'s' if len(elts) > 1 else ''}" + (f" ({' ; '.join(restes)})." if restes else ".")
                     if res["statut"] != ET.NOK else
                     "Le garde-corps ne porte pas les charges retenues en l'état : section, entraxe, hauteur ou ancrage à revoir (les tableaux de l'écran donnent le plus léger qui tient).")
            txt = (f"Taux maximal {_pct(res['taux_max'])} sur {RI.auto(g['libelle'])} ({RI.auto(crit)}" + (f", {_cas(CH.CAS_LIBELLES.get(cas_g, cas_g))}" if cas_g else "")
                   + f"), {MODES_PHRASE[C.meth['mode']]}. " + porte)
            if res.get("masse"):
                txt += f" Masse indicative de l'acier : {_fmt(res['masse'], 0)} kg."
        lignes = RI.envelopper(txt, S.f_b, 6.6, self.ms(S.ink), w - 16)
        h = 13 + 9 + len(lignes) * 6.6 * 1.3 + 8
        y0 = BAS
        d.box(x, y0, w, h, fill=mix(S.panel, "#FFFFFF", 0.3), stroke=col, lw=0.8, r=3)
        d.t(x + 8, y0 + h - 11, "CONCLUSION", S.f_v, 6.2, col, track=1.3)
        yy = y0 + h - 11 - 9
        for l in lignes:
            RI.dessiner(d, x + 8, yy, l, S.f_b, 6.6, S.ink, self.ms(S.ink))
            yy -= 6.6 * 1.3
        return h

    def construire(self, d):
        S = self.S
        W = d.W
        top = self.bandeau(d)
        w1, w2 = LARG
        w3 = W - 2 * M - w1 - w2 - 2 * GAP
        x1, x2, x3 = M, M + w1 + GAP, M + w1 + GAP + w2 + GAP
        for x in (x2, x3):
            d.line(x - GAP / 2, top, x - GAP / 2, BAS, S.rule, 0.45)
        f1, f2, f3 = Frame(x1, top, w1, BAS), Frame(x2, top, w2, BAS), Frame(x3, top, w3, BAS)
        _colonne(self, d, f1, (1, 0))
        _colonne(self, d, f2, (1, 1))
        hc = self.conclusion(d, x3, w3)
        f3.bottom = BAS + hc + 6
        _colonne(self, d, f3, (1, 2))
        d.t(M, 20, d.fit(LEGENDE, S.f_b, 5.4, W - 2 * M), S.f_b, 5.4, S.mut)
        for rang, f in enumerate((f1, f2, f3)):
            if f.overflow() > 1.0:
                self.warnings.append(Debord(1, rang, f.x, f.overflow()))
        return self.warnings


CART_H = 40


class Methode:
    """Page 2 · DÉTAILS ET MÉTHODE."""

    def __init__(self, calc: Calcul, doc_meta: Dict, k: float = 1.0, echelle: Optional[float] = None, suite: Optional["Suite"] = None):
        self.C, self.doc, self.k = calc, doc_meta, k
        self.suite = suite
        self.S = Encre()
        self.warnings: List[str] = []
        self.s = 6.3 * k
        self.echelle = echelle
        self.note1 = Note(calc, doc_meta, k)

    def titre(self, d, fr, txt):
        fr.down(1)
        self.note1.titre(d, fr, txt)
        fr.down(2)

    def paragraphe(self, d, fr, txt, col=None):
        self.note1.rp(d, fr, RI.auto(txt), size=self.s, col=col)
        fr.down(self.s * 0.5)

    def section(self, d, fr, sec):
        self.titre(d, fr, sec["titre"].upper())
        for p in sec["paragraphes"]:
            self.paragraphe(d, fr, p)

    def details_fixation(self, d, fr):
        C = self.C
        vues = [(k, C.vues[k]) for k in ("platine", "pied") if k in C.vues]
        if not vues:
            return
        lat = (C.res.get("fixation") or {}).get("type") == FX.LATERALE and C.systeme() == "montants"
        self.titre(d, fr, "DÉTAIL DE L'ANCRAGE — " + ("platine latérale : vue de face, coupe horizontale" if lat else
                                                   ", ".join(C.titres[k].lower().replace("coupe sur la fixation", "coupe") for k, _ in vues)))
        parts = {"platine": 0.46, "pied": 0.54} if len(vues) == 2 else {vues[0][0]: 1.0}
        larg = {k: (fr.w - 4 * (len(vues) - 1)) * parts[k] for k, _ in vues}
        h = min(max(110.0, max(larg[k] * dv.viewbox[3] / dv.viewbox[2] for k, dv in vues)), 190.0)
        fr.down(h + 3)
        x = fr.x
        for k, dv in vues:
            peindre_scene(d, dv, x, fr.y, larg[k], h - 2)
            x += larg[k] + 4

    def table_montants(self, d, fr):
        C = self.C
        res = C.res
        liste = res.get("montants") or res.get("consoles") or []
        if not liste:
            return
        gouv = (res.get("montant") or res.get("console") or {}).get("nom")
        rows = []
        for v in liste[:16]:
            g = v["nom"] == gouv
            rows.append([("lab", v["nom"] + (" · angle" if v["coin"] else ""), g), ("num", _fmt(v["x"] / 1000, 2)), ("num", _fmt(v["trib1"] + v["trib2"], 0)),
                         ("num", _fmt(v["P1"] / 1e3, 2) + (" + " + _fmt(v["P2"] / 1e3, 2) if v["P2"] > 0 else "")), ("num", _fmt(v["N"] / 1e3, 2)),
                         ("ref", _cas(CH.CAS_LIBELLES.get(v.get("cas_charge"), "")).replace("cas ", "")), ("eta", _pct(v["taux_max"]), v["taux_max"] <= 1.0, g)])
        note = f"+ {len(liste) - 16} non montrés" if len(liste) > 16 else None
        w = fr.w
        nom = "CONSOLE" if C.systeme() == "mur" else "MONTANT"
        cols = [(nom, w - 30 - 34 - 44 - 30 - 46 - 28, "left"), ("$x$ (m)", 30, "right"), ("$s_{trib}$ (mm)", 34, "right"), ("$P$ (kN)", 44, "right"), ("$N$ (kN)", 30, "right"),
                ("CAS", 46, "left"), ("η", 28, "right")]
        self.note1.s_tab, self.note1.lead = 5.8 * self.k, 7.8 * self.k
        self.note1.table(d, fr, f"{nom}S UN À UN — abscisse, longueur tributaire, charges, cas, taux", cols, rows, note)

    def soudure(self, d, fr):
        C = self.C
        s = (C.res.get("fixation") or {}).get("soudure")
        if not s:
            return
        g = s["res"].get("gouvernant") or {}
        meth_s = FOS.methode_du_point(s["res"], g) if g else ""
        lib_s = "vérification à l'ELS" if meth_s.startswith("els") else (FOS.TITRES[meth_s].split(" (")[0] if meth_s in FOS.TITRES else "module Soudures")
        self.titre(d, fr, "SOUDURE SUR LA PLATINE — " + lib_s)
        if C.vues_soudure and s["res"].get("config") != "C8":          # les cordons libres (platine latérale, section libre) : la vue est en colonne 1
            _, _, dv = C.vues_soudure[0]
            h = min(max(80.0, fr.w * 0.8 * dv.viewbox[3] / dv.viewbox[2]), 130.0)
            fr.down(h + 2)
            peindre_scene(d, dv, fr.x + 0.1 * fr.w, fr.y, fr.w * 0.8, h)
        fo = C.fo["soudure"]
        self.note1.s_txt = self.s * 0.97
        self.note1.formules(d, fr, [("Groupe de cordons", fo["groupe"]), ("Point gouvernant", fo["point"]), ("Critère", fo["critere"])])
        fr.down(3)

    def section_et_bibliotheque(self, d, fr):
        C = self.C
        dv = C.vues.get("section")
        role = C.role_principal()
        self.titre(d, fr, "SECTION DE L'ÉLÉMENT PRINCIPAL ET BIBLIOTHÈQUE")
        if dv is not None:
            h = min(max(55.0, fr.w * 0.4 * dv.viewbox[3] / dv.viewbox[2]), 80.0)
            fr.down(h + 2)
            peindre_scene(d, dv, fr.x + fr.w * 0.3, fr.y, fr.w * 0.4, h)
        sec_cur = C.res.get("section_montant") or {}
        groupe = BI.groupe_de(sec_cur) if sec_cur else "creux"
        cands = ET.candidats(C.cas, role, [groupe], 15.0)
        if not cands:
            return
        best = ET.plus_leger(cands)
        cur = sec_cur.get("nom")
        montres = [c for c in cands if c["taux"] <= 1.6][:9]
        if best and best not in montres:
            montres.append(best)
        rows = [[("lab", c["section"]["nom"], c["section"]["nom"] == cur), ("num", _fmt(c["section"]["masse"], 2)), ("eta", _pct(c["taux"]), c["taux"] <= 1.0, c["section"]["nom"] == cur, c["taux"])]
                for c in montres]
        w = fr.w
        cols = [("SECTION", w - 36 - 64, "left"), ("kg/m", 36, "right"), ("η", 64, "right")]
        self.note1.s_tab, self.note1.lead = 5.8 * self.k, 7.8 * self.k
        self.note1.table(d, fr, None, cols, rows,
                         f"{BI.GROUPES.get(groupe, groupe)} essayés comme {ET.ROLES[role]}, par masse croissante · le plus léger qui tient : {best['section']['nom']} (η {_pct(best['taux'])}) ; "
                         "la section retenue est en gras." if best else "Aucune section ≤ 15 kg/m ne tient.")

    def cartouche(self, d):
        S, C, doc = self.S, self.C, self.doc
        W = d.W
        x0, y0, w, h = M, M, W - 2 * M, CART_H
        d.box(x0, y0, w, h, stroke=S.ink, lw=0.9)
        cas = C.cas
        ech = "—"
        if self.echelle:
            ech = "1:" + f"{2.8346 / self.echelle:.0f}"
        ident = " · ".join(str(x) for x in (doc.get("projet"), doc.get("partie")) if x)
        m = C.meth
        lim = C.res["limites"]
        meth = MODES[m["mode"]] + (f" · $σ_{{adm}}$ = $f_y$/{_g(lim['coef'])} = {_fmt(lim['sigma'])} · $τ_{{adm}}$ {_fmt(lim['tau'])}" if m["mode"] == ME.ELS
                                   else f" · $γ_Q$ {_g(m.get('gamma_Q', 1.5))} · $γ_{{M0}}$ {_g(m.get('gamma_M0', 1))}")
        cases = [("CAS", cas["nom"], ident or "—", 0.18),
                 ("GARDE-CORPS", C.type_libelle(), C.res["geometrie"]["phrase"], 0.28),
                 ("MÉTHODE", meth, "flèche ≤ " + C.fleche_adm(), 0.20),
                 ("ACIER", C.acier["nuance"], f"$f_y$ {_g(C.acier['fy'])} N/mm² · $f_u$ {_g(C.acier['fu'])}" if C.acier.get("fy") is not None else "—", 0.12),
                 ("DATE · INDICE", str(doc.get("date", "")), "indice " + str(doc.get("indice", "")), 0.11),
                 ("ÉCHELLE DE L'ÉLÉVATION", ech, "A4 paysage", 0.11)]
        x = x0
        for i, (lab, l1, l2, part) in enumerate(cases):
            cw = w * part
            if i:
                d.line(x, y0 + 2, x, y0 + h - 2, S.rule, 0.6)
            d.t(x + 6, y0 + h - 10, lab, S.f_v, 5.4, S.mut, track=1.2)
            self.note1.rt(d, x + 6, y0 + h - 21, str(l1), 6.6, S.ink, font="Carlito-Bold", width=cw - 12)
            if l2:
                self.note1.rt(d, x + 6, y0 + h - 32, str(l2), 6.2, S.ink, width=cw - 12)
            x += cw

    def construire(self, d):
        S = self.S
        W, H = d.W, d.H
        y = H - M - 4
        d.t(M, y, self.doc.get("bureau", ""), S.f_v, 8.0, S.acc, track=1.4)
        d.t(W - M, y, TITRE + " · cas " + self.C.cas["nom"], S.f_b, 7.6, S.mut, "right")
        y -= 16
        d.t(M, y, "DÉTAILS ET MÉTHODE", S.f_h, 13.5, S.ink)
        # les références sont une section de la colonne Méthode (en tête, la ligne se tronquait)
        y -= 7
        d.line(M, y, W - M, y, S.ink, 1.0)
        top = y - 6
        bas = M + CART_H + 10
        wc = (W - 2 * M - 2 * GAP) / 3.0
        frames = [Frame(M + i * (wc + GAP), top, wc, bas) for i in range(3)]
        for i in (1, 2):
            d.line(frames[i].x - GAP / 2, top, frames[i].x - GAP / 2, bas, S.rule, 0.45)
        for rang, f in enumerate(frames):
            _colonne(self, d, f, (2, rang))
        self.cartouche(d)
        for rang, f in enumerate(frames):
            if f.overflow() > 1.0:
                self.warnings.append(Debord(2, rang, f.x, f.overflow()))
        return self.warnings

    def methode(self, d, fr):
        """Les textes de MÉTHODE de la méthode choisie (``methode.py``), puis les références."""
        secs = MT.sections(self.C.meth["mode"], self.C.cas["fixation"].get("type", "platine"), bool(self.C.res["geometrie"].get("sans_montant")),
                           self.C.res["acier"]["nuance"])     # la nuance retenue (etat.verifier) : la référence de ses f_y
        for sec in secs + [{"titre": "Références", "paragraphes": [" · ".join(MT.REFERENCES)]}]:
            self.section(d, fr, sec)


class Suite:
    """Page 3 · SUITE : les blocs du bas d'une colonne des pages 1 et 2 qui ne tiennent pas, même en taille réduite.

    ``reports`` : les blocs qui partent, ``((page, rang), nom)`` (``mise_en_page`` les choisit). La page de suite a
    trois colonnes, comme la page 2 ; chaque colonne d'origine qui reporte en reçoit une (une quatrième s'empilerait
    dans la troisième), sous son titre « SUITE DE LA PAGE 1 · CALCUL ». Un bloc reporté est d'abord dessiné AU MOMENT
    où sa page l'aurait dessiné, sur un brouillon et dans sa colonne de suite : la numérotation des blocs suivants
    (« 3 · BARREAUX ») et sa hauteur sont celles qu'ils auraient eues. Puis il est redessiné en page 3, au même endroit,
    avec l'état de sa page tel qu'il était à ce moment-là (numéro, tailles) : le même dessin.

    (Pas d'objet de formulaire PDF pour le poser : reportlab n'y reporte pas les états graphiques — transparence —
    de la page, la visionneuse les ignore.)"""

    def __init__(self, calc: Calcul, doc_meta: Dict, k: float, reports, W: float, H: float):
        self.C, self.doc, self.k = calc, doc_meta, k
        self.reports = set(reports)
        self.S = Encre()
        self.W, self.H = W, H
        self.top = H - M - 4 - 16 - 7 - 6           # l'en-tête de la page 2 (Methode.construire)
        self.bas = M + CART_H + 10
        self.wc = (W - 2 * M - 2 * GAP) / 3.0
        self.cadres: Dict = {}                      # (page, rang) d'origine → la colonne de la page 3
        self.ordre: List = []                       # les colonnes de la page 3, dans l'ordre (cadre, [colonnes d'origine])
        self.titres: List = []                      # (x, y, texte) des titres de colonne, posés en page 3
        self.blocs: List = []                       # (page, nom, état de la page, colonne, y de départ) à redessiner
        self.pages: set = set()                     # les pages d'origine des blocs posés (1, 2)
        self.brouillon = Doc(io.BytesIO(), (W, H))  # le dessin « au moment voulu », jeté
        self.warnings: List[str] = []

    def prend(self, cle, nom) -> bool:
        return (cle, nom) in self.reports

    def cadre(self, cle) -> Frame:
        if cle not in self.cadres:
            if len(self.ordre) < 3:
                i = len(self.ordre)
                fr = Frame(M + i * (self.wc + GAP), self.top, self.wc, self.bas)
                self.ordre.append(fr)
            else:
                fr = self.ordre[-1]
            self.cadres[cle] = fr
        return self.cadres[cle]

    def reporter(self, d, page, cle, noms, fr_origine):
        """Les blocs ``noms`` de la colonne ``cle`` dessinés sur le brouillon, dans la colonne de suite (pour les
        redessiner en page 3), et la mention « Suite p. 3 : … » au bas de la colonne d'origine. Un bloc vide (rien à
        dessiner) n'est ni posé ni nommé."""
        S = self.S
        fr = self.cadre(cle)
        poses = []
        for nom in noms:
            y0, min0 = fr.y, fr.min_y
            titre = not poses
            if titre:
                fr.down(12)                          # la place du titre de la colonne de suite
            yb = fr.y
            etat = _etat_page(page)
            getattr(page, nom)(self.brouillon, fr)
            if fr.y == yb:                           # rien dessiné : le bloc est vide
                fr.y, fr.min_y = y0, min0
                continue
            if titre:
                self.titres.append((fr.x, y0 - 8, f"SUITE DE LA PAGE {cle[0]} · {TITRES_PAGES[cle[0]].upper()}"))
                self.pages.add(cle[0])
            self.blocs.append((page, nom, etat, fr, yb))
            poses.append(nom)
        if poses:
            fr_origine.down(6.1 * self.k * 1.9)
            txt = "Suite p. 3 : " + ", ".join(NOMS_BLOCS[n] for n in poses) + "."
            d.t(fr_origine.x, fr_origine.y, d.fit(txt, S.f_b, 6.2 * self.k, fr_origine.w), S.f_b, 6.2 * self.k, S.acc)

    def utile(self) -> bool:
        """Vrai quand la page de suite a quelque chose à poser."""
        return bool(self.blocs)

    def construire(self, d, echelle: Optional[float]):
        S, C = self.S, self.C
        W, H = d.W, d.H
        y = H - M - 4
        d.t(M, y, self.doc.get("bureau", ""), S.f_v, 8.0, S.acc, track=1.4)
        d.t(W - M, y, TITRE + " · cas " + C.cas["nom"], S.f_b, 7.6, S.mut, "right")
        y -= 16
        titre = f"SUITE DE LA PAGE {min(self.pages)}" if len(self.pages) == 1 else "SUITE DES PAGES 1 ET 2"
        d.t(M, y, titre, S.f_h, 13.5, S.ink)
        y -= 7
        d.line(M, y, W - M, y, S.ink, 1.0)
        for fr in self.ordre[1:]:
            d.line(fr.x - GAP / 2, self.top, fr.x - GAP / 2, self.bas, S.rule, 0.45)
        for x, yt, txt in self.titres:
            d.t(x, yt, txt, S.f_v, 5.6, S.mut, track=1.1)
        for page, nom, etat, fr, yb in self.blocs:
            # le même dessin que sur le brouillon : la page remise dans son état d'alors, la colonne au même endroit
            maintenant = _etat_page(page)
            _remettre(etat)
            f = Frame(fr.x, fr.top, fr.w, fr.bottom)
            f.y = f.min_y = yb
            getattr(page, nom)(d, f)
            _remettre(maintenant)
        Methode(C, self.doc, self.k, echelle).cartouche(d)
        for rang, fr in enumerate(self.ordre):
            if fr.overflow() > 1.0:
                self.warnings.append(Debord(3, rang, fr.x, fr.overflow()))
        return self.warnings


def poser(d, calc, doc_meta, k, reports=()) -> List[str]:
    """Les pages d'UN cas posées dans le document ``d`` (sans l'ouvrir ni l'enregistrer) : page 1, page 2, et la page
    de suite quand des blocs y partent (``reports``). Rend les débordements. Le site pose ainsi chaque garde-corps de
    sa note dans un seul document (api_web/note_cas.py)."""
    suite = Suite(calc, doc_meta, k, reports, *A4L) if reports else None
    d.new_page(A4L)
    n1 = Note(calc, doc_meta, k, suite)
    w = list(n1.construire(d))
    d.new_page(A4L)
    n2 = Methode(calc, doc_meta, k, n1.echelle, suite)
    w += n2.construire(d)
    if suite is not None and suite.utile():
        d.new_page(A4L)
        w += suite.construire(d, n1.echelle)
    return w


def _essai(calc, doc_meta, k, chemin, reports=()):
    d = Doc(chemin, A4L, title=doc_meta.get("titre", "Note de calcul"))
    w = poser(d, calc, doc_meta, k, reports)
    d.save()
    return w


def mise_en_page(calc, doc_meta, chemin) -> Tuple[float, str, Tuple, List[str]]:
    """(k, nom de la taille, reports, débordements) : la taille normale, puis la réduite ; si une colonne déborde encore
    en taille réduite, le DERNIER bloc de chaque colonne qui déborde passe en page de suite, et ainsi de suite jusqu'à
    ce que tout tienne (ou qu'il n'y ait plus rien à reporter : les débordements restent, et le disent). Le fichier
    ``chemin`` garde la note retenue (le dernier essai)."""
    k, nom = VARIANTES[-1]
    warn: List[str] = []
    for k, nom in VARIANTES:
        warn = _essai(calc, doc_meta, k, chemin)
        if not warn:
            return k, nom, (), warn
    reports: List = []
    while warn:
        nouveaux = []
        for w in warn:
            cle = getattr(w, "colonne", None)
            if cle not in BLOCS:                    # la page de suite elle-même, ou un débordement sans colonne
                continue
            restent = [b for b in BLOCS[cle] if (cle, b) not in reports]
            if restent and (cle, restent[-1]) not in nouveaux:
                nouveaux.append((cle, restent[-1]))
        if not nouveaux:
            break
        reports += nouveaux
        warn = _essai(calc, doc_meta, k, chemin, tuple(reports))
    return k, nom, tuple(reports), warn


def generer_note(etat: Dict, cas: Optional[Dict] = None, infos: Optional[Dict] = None, chemin: Optional[str] = None) -> bytes:
    """La note (bytes PDF) : page 1 de calcul, page 2 de détails et méthode, page 3 de suite si une colonne ne tient pas
    (``mise_en_page``). ``infos`` : nom_projet, partie, date, indice."""
    global derniers_avertissements, derniere_variante, derniers_reports
    cas = cas or ET.cas_actif(etat)
    infos = infos or {}
    doc_meta = ndc_data.construire_doc(infos, date_defaut=datetime.today().strftime("%d/%m/%Y"))
    doc_meta["titre"] = "Note de calcul — garde-corps"
    calc = Calcul(etat, cas)
    if chemin is None:
        fd, chemin = tempfile.mkstemp(suffix=".pdf", prefix="note_garde_corps_")
        os.close(fd)
    _k, retenue, reports, warn = mise_en_page(calc, doc_meta, chemin)
    derniers_avertissements = list(warn)
    derniere_variante = retenue
    derniers_reports = reports
    with open(chemin, "rb") as fh:
        return fh.read()


derniers_avertissements: List[str] = []
derniere_variante: Optional[str] = None
derniers_reports: Tuple = ()           # les blocs passés en page de suite par la dernière note : ((page, rang), nom)
