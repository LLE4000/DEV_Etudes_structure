# -*- coding: utf-8 -*-
"""Note de calcul du plat d'âme — DEUX pages A4 paysage, la même charte que
le module doubles cornières (palette Encre, bandeau statut, en-tête compact
en trois lignes, trois colonnes, pied en deux lignes) :

- page 1 : bandeau (statut, η max, dimensionnante, taux par élément,
  alertes), en-tête (objets · attaches · efforts), dessins + hypothèses,
  tableaux par élément (Ed / Rd / η / réf.), Tableau 3.3, formules des
  vérifications essentielles, conclusion ;
- page 2 : « PLAN DE PRINCIPE » — trois vues à la même échelle normalisée,
  héritée du module doubles cornières (PlanPrincipe), avec les vues et le
  cartouche de CET assemblage.
"""
import os
import tempfile
from datetime import datetime

from reportlab.lib.pagesizes import A4, landscape

from ndc_pdf.kit import Doc, Frame, chip, mix
from ndc_pdf.styles import Encre
from ndc_pdf import data as ndc_data
from acier.formats import F, pct, nb
from acier.js import N, js_str
from acier.bibliotheques import PERSO
from . import schemas, synthese, formules
from .entrees import VISSERIE_DEFAUT
from acier.assemblages.note_kit import empaqueter, coefficients, MSB, SANS_TAUX, sans_taux, verdict, masquer_taux
from .notation import ligne_alerte, ref_courte, LEGENDE_REFERENCES, NOTATIONS as NOTATIONS_COURTES
from ..doubles_cornieres.rapport import peindre
from ..doubles_cornieres.note import PlanPrincipe, TEXTE_MM

A4L = landscape(A4)
M = 22
BAS = 40
GAP = 12
LARG = (210, 262, None)
S_TAB, S_TAB_H, S_REF, S_FORM, S_DATA = 6.5, 5.6, 5.6, 6.0, 7.0
LEAD_TAB = 8.8

TITRE = "Assemblage poutre–poutre — plat d'âme soudé (fin plate)"
VARIANTES = ("toutes", "eta")


def _prof(R, X):
    u = R.u
    if u["prof_" + X] == PERSO:
        return "h " + F(R["h_" + X], 0) + " b " + F(R["b_" + X], 0) + " tw " + F(R["tw_" + X], 1) + " tf " + F(R["tf_" + X], 1)
    return u["prof_" + X]


def lignes_entete(R):
    """L'en-tête compact : objets, attaches, efforts — pas de géométrie
    détaillée (elle est cotée sur le plan de principe)."""
    u = R.u
    grugee = bool(N(u.d_nt) or N(u.d_nb))
    l1 = ("Principale " + _prof(R, "P") + " " + u.nu_P
          + "    |    Secondaire " + _prof(R, "S") + " " + u.nu_S + (" · grugée" if grugee else "")
          + "    |    Plat " + nb(R.h_p) + "×" + nb(R.b_p) + "×" + nb(R.t_p) + " " + u.nu_pl)
    l2 = ("Boulons " + R.boulon + " " + u.classe + " cat. " + u.cat + " · trous Ø" + F(R.d_0, 0)
          + (" surdim." if u.trou != "Normal" else "")
          + "    |    Groupe " + js_str(R.n_1) + " × " + js_str(R.n_2) + " (1 plan)"
          + "    |    Soudure double a " + F(R.a_w, 0))
    l3 = ("VEd " + F(u.V_Ed, 1) + " kN    |    NEd " + F(u.N_Ed, 1) + " kN    |    MEd "
          + F(u.M_Ed, 2) + " kNm")
    return l1, l2, l3


def segments_hypotheses(R):
    """Les SEGMENTS du bloc HYPOTHÈSES (charte du 31/10/2026, §11) : modèle et
    excentricité, plat court / long, grugeage, cordons, coefficients — chaque
    segment écrit en entier, avec sa forme courte quand il en a une ; le kit
    (``note_kit.empaqueter``) les range en ≤ 3 lignes de ≤ 110 caractères.
    Gardés parce qu'ils ne vivent nulle part ailleurs sur la page : z et le
    moment repris ; retirés : MS, Ip (formule du cisaillement du groupe)."""
    u = R.u
    seg = ["articulé : rotule à la face de l'âme porteuse (MSB P5 §3.2)",
           "z = " + F(R.zeff, 1) + " mm",
           "le groupe reprend VEd·z + |MEd|",
           ("plat court (z ≤ tp/0,15 : pas de déversement)" if not R.long_p
            else "plat long (z > tp/0,15 : déversement, courbe BS 5950-1)")]
    if R.cas_g > 0:
        seg.append(("grugeage : flexion de la section réduite (MSB P5 §4.2.4)", "grugeage : section réduite (MSB P5 §4.2.4)"))
    seg.append(("cordons pleine hauteur, un par face (§4.5.3.3)", "cordons pleine hauteur (§4.5.3.3)"))
    suffixe = " · γM3 " + F(N(u.g_M3), 2) if u.cat != "A" else ""
    g = "γM0 " + F(N(u.g_M0), 2) + " · γM1 " + F(N(u.g_M1), 2) + " (ANB) · γM2 " + F(N(u.g_M2), 2)
    seg.append(tuple(f + suffixe for f in coefficients(g, N(u.g_M2), N(u.g_M2n))))
    return seg


def lignes_hypotheses(R):
    """≤ 3 lignes de ≤ 110 caractères, « MSB P5 » une fois par ligne si possible (ValueError sinon : le test rougit)."""
    return empaqueter(segments_hypotheses(R), n_max=3, larg=110, une_fois=MSB)


def _deux_lignes(d, txt, police, taille, largeur):
    """Un avis du bandeau en une ligne, ou en deux s'il ne tient pas (coupé à un « ; », sinon à une espace) : la
    seconde est rendue entière par l'appelant tant qu'elle tient (``fit`` au-delà) — un avis n'est plus tronqué par
    « … » dès qu'il s'allonge (la phrase de l'étude du SCI, lot B)."""
    if d.w(txt, police, taille) <= largeur:
        return txt, ""
    for sep, garde in ((" ; ", " ;"), (" ", "")):
        i = len(txt)
        while True:
            i = txt.rfind(sep, 0, i)
            if i <= 0:
                break
            if d.w(txt[:i] + garde, police, taille) <= largeur:
                return txt[:i] + garde, txt[i + len(sep):]
    return d.fit(txt, police, taille, largeur), ""


def _est_info(R, syn, c):
    """Une vérification que la synthèse du module déclare « information »
    (hors verdict) ne concourt pas aux formules imprimées."""
    f = getattr(syn, "info", None)
    return bool(f and f(R, c.key))


def _priorite(R, syn=synthese):
    act = [c for c in R.checks if c.active and not _est_info(R, syn, c)]
    ordre = []
    if R.gov:
        ordre.append(R.gov)
    ordre += [c for c in act if not c.ok]
    ordre += [pire for _, _, _, pire in syn.taux_par_element(R)]
    ordre += [c for c in act if c.ess]
    vus = []
    for c in ordre:
        if c not in vus:
            vus.append(c)
    return vus


def _obligatoires(R, syn=synthese):
    n = ((1 if R.gov else 0) + sum(1 for c in R.checks if c.active and not c.ok and not _est_info(R, syn, c))
         + len(syn.taux_par_element(R)))
    return _priorite(R, syn)[:n]


# ------------------------------------------------------------- page 1
class Note:
    """Compose la page 1 ; ``warnings`` = débordements (vide si tout tient).

    La mise en page est commune à la famille : un autre assemblage la
    réutilise en sous-classant et en remplaçant les attributs de classe
    ci-dessous (titre, synthèse, schémas, en-tête, hypothèses, tableaux des
    colonnes 2 et 3, mention normative de la conclusion)."""
    TITRE_NOTE = TITRE
    SYN = synthese
    SCH = schemas
    COL2 = ("boulons", "plat", "soudure")
    COL3 = ("portee", "porteuse")
    NORME = "(γM1 : ANB belge)"
    LEGENDE = LEGENDE_REFERENCES
    NOTATIONS = NOTATIONS_COURTES
    # la référence courte d'une vérification (bandeau, formules) : un autre
    # assemblage, avec d'autres normes, passe la SIENNE. C'est une FONCTION
    # portée par la classe : elle s'enveloppe dans ``staticmethod``, sinon
    # Python en fait une méthode et lui passe ``self`` en premier argument
    # (défaut signalé par le gabarit de la famille poutre–poteau, qui, lui,
    # l'enveloppait déjà). ``None`` et le repli ``or`` ont disparu : chaque
    # sous-classe NOMME la sienne.
    REF = staticmethod(ref_courte)

    def ref(self, r):
        return self.REF(r)

    def entete(self, R):
        return lignes_entete(R)

    def hypotheses(self, R):
        return lignes_hypotheses(R)

    def alerte(self, a, R):
        return ligne_alerte(a, R)

    def lignes_a_verifier(self, R):
        """Les lignes « À VÉRIFIER » d'une hypothèse prudente qui change le résultat (aucune par défaut)."""
        return []

    def alertes_bandeau(self, R):
        """Les alertes du bandeau (toutes par défaut ; une note peut en ranger une dans ses lignes « À VÉRIFIER »)."""
        return list(R.alerts)

    def __init__(self, R, doc_meta, variante):
        self.R = R; self.doc = doc_meta; self.mode_lignes = variante
        self.S = Encre(); self.warnings = []; self.formules_imprimees = []
        # la note SANS les taux (``note_kit.sans_taux`` : option de l'écran du site) — Ed, Rd et les verdicts restent
        self.sans_taux = sans_taux(doc_meta)

    def titre(self, d, fr, txt):
        S = self.S
        fr.down(10)
        d.t(fr.x, fr.y, txt, S.f_v, 6.2, S.acc, track=1.3)
        fr.down(3)
        d.line(fr.x, fr.y, fr.x1, fr.y, mix(S.rule, S.ink, 0.12), 0.5)

    def table(self, d, fr, titre, cols, lignes):
        S = self.S
        self.titre(d, fr, titre)
        fr.down(8)
        xs = []
        x = fr.x
        for ent, w, al in cols:
            xs.append(x)
            # (note SANS les taux : la colonne η dit « OK » / « NON OK », sans titre — comme celle des pinces)
            if not (self.sans_taux and ent in ("η", "max")):
                d.t(x + (w - 3 if al == "right" else 0), fr.y, ent.upper() if ent != "η" else ent, S.f_b, S_TAB_H, S.mut, al)
            x += w
        fr.down(2.5)
        d.line(fr.x, fr.y, fr.x1, fr.y, S.acc, 0.5)
        for cells in lignes:
            rendus = []
            n_max = 1
            for (ent, w, al), cell in zip(cols, cells):
                style, txt = cell[0], cell[1]
                if self.sans_taux and style == "lab":
                    txt = masquer_taux(txt)        # (un taux écrit dans un libellé : les tableaux « calcul à la main »)
                if style in ("lab", "ref"):
                    size = S_REF if style == "ref" else S_TAB
                    ls = d.wrap(txt, S.f_b, size, w - 4)
                    n_max = max(n_max, len(ls))
                    rendus.append((style, ls, cell))
                else:
                    rendus.append((style, [txt], cell))
            h = LEAD_TAB * n_max + 1.2
            fr.down(LEAD_TAB - 1.8)
            y = fr.y
            for (ent, w, al), (style, ls, cell), xx in zip(cols, rendus, xs):
                if style == "lab":
                    f = S.f_b if not (len(cell) > 2 and cell[2] == "gov") else "Carlito-Bold"
                    for i, l in enumerate(ls):
                        d.t(xx, y - i * LEAD_TAB, l, f, S_TAB, S.ink)
                elif style == "ref":
                    for i, l in enumerate(ls):
                        d.t(xx, y - i * LEAD_TAB, l, S.f_b, S_REF, S.mut)
                elif style == "num":
                    d.t(xx + w - 3, y, ls[0], S.f_b, S_TAB, S.ink, "right")
                elif style == "eta":
                    ok, gov = cell[2], (len(cell) > 3 and cell[3])
                    d.t(xx + w - 3, y, verdict(ok) if self.sans_taux else ls[0], "Carlito-Bold" if (gov or not ok) else S.f_b,
                        S_TAB, S.ok if ok else S.ko, "right")
                elif style == "st":
                    ok = cell[2]
                    d.t(xx + w - 3, y, ls[0], "Carlito-Bold", S_TAB, S.ok if ok else S.ko, "right")
            fr.down(h - (LEAD_TAB - 1.8))
            d.line(fr.x, fr.y + 1.5, fr.x1, fr.y + 1.5, mix(S.rule, S.ink, 0.06), 0.4)
        fr.down(2)

    def bandeau(self, d):
        S, R, doc = self.S, self.R, self.doc
        W, H = d.W, d.H
        y = H - M - 4
        d.t(M, y, doc.get("bureau", ""), S.f_v, 8.0, S.acc, track=1.4)
        d.t(W - M, y, "Note de calcul · " + doc.get("date", "") + " · indice " + str(doc.get("indice", "")), S.f_b, 8, S.mut, "right")
        y -= 15
        d.t(M, y, self.TITRE_NOTE, S.f_h, 12.5, S.ink)
        u = R.u
        ident = " · ".join(str(x) for x in (doc.get("projet") or u.id_projet, doc.get("partie") or u.id_rep, u.id_red) if x)
        if ident:
            d.t(W - M, y, ident, S.f_b, 8, S.ink, "right")
        y -= 8
        d.line(M, y, W - M, y, S.ink, 1.0)
        y -= 15
        etat_ok = R.verified
        # « À VÉRIFIER » (ocre) : un contrôle hors périmètre au-delà de 100 % nommé par le moteur (``R.a_verifier``, pied
        # de poteau — brief v12 § 19.1 point 4) ; jamais « VÉRIFIÉ » en vert dans ce cas
        a_verif = bool(etat_ok and R.get("a_verifier"))
        col = S.att if a_verif else (S.ok if etat_ok else S.ko)
        w = chip(d, M, y - 3.2, "À VÉRIFIER" if a_verif else ("VÉRIFIÉ" if etat_ok else "NON VÉRIFIÉ"), S.f_v, 6.6,
                 "#FFFFFF", col)
        x = M + w + 8
        if not self.sans_taux:
            t1 = "η max " + pct(R.eta_max, 1)
            d.t(x, y, t1, "Carlito-Bold", 8.6, col)
            x += d.w(t1, "Carlito-Bold", 8.6) + 5
        t2 = (("" if self.sans_taux else "— ") + "dimensionnant : " + self.SYN.court(R.gov) + " (" + self.ref(R.gov.ref) + ")") if R.gov else ""
        if not R.geo_ok:
            t2 += " · géométrie non valide"
        if not R.dist_ok:
            t2 += " · Tableau 3.3 non conforme"
        if a_verif:
            t2 += " · à vérifier : " + R.a_verifier
        elif R.verified and (R.reserve or R.alerts):
            t2 += " · sous réserve des points signalés"
        if self.sans_taux:
            t2 = masquer_taux(t2)
        pieces = []
        for nom, eta, ok, _ in ([] if self.sans_taux else self.SYN.taux_par_element(R)):
            pieces.append((nom + " ", S.f_b, S.ink)); pieces.append((pct(eta, 0), "Carlito-Bold", S.ok if ok else S.ko))
            pieces.append(("   ", S.f_b, S.ink))
        wt = sum(d.w(t, f, 8) for t, f, _ in pieces)
        xr = W - M - wt
        d.t(x, y, d.fit(t2, S.f_b, 8, xr - x - 6), S.f_b, 8, S.ink)
        for t, f, col in pieces:
            d.t(xr, y, t, f, 8, col)
            xr += d.w(t, f, 8)
        # une hypothèse prudente qui CHANGE le résultat (règle 7 du lot B : pied de poteau, calcul manuel), une ligne
        # ocre, avant les alertes (jamais rangée dans « + n autre(s) point(s) »)
        for txt in self.lignes_a_verifier(R):
            txt = masquer_taux(txt) if self.sans_taux else txt
            y -= 10
            d.box(M + 1, y - 0.5, 4.2, 4.2, fill=S.att)
            d.t(M + 9, y, d.fit(txt, S.f_b, 6.8, W - 2 * M - 12), S.f_b, 6.8, S.ink)
        al = self.alertes_bandeau(R)
        for a in al[:3]:
            y -= 10
            titre, det = self.alerte(a, R)
            col = S.ko if a.block else S.att
            d.box(M + 1, y - 0.5, 4.2, 4.2, fill=col)
            txt = titre + (" : " + det if det else "")
            txt = masquer_taux(txt) if self.sans_taux else txt
            l1, l2 = _deux_lignes(d, txt, S.f_b, 6.8, W - 2 * M - 12)
            d.t(M + 9, y, l1, S.f_b, 6.8, S.ink)
            if l2:                      # un avis trop long passe à la ligne, il n'est plus coupé (« …mai 20… »)
                y -= 8.5
                d.t(M + 9, y, d.fit(l2, S.f_b, 6.8, W - 2 * M - 12), S.f_b, 6.8, S.ink)
        if len(al) > 3:
            y -= 9
            d.t(M + 9, y, "+ " + str(len(al) - 3) + " autre(s) point(s) signalé(s).", S.f_b, 6.4, S.mut)
        y -= 12
        l1, l2, l3 = self.entete(R)
        d.t(M, y, d.fit(l1, S.f_b, S_DATA, W - 2 * M), S.f_b, S_DATA, S.ink)
        y -= S_DATA * 1.35
        d.t(M, y, d.fit(l2, S.f_b, S_DATA, W - 2 * M), S.f_b, S_DATA, S.ink)
        y -= S_DATA * 1.45
        d.t(M, y, l3, "Carlito-Bold", S_DATA, S.ink)
        y -= 6
        d.line(M, y, W - M, y, mix(S.rule, S.ink, 0.3), 0.6)
        return y - 4

    def colonne_dessins(self, d, fr):
        S, R, sch = self.S, self.R, self.SCH
        hyp = self.hypotheses(R)
        lignes = []
        for h in hyp:
            lignes.extend(d.wrap(h, S.f_b, 6.2, fr.w))
        h_hyp = 13 + len(lignes) * 6.2 * 1.3 + 4
        dispo = fr.room() - h_hyp - 2 * 13 - 6
        he = dispo * 0.58; hp = dispo - he
        opt = sch.options_rapport()
        self.titre(d, fr, "ÉLÉVATION (mm)")
        fr.down(he)
        peindre(d, sch.elevation(R, opt), fr.x, fr.y, fr.w, he - 2)
        self.titre(d, fr, "VUE EN PLAN")
        fr.down(hp)
        peindre(d, sch.plan(R, opt), fr.x, fr.y, fr.w, hp - 2)
        self.titre(d, fr, "HYPOTHÈSES")
        fr.down(3)
        for l in lignes:
            fr.down(6.2 * 1.3)
            d.t(fr.x, fr.y, l, S.f_b, 6.2, S.mut)

    def table_simple(self, d, fr, cle, largeurs):
        R = self.R
        ls = self.SYN.lignes(R, cle)
        if not ls:
            return
        cols = [("Vérification", largeurs[0], "left"), ("Ed", largeurs[1], "right"), ("Rd", largeurs[2], "right"),
                ("η", largeurs[3], "right"), ("Réf.", largeurs[4], "left")]
        lignes = []
        for l in ls:
            gov = l["c"] is R.gov
            lignes.append([("lab", l["lab"], "gov" if gov else ""),
                           ("num", l["Ed"]), ("num", l["Rd"] + (" " + l["unit"] if l["unit"] else "")),
                           ("eta", l["pct"], l["ok"], gov), ("ref", l["ref"])])
        self.table(d, fr, self.SYN.titre_table(cle).upper(), cols, lignes)

    def table_pinces(self, d, fr):
        R = self.R
        if not R.dist:
            return
        w = fr.w
        cols = [("Distance (Tab. 3.3)", w - 128, "left"), ("Valeur", 32, "right"), ("Min", 32, "right"),
                ("Max", 32, "right"), ("", 32, "right")]
        lignes = [[("lab", x.lab), ("num", F(x.val, 1)), ("num", F(x.min, 1)),
                   ("num", "—" if x.max is None else F(x.max, 0)), ("st", "OK" if x.ok else "NON OK", x.ok)] for x in R.dist]
        self.table(d, fr, "PINCES ET ENTRAXES — EN 1993-1-8 TAB. 3.3 (mm)", cols, lignes)

    def conclusion(self, d, x, w):
        S, R = self.S, self.R
        txt = (R.statut + " à l'ELU selon EN 1993-1-8 et EN 1993-1-1 " + self.NORME
               + (" — sous réserve des points signalés." if R.verified and (R.reserve or R.alerts) else "."))
        txt = masquer_taux(txt) if self.sans_taux else txt
        col = S.ok if R.verified else S.ko
        lines = d.wrap(txt, S.f_b, 7.2, w - 15)
        h = len(lines) * 7.2 * 1.28 + 7
        y0 = BAS
        d.box(x, y0, w, h, fill=mix(col, "#FFFFFF", 0.90))
        d.box(x, y0 + 1.5, 2.0, h - 3, fill=col)
        for i, ln in enumerate(lines):
            d.t(x + 9, y0 + h - 7.2 * (1.02 + i * 1.28), ln, S.f_b, 7.2, S.ink)
        return h

    def _bloc_formules(self, d, c, largeur):
        S, R = self.S, self.R
        textes = formules.textes(R, c)
        if self.mode_lignes == "eta" and len(textes) > 1:
            textes = [textes[0], textes[-1]]
        if self.sans_taux:
            textes = [masquer_taux(t) for t in textes]
        bloc = []
        for t in textes:
            bloc.extend(d.wrap(t, S.f_b, S_FORM, largeur - 6))
        return bloc, 9 + len(bloc) * S_FORM * 1.25 + 3

    def _simuler(self, d, frames, retenues, hauteurs):
        R = self.R
        rooms = [max(0.0, f.room()) for f in frames]
        rooms[0] -= 16
        i = 0
        places, manq = [], []
        for c in [c for c in R.checks if c in retenues]:
            h = hauteurs[(c.key, i)]
            while h > rooms[i] and i + 1 < len(frames):
                i += 1
                h = hauteurs[(c.key, i)]
            if h > rooms[i]:
                manq.append(c)
            else:
                rooms[i] -= h
                places.append(c)
        return places, manq

    def formules(self, d, frames):
        S, R = self.S, self.R
        cand = _priorite(R, self.SYN)
        if not frames or not cand:
            return
        oblig = _obligatoires(R, self.SYN)
        hauteurs = {(c.key, i): self._bloc_formules(d, c, f.w)[1] for c in cand for i, f in enumerate(frames)}
        dispo = sum(max(0.0, f.room()) for f in frames) - 16 - 8
        retenues = []
        total = 0.0
        for c in cand:
            h = max(hauteurs[(c.key, i)] for i in range(len(frames)))
            if total + h <= dispo:
                retenues.append(c); total += h
        while True:
            places, manq = self._simuler(d, frames, retenues, hauteurs)
            if not any(c in oblig for c in manq):
                break
            facultatives = [c for c in retenues if c not in oblig]
            if not facultatives:
                break
            retenues.remove(facultatives[-1])
        for c in manq:
            if c in oblig:
                self.warnings.append("formules : " + c.key + " ne tient pas")
        i = 0
        fr = frames[0]
        self.titre(d, fr, "FORMULES ET SUBSTITUTIONS NUMÉRIQUES")
        fr.down(2)
        for c in places:
            bloc, h = self._bloc_formules(d, c, fr.w)
            while not fr.fits(h) and i + 1 < len(frames):
                i += 1
                fr = frames[i]
            if not fr.fits(h):
                continue
            self.formules_imprimees.append(c.key)
            fr.down(9)
            d.box(fr.x, fr.y - 1.4, 1.6, 6.4, fill=S.ok if c.ok else S.ko)
            lab = self.SYN.court(c) + ("" if c.nat == "EC" else " [" + c.nat + "]")
            d.t(fr.x + 5, fr.y, lab, "Carlito-Bold", 6.3, S.ink)
            wl = d.w(lab, "Carlito-Bold", 6.3)
            d.t(fr.x + 5 + wl + 4, fr.y, d.fit("— " + self.ref(c.ref), S.f_b, S_REF, fr.w - wl - 12), S.f_b, S_REF, S.mut)
            for l in bloc:
                fr.down(S_FORM * 1.25)
                d.t(fr.x + 5, fr.y, l, S.f_b, S_FORM, S.ink)
            fr.down(3)

    def construire(self, d):
        S = self.S
        W, H = d.W, d.H
        top = self.bandeau(d)
        w1, w2 = LARG[0], LARG[1]
        w3 = W - 2 * M - w1 - w2 - 2 * GAP
        x1, x2, x3 = M, M + w1 + GAP, M + w1 + GAP + w2 + GAP
        for x in (x2, x3):
            d.line(x - GAP / 2, top, x - GAP / 2, BAS, S.rule, 0.45)
        f1 = Frame(x1, top, w1, BAS)
        f2 = Frame(x2, top, w2, BAS)
        f3 = Frame(x3, top, w3, BAS)
        self.colonne_dessins(d, f1)
        for cle in self.COL2:
            self.table_simple(d, f2, cle, (92, 34, 46, 26, w2 - 198))
        for cle in self.COL3:
            self.table_simple(d, f3, cle, (98, 36, 50, 28, w3 - 212))
        self.table_pinces(d, f3)
        hc = self.conclusion(d, x3, w3)
        f3.bottom = BAS + hc + 6
        self.formules(d, [f2, f3])
        d.t(M, 24, d.fit(self.LEGENDE, S.f_b, 5.6, W - 2 * M), S.f_b, 5.6, S.mut)
        d.t(M, 16.5, d.fit(self.NOTATIONS, S.f_b, 5.6, W - 2 * M), S.f_b, 5.6, S.mut)
        for f in (f1, f2, f3):
            if f.overflow() > 1.0:
                self.warnings.append(f"colonne {f.x:.0f} : {f.overflow():.0f} pt")
        return self.warnings


# ------------------------------------------------- page 2 : plan de principe
class PlanPrincipeFP(PlanPrincipe):
    """Le plan de principe du plat d'âme : mêmes échelles normalisées, mêmes
    dispositions et même cartouche que le module doubles cornières — seules
    les VUES et les cases du cartouche sont propres à cet assemblage."""

    def __init__(self, R, doc_meta):
        super().__init__(R, doc_meta)
        self.titre = TITRE

    def _vues(self, dnm):
        f = TEXTE_MM * dnm
        R = self.R
        return [("ÉLÉVATION", schemas.elevation(R, schemas.options_fabrication(schemas.EXCLURE_ELEVATION, f))),
                ("VUE EN PLAN", schemas.plan(R, schemas.options_fabrication(schemas.EXCLURE_PLAN, f))),
                ("VUE DE DROITE", schemas.vue_droite(R, schemas.options_fabrication(schemas.EXCLURE_DROITE, f)))]

    def _cartouche(self, d, dnm):
        from ..doubles_cornieres.note import _fmt_echelle, CART_H
        S, R, doc = self.S, self.R, self.doc
        u = R.u
        W = d.W
        x0, y0, w, h = M, M, W - 2 * M, CART_H
        d.box(x0, y0, w, h, stroke=S.ink, lw=0.9)
        fix = ("Boulons " + R.boulon + " " + u.classe + " – trous Ø" + F(R.d_0, 0)
               + " – " + js_str(R.n_1) + " × " + js_str(R.n_2) + " · soudure double a " + F(R.a_w, 0))
        vis = "par boulon : " + (str(doc.get("visserie") or "").strip() or VISSERIE_DEFAUT)
        ident = " · ".join(str(x) for x in (doc.get("projet"), doc.get("partie")) if x)
        cases = [("ASSEMBLAGE", "Poutre–poutre – plat d'âme soudé", ident or "—", 0.185),
                 ("POUTRES", "P : " + _prof(R, "P") + " " + u.nu_P, "S : " + _prof(R, "S") + " " + u.nu_S, 0.165),
                 ("PLAT", nb(R.h_p) + "×" + nb(R.b_p) + "×" + nb(R.t_p) + " " + u.nu_pl,
                  "zp " + F(N(u.z_C), 0) + " mm", 0.165),
                 ("FIXATIONS", fix, vis, 0.27),
                 ("DATE · INDICE", str(doc.get("date", "")), "indice " + str(doc.get("indice", "")), 0.10),
                 ("ÉCHELLE", _fmt_echelle(dnm), "A4 paysage", 0.115)]
        x = x0
        for i, (lab, l1, l2, part) in enumerate(cases):
            cw = w * part
            if i:
                d.line(x, y0 + 2, x, y0 + h - 2, S.rule, 0.6)
            d.t(x + 6, y0 + h - 10, lab, S.f_v, 5.4, S.mut, track=1.2)
            gras = S.f_h if lab == "ÉCHELLE" else "Carlito-Bold"
            d.t(x + 6, y0 + h - 21, d.fit(str(l1), gras, 7.2 if lab == "ÉCHELLE" else 6.6, cw - 12),
                gras, 7.2 if lab == "ÉCHELLE" else 6.6, S.ink)
            if l2:
                d.t(x + 6, y0 + h - 32, d.fit(str(l2), S.f_b, 6.2, cw - 12), S.f_b, 6.2, S.ink)
            x += cw


def _essai(R, doc_meta, variante, chemin):
    d = Doc(chemin, A4L, title=doc_meta.get("titre", "Note de calcul"))
    d.new_page(A4L)
    n = Note(R, doc_meta, variante)
    w = n.construire(d)
    d.save()
    return list(w)


def generer_note(R, infos=None, chemin=None):
    """La note (bytes) : page 1 de calcul, page 2 « PLAN DE PRINCIPE »."""
    global derniers_avertissements, derniere_variante, derniere_echelle, derniere_disposition
    infos = infos or {}
    doc_meta = ndc_data.construire_doc(infos, date_defaut=datetime.today().strftime("%d/%m/%Y"))
    doc_meta["titre"] = "Note de calcul"
    doc_meta["visserie"] = infos.get("visserie", "")
    doc_meta[SANS_TAUX] = bool(infos.get(SANS_TAUX))          # la note sans les taux (note_kit)
    if chemin is None:
        fd, chemin = tempfile.mkstemp(suffix=".pdf", prefix="note_plat_ame_")
        os.close(fd)
    retenue = VARIANTES[-1]
    warn = []
    for v in VARIANTES:
        warn = _essai(R, doc_meta, v, chemin)
        retenue = v
        if not warn:
            break
    d = Doc(chemin, A4L, title=doc_meta.get("titre", "Note de calcul"))
    d.new_page(A4L)
    n1 = Note(R, doc_meta, retenue)
    warn = list(n1.construire(d))
    d.new_page(A4L)
    pp = PlanPrincipeFP(R, doc_meta)
    warn += pp.construire(d)
    d.save()
    derniere_variante = retenue
    derniers_avertissements = warn
    derniere_echelle = getattr(pp, "echelle", None)
    derniere_disposition = getattr(pp, "disposition", None)
    with open(chemin, "rb") as fh:
        return fh.read()


derniers_avertissements = []
derniere_variante = None
derniere_echelle = None
derniere_disposition = None
