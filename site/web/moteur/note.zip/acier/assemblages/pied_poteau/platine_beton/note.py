# -*- coding: utf-8 -*-
"""Note de calcul du pied de poteau — DEUX pages A4 paysage, la charte de la
famille (palette Encre, bandeau statut, en-tête compact en trois lignes,
trois colonnes, pied en deux lignes) :

- page 1 : bandeau (statut, η max, dimensionnante, taux par élément,
  alertes), en-tête (poteau · platine · massif ; tiges · mortier · cordons ;
  efforts), colonne 1 = vue en plan avec la RÉPARTITION, coupe A-A, domaine
  (Mx, My) et hypothèses, colonnes 2 et 3 = tableaux par élément (Ed / Rd /
  η / réf.), pince de la platine, formules des vérifications essentielles,
  conclusion ;
- page 2 : « PLAN DE PRINCIPE » — coupe A-A, vue en plan et coupe B-B à la
  même échelle normalisée (PlanPrincipe du module doubles cornières), avec
  le cartouche de CET assemblage.
"""
import os
import re
import tempfile
from datetime import datetime

from reportlab.lib.pagesizes import A4, landscape

from ndc_pdf.kit import Doc, mix
from ndc_pdf import data as ndc_data
from acier.formats import F, pct, nb
from acier.js import N, js_str
from acier.assemblages.note_kit import empaqueter_au_mieux, SANS_TAUX, masquer_taux
from . import schemas, synthese
from .entrees import VISSERIE_DEFAUT, OUI, ancrage_txt, TYPE_CROSSE, TYPE_ETA
from .notation import LEGENDE_REFERENCES, ligne_alerte, ref_courte, rangee_lisible, NOTATIONS as NOTATIONS_COURTES
from ...poutre_poutre.plat_ame import note as _np
from ...poutre_poutre.doubles_cornieres.note import PlanPrincipe, TEXTE_MM, _fmt_echelle, CART_H
from ...poutre_poutre.doubles_cornieres.rapport import peindre

A4L = landscape(A4)
M = _np.M
BAS = _np.BAS

TITRE = "Pied de poteau — platine sur béton (N + Mx + My)"
# un nombre et son unité (« 8,6 mm », « 43,2 kN », « 35,9 kNm/m ») : l'espace qui les sépare devient insécable
_UNITE = re.compile(r"(\d) (kNm/m|kNm|kN|MPa|mm)(?![\w/])")
VARIANTES = _np.VARIANTES


def lignes_entete(R):
    """L'en-tête compact : objets, attaches, efforts — la géométrie détaillée
    est cotée sur le plan de principe."""
    u = R.u
    l1 = ("Poteau " + R.nom_c + " " + str(u.nu_c)
          + "    |    Platine " + nb(N(u.bp_u)) + "×" + nb(N(u.lp_u)) + "×" + nb(N(u.tp_u)) + " " + str(u.nu_pl)
          + "    |    Massif " + nb(N(u.bc_u)) + "×" + nb(N(u.lc_u)) + "×" + nb(N(u.hc_u)) + " "
          + str(u.beton) + (" fissuré" if u.fiss == OUI else " non fissuré"))
    l2 = ("Tiges " + js_str(R.n_t) + " × " + str(u.ancr) + " " + str(u.classe) + " (" + js_str(int(u.n_ax)) + " files × "
          + js_str(int(u.n_ay)) + " rangées, " + nb(N(u.w_x)) + " × " + nb(N(u.w_y)) + ") · "
          + ancrage_txt(u, True) + " · hef " + F(u.hef, 0)
          + "    |    Mortier " + F(u.t_g, 0) + " mm, " + F(u.f_g, 0) + " MPa"
          + "    |    Cordons a " + F(u.a_w, 1).replace(",0", ""))
    l3 = ("NEd " + F(u.N_Ed, 1) + " kN    |    Mx,Ed " + F(u.Mx_Ed, 1) + " kNm    |    My,Ed " + F(u.My_Ed, 1)
          + " kNm    |    Vx,Ed " + F(u.Vx_Ed, 1) + " kN    |    Vy,Ed " + F(u.Vy_Ed, 1) + " kN"
          + ("    |    TEd " + F(u.T_Ed, 2) + " kNm" if N(u.T_Ed) else ""))
    return l1, l2, l3


def segments_hypotheses(R):
    """Les SEGMENTS du bloc HYPOTHÈSES (charte du 31/10/2026, §11) : le
    périmètre ; l'aire efficace (c, Aeff, fjd, βj) et ΣT de la platine
    rigide ; le niveau du verdict, le type de tiges, les coefficients —
    chaque segment écrit en entier, avec sa forme courte quand il en a une ;
    le kit (``note_kit.empaqueter``) les range en ≤ 3 lignes de ≤ 110
    caractères. Gardés parce qu'ils ne vivent nulle part ailleurs sur la
    page : Aeff et ΣT. Retirés parce que déjà sur la page : C et pmax (vue en
    plan, table Béton d'appui), les taux des niveaux 1 et 2 (lignes fc1 / fc2),
    Sj,ini et son seuil (alerte « rig » sous le bandeau). Perte assumée :
    √(Ac1/Ac0) (Paramètres retenus à l'écran, export texte)."""
    u = R.u
    bj = "2/3" if abs(R.beta_j - 2 / 3) < 1e-9 else F(R.beta_j, 2)
    perim = ("périmètre EN 1993-1-8 : platine, tiges, poteau, cordons, appui fjd ; béton d'ancrage EN 1992-4 en "
             "information" if R.perim_ec3 else
             "périmètre complet : EN 1993-1-8 et EN 1992-4, béton d'ancrage dans le verdict")
    aire = "c = " + F(R.c, 0) + " mm, Aeff = " + F(R.A_eff / 100, 0) + " cm², fjd = " + F(R.fjd, 1) + " MPa"
    tiges = {TYPE_CROSSE: "tiges à crosse (adhérence)", TYPE_ETA: "tiges scellées (ETA)"}.get(
        u.typ_a, "tiges coulées (ψM,N = 1)")
    return [perim,
            ("aire efficace EC3 §6.2.5 : " + aire + " (βj " + bj + ")", "aire efficace §6.2.5 : " + aire),
            "platine rigide, ΣT = " + F(R.T_tot, 0) + " kN",
            "verdict niveau 1",
            tiges,
            "γM0 " + F(N(u.g_M0), 2) + " · γM2 " + F(N(u.g_M2), 2) + " · γc " + F(N(u.g_c), 2) + " · γMc "
            + F(N(u.g_Mc), 2)]


def lignes_hypotheses(R):
    """Trois lignes de ≤ 110 caractères ; une ligne
    de plus quand plusieurs cas se cumulent (défaut D1 du dossier de contrôle,
    lot de clôture du 27/11/2026) : la note s'imprime toujours."""
    return empaqueter_au_mieux(segments_hypotheses(R), n_max=3, larg=110)


class Note(_np.Note):
    """Page 1 : la mise en page de la famille (bandeau, colonnes, tableaux,
    formules, conclusion — classe du plat d'âme) avec le titre, la synthèse,
    les schémas, l'en-tête, les hypothèses, les tableaux et les références
    courtes de CET assemblage."""
    TITRE_NOTE = TITRE
    SYN = synthese
    SCH = schemas
    COL2 = ("pied", "platine", "beton")
    COL3 = ("ancrages", "tiges", "poteau", "soudure")
    NORME = "(γM0 : ANB belge ; αcc = 0,85)"
    LEGENDE = LEGENDE_REFERENCES
    NOTATIONS = NOTATIONS_COURTES
    REF = staticmethod(ref_courte)

    def entete(self, R):
        return lignes_entete(R)

    def hypotheses(self, R):
        return lignes_hypotheses(R)

    def alerte(self, a, R):
        return ligne_alerte(a, R)

    def table_simple(self, d, fr, cle, largeurs):
        """Comme la famille, avec le titre qui dit « information » pour les
        ancrages hors périmètre, et le calcul à la main sous la platine."""
        R = self.R
        ls = self.SYN.lignes(R, cle)
        if not ls:
            return
        cols = [("Vérification", largeurs[0], "left"), ("Ed", largeurs[1], "right"), ("Rd", largeurs[2], "right"),
                ("η", largeurs[3], "right"), ("Réf.", largeurs[4], "left")]
        lignes = []
        for l in ls:
            gov = l["c"] is R.gov
            lignes.append([("lab", l["lab"], "gov" if gov else ""),
                           ("num", l["Ed"]), ("num", l["Rd"] + (" " + l["unit"] if l["unit"] else "")),
                           ("eta", l["pct"], l["ok"], gov), ("ref", l["ref"])])
        self.table(d, fr, self.SYN.titre_table(cle, R).upper(), cols, lignes)
        if cle == "platine":
            self.table_platine_main(d, fr)

    def table_platine_main(self, d, fr):
        """Le calcul de la platine à la main : le moment pris de chaque côté,
        l'épaisseur qu'il demande, l'épaisseur requise."""
        R = self.R
        P = R.plaque
        u = R.u
        if not R.ck["tpq"].active:
            return
        T = P.get("tendu")

        def mm(v):
            return "∞" if v == float("inf") else F(v, 1)
        w = fr.w
        cols = [("Côté", 62, "left"), ("Le moment pris, sa résistance, l'épaisseur qu'il demande", w - 62, "left")]
        lignes = [[("lab", "Console comprimée"),
                   ("lab", "p max " + F(P["p_max"], 1) + " MPa sur c = " + F(P["c"], 0) + " mm (" + P["ligne"]
                    + ") : mEd = ∫p·s ds = " + F(P["m_Ed"], 1) + " ≤ tp²·fy/(6·γM0) = " + F(P["m_Rd_el"], 1)
                    + " kNm/m → tc = " + mm(P["t_c"]) + " mm ; appui tN = " + mm(P["t_N"]) + " ; niveau 1 tM = "
                    + mm(P["t_M"]) + " mm")]]
        if T and T["T"] > 1e-9:
            lignes.append([("lab", "Tronçon en T"),
                           ("lab", "rangée " + rangee_lisible(T["cle"]) + " : M = T·m = " + F(T["T"], 1) + " × "
                            + F(T["m"], 1) + " = "
                            + F(T["M"], 2) + " kNm ; Σleff,1 = " + F(T["leff1"], 0) + " mm, Mpl,1 = " + F(T["Mpl1"], 2)
                            + " kNm, " + ("avec" if T["levier"] else "sans") + " effet de levier → FT,Rd = "
                            + F(T["FT_Rd"], 0) + " kN → tT = " + mm(P["t_T"]) + " mm")])
        lignes.append([("lab", "Épaisseur requise", "gov"),
                       ("lab", "max(tc ; tN ; tM ; tT) = " + mm(P["t_req"]) + " mm pour tp = " + F(u.tp_u, 0) + " mm ("
                        + pct(R.ck["tpq"].eta, 0) + ")", "gov")])
        NV = P["navier"]
        if NV["applicable"]:
            lignes.append([("lab", "Repère Navier"),
                           ("lab", "platine entière : σ max = " + F(NV["s_max"], 2) + " MPa, L = " + F(NV["L"], 0)
                            + " mm, m = σ·L²/2 = " + F(NV["m"], 1) + " kNm/m → t = " + F(NV["t"], 1) + " mm")])
        # une valeur ne se sépare pas de son unité en fin de ligne (« tT = 8,6 / mm », relecture des notes finales
        # du 01/11/2026) : ndc_pdf.kit.wrap ne coupe qu'aux espaces ordinaires
        lignes = [[(c[0], _UNITE.sub("\\1\u00a0\\2", c[1])) + tuple(c[2:]) for c in l] for l in lignes]
        self.table(d, fr, "ÉPAISSEUR DE LA PLATINE — LE CALCUL À LA MAIN", cols, lignes)

    def colonne_dessins(self, d, fr):
        """Colonne 1 : la vue en plan avec la répartition (le dessin qui
        explique le résultat), la coupe A-A, le domaine (Mx, My), puis les
        hypothèses."""
        S, R = self.S, self.R
        hyp = self.hypotheses(R)
        lignes = []
        for h in hyp:
            lignes.extend(d.wrap(h, S.f_b, 6.2, fr.w))
        h_hyp = 13 + len(lignes) * 6.2 * 1.3 + 4
        dispo = fr.room() - h_hyp - 3 * 13 - 9
        hp = dispo * 0.46
        he = dispo * 0.28
        hd = dispo - hp - he
        opt = schemas.options_rapport()
        self.titre(d, fr, "VUE EN PLAN — RÉPARTITION (mm)")
        fr.down(hp)
        peindre(d, schemas.plan(R, opt), fr.x, fr.y, fr.w, hp - 2)
        self.titre(d, fr, "COUPE A-A")
        fr.down(he)
        peindre(d, schemas.coupe_aa(R, opt), fr.x, fr.y, fr.w, he - 2)
        self.titre(d, fr, "DOMAINE (Mx, My) À N = " + F(R.u.N_Ed, 0) + " kN")
        fr.down(hd)
        peindre(d, schemas.domaine(R), fr.x, fr.y, fr.w, hd - 2)
        self.titre(d, fr, "HYPOTHÈSES")
        fr.down(3)
        for l in lignes:
            fr.down(6.2 * 1.3)
            d.t(fr.x, fr.y, l, S.f_b, 6.2, S.mut)

    def conclusion(self, d, x, w):
        S, R = self.S, self.R
        statut = "PIED DE POTEAU VÉRIFIÉ" if R.verified else "PIED DE POTEAU NON VÉRIFIÉ"
        if R.verified and R.get("a_verifier"):
            # brief v12 § 19.1 point 4 : un contrôle hors périmètre au-delà de 100 % — « À VÉRIFIER », en ocre
            txt = ("PIED DE POTEAU À VÉRIFIER : " + R.a_verifier + " ; vérifié à l'ELU selon EN 1993-1-8 §6.2.5 et "
                   "§6.2.8 " + self.NORME + " pour le reste.")
        elif R.perim_ec3:
            txt = (statut + " à l'ELU selon EN 1993-1-8 §6.2.5 et §6.2.8 " + self.NORME + " — le béton d'ancrage "
                   "(EN 1992-4) est donné en information et ne fait pas partie du verdict"
                   + (" ; sous réserve des points signalés." if R.verified and (R.reserve or R.alerts) else "."))
        else:
            txt = (statut + " à l'ELU selon EN 1993-1-8 §6.2.8, EN 1992-1-1 §6.7 et EN 1992-4 " + self.NORME
                   + (" — sous réserve des points signalés." if R.verified and (R.reserve or R.alerts) else "."))
        col = S.att if (R.verified and R.get("a_verifier")) else (S.ok if R.verified else S.ko)
        txt = masquer_taux(txt) if self.sans_taux else txt
        lines = d.wrap(txt, S.f_b, 7.2, w - 15)
        h = len(lines) * 7.2 * 1.28 + 7
        y0 = BAS
        d.box(x, y0, w, h, fill=mix(col, "#FFFFFF", 0.90))
        d.box(x, y0 + 1.5, 2.0, h - 3, fill=col)
        for i, ln in enumerate(lines):
            d.t(x + 9, y0 + h - 7.2 * (1.02 + i * 1.28), ln, S.f_b, 7.2, S.ink)
        return h


# ------------------------------------------------- page 2 : plan de principe
class PlanPrincipePB(PlanPrincipe):
    """Le plan de principe du pied : mêmes échelles normalisées, mêmes
    dispositions et même cartouche que les assemblages poutre–poutre — seules
    les VUES (coupe A-A, vue en plan, coupe B-B) et les cases du cartouche
    sont propres à cet assemblage."""

    def __init__(self, R, doc_meta):
        super().__init__(R, doc_meta)
        self.titre = TITRE

    def _vues(self, dnm):
        f = TEXTE_MM * dnm
        R = self.R
        return [("COUPE A-A", schemas.coupe_aa(R, schemas.options_fabrication(schemas.EXCLURE_AA, f))),
                ("VUE EN PLAN", schemas.plan(R, schemas.options_fabrication(schemas.EXCLURE_PLAN, f))),
                ("COUPE B-B", schemas.coupe_bb(R, schemas.options_fabrication(schemas.EXCLURE_BB, f)))]

    def _cartouche(self, d, dnm):
        S, R, doc = self.S, self.R, self.doc
        u = R.u
        W = d.W
        x0, y0, w, h = M, M, W - 2 * M, CART_H
        d.box(x0, y0, w, h, stroke=S.ink, lw=0.9)
        fix = ("Tiges " + js_str(R.n_t) + " × " + str(u.ancr) + " " + str(u.classe) + " – trous Ø" + F(R.d0, 0)
               + " – " + js_str(int(u.n_ax)) + " × " + js_str(int(u.n_ay)) + " (" + nb(N(u.w_x)) + " × "
               + nb(N(u.w_y)) + ") · " + ancrage_txt(u, True) + " · hef " + F(u.hef, 0))
        vis = "par tige : " + (str(doc.get("visserie") or "").strip() or VISSERIE_DEFAUT)
        # Le rédacteur saisi (id_red) est porté au cartouche — un champ saisi et jamais lu était un
        # défaut (charte du 31/10/2026, amendement 3) ; un champ vide n'est pas imprimé.
        ident = " · ".join(str(x) for x in (doc.get("projet"), doc.get("partie"), u.get("id_red")) if x)
        cases = [("ASSEMBLAGE", "Pied de poteau – platine sur béton", ident or "—", 0.185),
                 ("POTEAU · MASSIF", R.nom_c + " " + str(u.nu_c),
                  "massif " + nb(N(u.bc_u)) + "×" + nb(N(u.lc_u)) + "×" + nb(N(u.hc_u)) + " " + str(u.beton), 0.165),
                 ("PLATINE", nb(N(u.bp_u)) + "×" + nb(N(u.lp_u)) + "×" + nb(N(u.tp_u)) + " " + str(u.nu_pl),
                  "mortier " + F(u.t_g, 0) + " mm · cordons a " + F(u.a_w, 1).replace(",0", ""), 0.165),
                 ("TIGES D'ANCRAGE", fix, vis, 0.27),
                 ("DATE · INDICE", str(doc.get("date", "")), "indice " + str(doc.get("indice", "")), 0.10),
                 ("ÉCHELLE", _fmt_echelle(dnm), "A4 paysage", 0.115)]
        x = x0
        for i, (lab, l1, l2, part) in enumerate(cases):
            cw = w * part
            if i:
                d.line(x, y0 + 2, x, y0 + h - 2, S.rule, 0.6)
            d.t(x + 6, y0 + h - 10, lab, S.f_v, 5.4, S.mut, track=1.2)
            gras = S.f_h if lab == "ÉCHELLE" else "Carlito-Bold"
            d.t(x + 6, y0 + h - 21, d.fit(str(l1), gras, 7.2 if lab == "ÉCHELLE" else 6.6, cw - 12),
                gras, 7.2 if lab == "ÉCHELLE" else 6.6, S.ink)
            if l2:
                d.t(x + 6, y0 + h - 32, d.fit(str(l2), S.f_b, 6.2, cw - 12), S.f_b, 6.2, S.ink)
            x += cw


def _essai(R, doc_meta, variante, chemin):
    d = Doc(chemin, A4L, title=doc_meta.get("titre", "Note de calcul"))
    d.new_page(A4L)
    n = Note(R, doc_meta, variante)
    w = n.construire(d)
    d.save()
    return list(w)


def generer_note(R, infos=None, chemin=None):
    """La note (bytes) : page 1 de calcul, page 2 « PLAN DE PRINCIPE » — celle
    du mode de ``R`` (calcul manuel : ``manuel.note``)."""
    global derniers_avertissements, derniere_variante, derniere_echelle, derniere_disposition
    if getattr(R, "mode", "") == "manuel":
        from .manuel import note as _nm
        octets = _nm.generer_note(R, infos, chemin)
        derniers_avertissements, derniere_variante = _nm.derniers_avertissements, _nm.derniere_variante
        derniere_echelle, derniere_disposition = _nm.derniere_echelle, _nm.derniere_disposition
        return octets
    infos = infos or {}
    doc_meta = ndc_data.construire_doc(infos, date_defaut=datetime.today().strftime("%d/%m/%Y"))
    doc_meta["titre"] = "Note de calcul"
    doc_meta["visserie"] = infos.get("visserie", "")
    doc_meta[SANS_TAUX] = bool(infos.get(SANS_TAUX))          # la note sans les taux (note_kit)
    if chemin is None:
        fd, chemin = tempfile.mkstemp(suffix=".pdf", prefix="note_pied_poteau_")
        os.close(fd)
    retenue = VARIANTES[-1]
    warn = []
    for v in VARIANTES:
        warn = _essai(R, doc_meta, v, chemin)
        retenue = v
        if not warn:
            break
    d = Doc(chemin, A4L, title=doc_meta.get("titre", "Note de calcul"))
    d.new_page(A4L)
    n1 = Note(R, doc_meta, retenue)
    warn = list(n1.construire(d))
    d.new_page(A4L)
    pp = PlanPrincipePB(R, doc_meta)
    warn += pp.construire(d)
    d.save()
    derniere_variante = retenue
    derniers_avertissements = warn
    derniere_echelle = getattr(pp, "echelle", None)
    derniere_disposition = getattr(pp, "disposition", None)
    with open(chemin, "rb") as fh:
        return fh.read()


derniers_avertissements = []
derniere_variante = None
derniere_echelle = None
derniere_disposition = None
